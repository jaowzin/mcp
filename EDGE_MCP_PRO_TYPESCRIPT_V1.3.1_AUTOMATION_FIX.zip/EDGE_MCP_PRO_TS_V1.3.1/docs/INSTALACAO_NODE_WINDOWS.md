# Instalação do Node.js no Windows

## 1. Baixar o Node.js

Abra o site oficial:

```text
https://nodejs.org/
```

Baixe a versão **Node.js 24 LTS** para Windows, instalador `.msi` de 64 bits.

Evite a versão `Current` para este projeto. A versão LTS é a indicada para uso normal e servidor.

## 2. Instalar

Execute o `.msi` e avance pelas telas:

1. aceite a licença;
2. mantenha a pasta padrão;
3. deixe o recurso **Add to PATH** ativado;
4. conclua a instalação.

Não é necessário instalar Python, Visual Studio ou ferramentas extras para usar este projeto.

## 3. Confirmar

Feche terminais antigos. Abra um novo Prompt de Comando e rode:

```bat
node --version
npm --version
```

O resultado esperado é parecido com:

```text
v24.x.x
11.x.x
```

Se aparecer “node não é reconhecido”, reinicie o Windows ou reinstale o Node deixando `Add to PATH` marcado.

## 4. Preparar o Edge MCP

Extraia o projeto, por exemplo em:

```text
C:\EdgeMCPProTS
```

Evite executar diretamente de dentro do ZIP.

Clique duas vezes em:

```text
Edge MCP Pro TS.bat
```

Escolha:

```text
1 — Preparar ambiente Node.js
```

Essa etapa executa:

```bat
npm install
npm run build
npm run setup
```

Ela não instala Node automaticamente e não altera sua instalação do Windows.

## 5. Abrir o Edge isolado

No menu, escolha:

```text
2 — Abrir Microsoft Edge isolado
```

O projeto abre um perfil separado em:

```text
%LOCALAPPDATA%\EdgeMCPPro\edge-profile-ts
```

A porta CDP é:

```text
http://127.0.0.1:9222
```

Use esse Edge para abrir os sites que o MCP deve analisar. Seu perfil pessoal do Edge não é utilizado.

## 6. Iniciar o servidor

No menu, escolha:

```text
3 — Iniciar MCP + painel administrativo
```

O terminal mostrará:

- URL MCP local;
- URL MCP pública;
- health check;
- painel local;
- workspace.

Mantenha a janela aberta.

## 7. Abrir o painel

Copie a linha `Painel:` do terminal. Ela é parecida com:

```text
http://127.0.0.1:8765/dashboard?token=...
```

O painel só aceita acesso por `localhost`/`127.0.0.1`. Ele não é publicado pelo Cloudflare Tunnel.

## 8. Cadastrar no ChatGPT

Use a URL completa salva em:

```text
%LOCALAPPDATA%\EdgeMCPPro\CHATGPT_MCP_URL.txt
```

No ChatGPT, abra as configurações de Apps/Modo de Desenvolvedor, crie ou atualize o app e cole a URL completa.

Depois de atualizar o código e adicionar ferramentas novas, use a opção **Atualizar ferramentas** do app ou abra uma conversa nova.

## Atualização futura

Ao baixar uma versão nova:

1. extraia em outra pasta;
2. execute a opção `1`;
3. inicie opções `2` e `3`.

A identidade fica em `%LOCALAPPDATA%\EdgeMCPPro`, portanto o caminho MCP não muda.
