# Migração para v1.0.1

A v1.0.1 corrige os inicializadores do Windows.

## Problema corrigido

A v1.0.0 possuía arquivos `.bat` em UTF-8 com finais de linha LF e comandos de menu encadeados com `&`. Em algumas instalações do `cmd.exe`, partes do texto eram interpretadas como comandos.

## Como atualizar

1. Extraia a v1.0.1 em uma pasta nova.
2. Execute `Edge MCP Pro TS.bat`.
3. Escolha `1` para preparar o ambiente.
4. Depois use `2` e `3`.

A identidade persistente em `%LOCALAPPDATA%\EdgeMCPPro` continua sendo reutilizada, portanto a URL MCP não muda.
