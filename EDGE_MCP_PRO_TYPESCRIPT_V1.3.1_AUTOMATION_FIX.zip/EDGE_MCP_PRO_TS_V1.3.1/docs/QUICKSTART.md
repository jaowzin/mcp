# Guia rápido

## Primeira vez

```text
1. Instale Node.js 24 LTS
2. Extraia o projeto
3. Edge MCP Pro TS.bat → 1
4. Edge MCP Pro TS.bat → 2
5. Edge MCP Pro TS.bat → 3
6. Cadastre a URL de CHATGPT_MCP_URL.txt no ChatGPT
```

## Uso diário

```text
Opção 2 → Edge isolado
Opção 3 → MCP e painel
```

## Teste básico

No navegador:

```text
http://127.0.0.1:8765/health
```

No ChatGPT:

```text
Use system_status e browser_list_tabs.
```

## Criar JavaScript pela conversa

```text
Crie site-scripts/teste.js com workspace_write.
Depois registre o arquivo para o domínio atual e execute por script_id.
```

## Importar anexo `.js`

```text
Importe o arquivo anexado com page_script_import_file,
registre os hosts necessários e não execute até retornar o script_id.
```

## Erro 404 no MCP

O ChatGPT está usando um caminho antigo. Copie novamente a URL completa de:

```text
%LOCALAPPDATA%\EdgeMCPPro\CHATGPT_MCP_URL.txt
```
