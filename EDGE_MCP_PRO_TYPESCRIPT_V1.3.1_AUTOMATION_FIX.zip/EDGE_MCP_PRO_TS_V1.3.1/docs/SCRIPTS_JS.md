# Scripts JavaScript

## Fluxo recomendado

```text
workspace_write
→ page_script_register_workspace_file
→ page_script_run_saved
```

## Perfis automáticos

- `visual_preview`: DOM, menus, overlays e acessibilidade sem rede.
- `authorized_web_test`: usa fetch, XHR, WebSocket, EventSource, sendBeacon ou storage.
- `review_required`: usa eval, Function, workers, navegação ou envio de formulários.

Salvar o arquivo nunca executa o código.

## Hosts

Exemplo restrito:

```text
allowed_page_hosts:
- jogo.ctf.local

allowed_network_hosts:
- api.jogo.ctf.local
- socket.jogo.ctf.local
```

Para aceitar tudo, ative **Todos os hosts** no painel e use `*`. Essa opção é poderosa e deve ser utilizada apenas no Edge isolado.

## WebSocket e fetch

Antes de executar um script, o servidor instala wrappers no contexto da página para verificar o hostname de:

- `fetch`;
- `XMLHttpRequest.open`;
- `WebSocket`;
- `EventSource`;
- `navigator.sendBeacon`.

O modo `*` só funciona quando `allowGlobalScriptHosts` está ligado.

## Autoexecução

Marque o script como:

```text
trusted = true
autoRun = true
```

E ative `autoRunTrustedScripts`.

A autoexecução não usa aprovação a cada carregamento. Recomenda-se utilizar hosts específicos em vez de `*`.
