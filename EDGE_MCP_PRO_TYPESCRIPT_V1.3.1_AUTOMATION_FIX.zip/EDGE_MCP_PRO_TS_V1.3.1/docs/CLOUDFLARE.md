# Cloudflare Named Tunnel

O projeto não cria Quick Tunnel automaticamente. Ele espera que o Named Tunnel já encaminhe:

```text
mcp.jaowzin.qzz.io → http://localhost:8765
```

O serviço `cloudflared` pode continuar instalado no Windows como antes.

Para trocar o domínio:

```text
Edge MCP Pro TS.bat → opção 4
```

A opção altera somente a base pública. Ela não troca o caminho secreto.

Teste:

```text
https://mcp.jaowzin.qzz.io/health
```

URL do ChatGPT:

```text
https://mcp.jaowzin.qzz.io/mcp/<segredo-persistente>
```

Nunca publique uma rota separada para o painel. As rotas `/dashboard` e `/admin/*` também verificam que o Host é localhost.
