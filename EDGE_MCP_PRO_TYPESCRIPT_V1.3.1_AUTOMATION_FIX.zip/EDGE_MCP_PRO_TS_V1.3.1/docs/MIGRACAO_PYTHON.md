# Migração da versão Python

Na primeira execução, o setup procura:

```text
%LOCALAPPDATA%\EdgeMCPPro\identity.env
```

Quando encontra valores válidos, importa:

```text
EDGE_MCP_PUBLIC_PATH
EDGE_MCP_ADMIN_TOKEN
```

para:

```text
%LOCALAPPDATA%\EdgeMCPPro\identity.json
```

Isso preserva a URL já cadastrada no ChatGPT.

O código Python antigo não é necessário depois que a versão TypeScript estiver validada, mas mantenha uma cópia até confirmar que o app conectou e as ferramentas foram atualizadas.
