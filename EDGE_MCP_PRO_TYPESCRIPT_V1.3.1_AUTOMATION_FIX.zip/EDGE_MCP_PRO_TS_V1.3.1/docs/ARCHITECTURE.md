# Arquitetura

## Processo principal

O processo Node.js executa:

- Express em `127.0.0.1:8765`;
- transporte MCP Streamable HTTP;
- painel administrativo;
- Playwright Core conectado ao Edge por CDP;
- biblioteca de scripts;
- workspace e auditoria;
- observador de autoexecução.

## Persistência

Dados que devem sobreviver a atualizações ficam em:

```text
%LOCALAPPDATA%\EdgeMCPPro\
```

Principais arquivos:

```text
identity.json
config.json
runtime-settings.json
site-scripts.json
approvals.json
audit.jsonl
CHATGPT_MCP_URL.txt
workspace\
artifacts\
```

## MCP

Cada POST usa transporte stateless. O endpoint é um caminho aleatório persistente:

```text
/mcp/<segredo>
```

GET e DELETE no endpoint retornam 405. Caminhos incorretos retornam 404.

## Edge/CDP

O Edge é iniciado com:

```text
--remote-debugging-address=127.0.0.1
--remote-debugging-port=9222
--user-data-dir=<perfil-isolado>
```

O Playwright usa `chromium.connectOverCDP()`; não instala navegador próprio.

## Scripts

O conteúdo do script é salvo localmente. O registro armazena:

- ID;
- SHA-256;
- perfil detectado;
- hosts de página;
- hosts de API/WebSocket;
- confiança;
- autoexecução.

A execução por MCP recebe somente o `script_id`. A opção de JavaScript direto é separada e desativada por padrão.
