# Segurança

- O Edge usa perfil isolado.
- CDP escuta somente em `127.0.0.1`.
- O MCP usa caminho secreto persistente.
- O painel exige token e Host local.
- Cookies, Authorization e corpos de rede não aparecem em `browser_recent_network`.
- Arquivos ficam dentro do workspace global.
- Imports de anexos rejeitam binário, vazio e tamanho excessivo.
- Scripts têm checksum e escopo de hosts.
- Aprovações de uso único podem ser ligadas ou desligadas pelo painel.
- O bloqueio de emergência é obtido desativando ações, scripts ou rede no painel.

Use apenas em páginas, CTFs, laboratórios, staging e sistemas que você tem autorização para testar.
