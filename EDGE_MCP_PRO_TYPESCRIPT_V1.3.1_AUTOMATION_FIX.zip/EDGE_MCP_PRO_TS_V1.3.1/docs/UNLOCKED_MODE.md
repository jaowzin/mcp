# Modo local liberado

Esta edição remove as aprovações e allowlists **do próprio Edge MCP Pro** para desenvolvimento local:

- JavaScript direto habilitado;
- scripts salvos e scripts com rede habilitados;
- hosts de página e rede liberados;
- localhost e redes privadas habilitados;
- requisições HTTP com qualquer método e cabeçalhos;
- sobrescrita e exclusão no workspace sem aprovação local;
- autoexecução de scripts confiáveis habilitada.

O workspace continua isolado em `%LOCALAPPDATA%\EdgeMCPPro\workspace`, e os limites estruturais de caminho/tamanho continuam ativos.

Esta alteração não desativa políticas ou bloqueios impostos pelo cliente MCP, pelo ChatGPT ou por outro serviço externo.
