# Edge MCP Pro TypeScript v1.3.1 AUTOMATION EDGE

Edição TypeScript completa para automação autorizada do Microsoft Edge isolado via CDP/Playwright Core.

## O que mudou nesta versão

- O modo padrão voltou a ser **catálogo completo** (`EDGE_MCP_TOOL_MODE=advanced`).
- Todas as ferramentas MCP agora declaram `outputSchema`.
- Todas as respostas de ferramenta continuam retornando `structuredContent` como objeto JSON validável.
- URLs sem esquema são aceitas nas ferramentas principais; `gringoxp.site/gringo/GetKey` vira `https://gringoxp.site/gringo/GetKey`.
- O domínio padrão permanece `https://mcp.jaowzin.qzz.io`.
- Em instalação nova, o caminho MCP reaproveita o token antigo: `/mcp/tHkam4tNZY9Oyr5rljc4vEn0IURK1rvZ7Lp5isSpxFs`.
- A ferramenta `browser_open_and_analyze` continua disponível para abrir e analisar uma URL em uma chamada só.
- A edição UNLOCKED mantém scripts, rede privada, workspace e JavaScript liberados para desenvolvimento local.

## Por que o outputSchema foi adicionado

O ChatGPT recomenda que ferramentas que retornam `structuredContent` declarem `outputSchema`. Esta versão instala automaticamente um schema de objeto para toda ferramenta registrada. Assim, `tools/list` mostra `outputSchema` em todas as ações e `tools/call` valida que o resultado estruturado é um objeto.

## Instalação

1. Extraia o ZIP em uma pasta nova.
2. Execute `Edge MCP Pro TS.bat`.
3. Escolha `1 — Preparar ambiente Node.js`.
4. Escolha `2 — Abrir Microsoft Edge isolado`.
5. Escolha `3 — Iniciar MCP e painel administrativo`.
6. Remova o conector antigo no ChatGPT e adicione de novo a URL mostrada no terminal.

A URL pronta também fica em:

```text
MCP_URL_PRONTA.txt
```

## Ferramentas principais

Mesmo com o catálogo completo ativo, use estas primeiro:

- `browser_open_and_analyze`: abre/reutiliza uma URL e retorna página, DOM, texto, scripts, CSS, iframes, console e rede.
- `browser_analyze_page`: analisa a aba atual.
- `browser_snapshot`: cria refs temporárias para clicar/preencher.
- `browser_click`, `browser_fill`, `browser_type_text`, `browser_press`: interações na página.
- `api_http_request`: testa APIs HTTP/HTTPS.
- `source_fetch_url`: baixa JS, CSS, HTML ou JSON público.
- `workspace_write`, `workspace_read`, `api_scaffold_fastify`: criação e edição de APIs locais.
- `system_activity`: diagnostica chamada parada.

## URL sem https

Agora estas duas chamadas são aceitas:

```text
browser_open_and_analyze({ "url": "gringoxp.site/gringo/GetKey" })
browser_open_and_analyze({ "url": "https://gringoxp.site/gringo/GetKey" })
```

## Modo compacto opcional

O modo compacto ainda existe para emergência. Antes de iniciar o servidor:

```bat
set EDGE_MCP_TOOL_MODE=compact
```

Sem isso, o servidor inicia em modo completo.

## Validação da versão

```text
npm run typecheck  -> passou
npm test           -> 18/18 passaram
npm run build      -> passou
tools/list         -> catálogo completo com outputSchema em todas as ferramentas
```

## Segurança

Esta é uma build de desenvolvimento local. Ela remove aprovações locais do projeto, mas políticas externas do ChatGPT/cliente MCP continuam fora do controle do servidor. Não use esta versão como serviço público compartilhado sem autenticação, revisão de permissões e rotação do token.


## Histórico anterior removido nesta distribuição

- Adicionada ferramenta system_session_reset para limpar buffers de console/rede, refs temporárias e histórico recente sem reiniciar tudo.
- Respostas MCP agora são sanitizadas e truncadas com limites previsíveis para evitar que o cliente trate payload grande como bloqueio.
- Buffers internos de console/rede foram reduzidos e podados antes de análises pesadas.
- Defaults de browser_analyze_page/browser_open_and_analyze ficaram menores para uso prolongado.


## Histórico anterior removido nesta distribuição

Esta versão adiciona três ferramentas específicas para CTF/lab autorizado:

- `ctf_readonly_recon`: GET/HEAD read-only no mesmo origin com preview pequeno.
- `ctf_public_code_search`: busca termos e endpoints em HTML/JS/CSS público sem executar mutações.
- `ctf_request_plan`: gera comandos DevTools/curl para testes que envolvem POST/callback/payload, mas não executa essas requisições pelo MCP.

Isso reduz falsos bloqueios do cliente porque evita passar payloads mutáveis por ferramentas genéricas e mantém respostas pequenas, com `outputSchema` e `structuredContent` compatíveis.


## v1.3.1 AUTOMATION EDGE

Inclui browser_quick_scan, browser_frame_scan e ctf_game_runtime_capture para evitar timeouts em Telegram/Gamee, páginas com milhares de elementos e jogos com WebSocket em tempo real.
