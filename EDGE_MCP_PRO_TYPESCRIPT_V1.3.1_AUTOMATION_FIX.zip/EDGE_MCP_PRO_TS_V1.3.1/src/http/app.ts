import express, { type NextFunction, type Request, type Response } from 'express';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import type { AppContext } from '../core/context.js';
import { createMcpServer } from '../mcp/createMcpServer.js';
import { createAdminRouter } from '../admin/router.js';
import { APP_NAME, APP_VERSION } from '../core/version.js';
import { beginActivity, finishActivity } from '../core/activity.js';
import { DeadlineError, withDeadline } from '../core/deadline.js';

function stripPort(host: string): string {
  if (host.startsWith('[')) return host.slice(1, host.indexOf(']'));
  return host.split(':')[0] ?? '';
}

function hostGuard(ctx: AppContext) {
  const publicHost = new URL(ctx.config.publicBaseUrl).hostname.toLowerCase();
  const allowed = new Set(['127.0.0.1', 'localhost', '::1', publicHost]);
  return (req: Request, res: Response, next: NextFunction): void => {
    const host = stripPort(String(req.headers.host ?? '')).toLowerCase();
    if (!allowed.has(host)) {
      res.status(421).json({ error: 'Host não permitido.' });
      return;
    }
    next();
  };
}

function rpcLabel(body: unknown): { method: string; tool?: string; id?: unknown } {
  if (Array.isArray(body)) return { method: 'batch' };
  if (!body || typeof body !== 'object') return { method: 'invalid' };
  const value = body as { method?: unknown; id?: unknown; params?: { name?: unknown } };
  const method = typeof value.method === 'string' ? value.method : 'unknown';
  const tool = method === 'tools/call' && typeof value.params?.name === 'string' ? value.params.name : undefined;
  return { method, tool, id: value.id };
}

function requestTimeoutMs(method: string): number {
  return method === 'tools/call' ? 75_000 : 20_000;
}

async function closeQuietly(label: string, work: () => Promise<void>): Promise<void> {
  await withDeadline(work, 2_000, label).catch(() => undefined);
}

export function createHttpApp(ctx: AppContext): express.Express {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', ['loopback']);
  app.use(hostGuard(ctx));
  app.use(createAdminRouter(ctx));

  app.get('/health', async (_req, res) => {
    const edge = await withDeadline(() => ctx.edge.status(), 5_000, 'Diagnóstico do Edge')
      .catch(error => ({ connected: false, error: error instanceof Error ? error.message : String(error) }));
    res.json({ ok: true, name: APP_NAME, version: APP_VERSION, edge });
  });

  app.get('/', (_req, res) => {
    res.json({ name: APP_NAME, version: APP_VERSION, health: '/health', mcp: ctx.identity.mcpPath });
  });

  app.post(ctx.identity.mcpPath, express.json({ limit: '4mb' }), async (req, res) => {
    const rpc = rpcLabel(req.body);
    const label = rpc.tool ? `tools/call:${rpc.tool}` : rpc.method;
    const timeoutMs = requestTimeoutMs(rpc.method);
    const activity = beginActivity('mcp_request', label, {
      method: rpc.method,
      tool: rpc.tool,
      rpc_id: rpc.id,
      timeout_ms: timeoutMs
    });
    const server = createMcpServer(ctx);
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
    let activityFinished = false;

    const finish = (status: 'ok' | 'error' | 'timeout' | 'cancelled', error?: string): void => {
      if (activityFinished) return;
      activityFinished = true;
      finishActivity(activity, status, error, { http_status: res.statusCode });
    };

    res.setHeader('x-edge-mcp-version', APP_VERSION);
    res.setHeader('x-edge-mcp-request-id', activity.id);
    res.once('finish', () => finish(res.statusCode >= 400 ? 'error' : 'ok'));
    req.once('aborted', () => finish('cancelled', 'A conexão HTTP foi cancelada pelo cliente.'));

    try {
      await withDeadline(() => server.connect(transport), 10_000, 'Conexão do transporte MCP');
      await withDeadline(
        () => transport.handleRequest(req, res, req.body),
        timeoutMs,
        `Requisição MCP ${label}`
      );
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`[MCP ${activity.id}] ${label}: ${message}`);
      if (error instanceof DeadlineError) {
        finish('timeout', message);
        if (!res.headersSent) {
          res.status(504).json({
            jsonrpc: '2.0',
            error: {
              code: -32001,
              message,
              data: { retryable: true, request_id: activity.id }
            },
            id: rpc.id ?? null
          });
        } else if (!res.writableEnded) {
          res.end();
        }
      } else {
        finish('error', message);
        if (!res.headersSent) {
          res.status(500).json({ jsonrpc: '2.0', error: { code: -32603, message: 'Internal server error', data: { request_id: activity.id } }, id: rpc.id ?? null });
        }
      }
    } finally {
      await Promise.all([
        closeQuietly('Fechamento do transporte MCP', () => transport.close()),
        closeQuietly('Fechamento do servidor MCP', () => server.close())
      ]);
    }
  });

  for (const method of ['get', 'delete'] as const) {
    app[method](ctx.identity.mcpPath, (_req, res) => {
      res.status(405).set('Allow', 'POST').json({ jsonrpc: '2.0', error: { code: -32000, message: 'Method not allowed.' }, id: null });
    });
  }

  app.all('/mcp/*path', (_req, res) => res.status(404).json({ error: 'MCP path not found.' }));
  app.use((_req, res) => res.status(404).json({ error: 'Not found' }));
  return app;
}
