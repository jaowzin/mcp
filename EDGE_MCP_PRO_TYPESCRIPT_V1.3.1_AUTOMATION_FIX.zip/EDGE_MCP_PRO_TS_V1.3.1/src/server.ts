import { createContext } from './core/createContext.js';
import { createHttpApp } from './http/app.js';
import { getPaths } from './core/paths.js';
import { APP_NAME, APP_VERSION } from './core/version.js';

const ctx = createContext();
const app = createHttpApp(ctx);
ctx.autorun.start();

const server = app.listen(ctx.config.port, '127.0.0.1', () => {
  const mcpUrl = `${ctx.config.publicBaseUrl}${ctx.identity.mcpPath}`;
  const dashboardUrl = `http://127.0.0.1:${ctx.config.port}/dashboard?token=${ctx.identity.dashboardToken}`;
  console.log('');
  console.log('='.repeat(78));
  console.log(`${APP_NAME.toUpperCase()} v${APP_VERSION}`);
  console.log(`MCP local:   http://127.0.0.1:${ctx.config.port}${ctx.identity.mcpPath}`);
  console.log(`MCP público: ${mcpUrl}`);
  console.log(`Health:      http://127.0.0.1:${ctx.config.port}/health`);
  console.log(`Painel:      ${dashboardUrl}`);
  console.log(`Edge modo:   ${process.env.EDGE_MCP_EDGE_MODE ?? 'automation'} (sem CDP externo por padrao)`);
  console.log(`Workspace:   ${getPaths().workspaceDir}`);
  console.log('='.repeat(78));
  console.log('');
});

async function shutdown(): Promise<void> {
  ctx.autorun.stop();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => void shutdown());
process.on('SIGTERM', () => void shutdown());
