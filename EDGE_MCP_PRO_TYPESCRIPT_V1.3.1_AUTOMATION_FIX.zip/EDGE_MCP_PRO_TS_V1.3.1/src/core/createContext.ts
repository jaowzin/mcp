import { loadIdentity } from './identity.js';
import { loadConfig, RuntimeSettingsStore } from './settings.js';
import { AuditLog } from './audit.js';
import { ApprovalService } from '../services/ApprovalService.js';
import { WorkspaceService } from '../services/WorkspaceService.js';
import { ScriptService } from '../services/ScriptService.js';
import { UploadedFileService } from '../services/UploadedFileService.js';
import { EdgeController } from '../edge/EdgeController.js';
import { AutoRunService } from '../services/AutoRunService.js';
import type { AppContext } from './context.js';

export function createContext(): AppContext {
  const identity = loadIdentity();
  const config = loadConfig();
  const runtime = new RuntimeSettingsStore();
  const audit = new AuditLog();
  const approvals = new ApprovalService(audit);
  const workspace = new WorkspaceService(config.maxFileBytes);
  const scripts = new ScriptService(Math.min(config.maxFileBytes, 1_000_000));
  const uploads = new UploadedFileService(Math.min(config.maxFileBytes, 1_000_000));
  const edge = new EdgeController(config.cdpUrl, runtime);
  const autorun = new AutoRunService(runtime, scripts, edge, audit);
  return { identity, config, runtime, audit, approvals, workspace, scripts, uploads, edge, autorun };
}
