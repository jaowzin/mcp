import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

function findProjectRoot(start: string): string {
  let current = path.resolve(start);
  while (true) {
    if (fs.existsSync(path.join(current, 'package.json'))) return current;
    const parent = path.dirname(current);
    if (parent === current) return process.cwd();
    current = parent;
  }
}

export const PROJECT_ROOT = findProjectRoot(path.dirname(fileURLToPath(import.meta.url)));

function windowsLocalAppData(): string | undefined {
  const value = process.env.LOCALAPPDATA?.trim();
  return value || undefined;
}

export function globalRoot(): string {
  if (process.platform === 'win32') {
    return path.join(windowsLocalAppData() ?? path.join(os.homedir(), 'AppData', 'Local'), 'EdgeMCPPro');
  }
  return path.join(os.homedir(), '.edge-mcp-pro');
}

export interface AppPaths {
  globalRoot: string;
  identityFile: string;
  configFile: string;
  runtimeSettingsFile: string;
  scriptsIndexFile: string;
  approvalsFile: string;
  auditFile: string;
  autorunFile: string;
  workspaceDir: string;
  scriptsDir: string;
  artifactsDir: string;
}

export function getPaths(): AppPaths {
  const root = globalRoot();
  const workspaceDir = path.join(root, 'workspace');
  return {
    globalRoot: root,
    identityFile: path.join(root, 'identity.json'),
    configFile: path.join(root, 'config.json'),
    runtimeSettingsFile: path.join(root, 'runtime-settings.json'),
    scriptsIndexFile: path.join(root, 'site-scripts.json'),
    approvalsFile: path.join(root, 'approvals.json'),
    auditFile: path.join(root, 'audit.jsonl'),
    autorunFile: path.join(root, 'autorun-status.json'),
    workspaceDir,
    scriptsDir: path.join(workspaceDir, 'site-scripts'),
    artifactsDir: path.join(root, 'artifacts')
  };
}

export function ensureDirectories(paths = getPaths()): void {
  for (const dir of [paths.globalRoot, paths.workspaceDir, paths.scriptsDir, paths.artifactsDir]) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

export function isInside(root: string, candidate: string): boolean {
  const rel = path.relative(path.resolve(root), path.resolve(candidate));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

export function safeJoin(root: string, relativePath: string): string {
  const clean = relativePath.replaceAll('\\', '/').replace(/^\/+/, '');
  if (clean.includes('\0')) {
    throw new Error('Caminho inválido.');
  }
  if (!clean || clean === '.') return path.resolve(root);
  const resolved = path.resolve(root, clean);
  if (!isInside(root, resolved)) {
    throw new Error('O caminho precisa permanecer dentro do workspace.');
  }
  return resolved;
}
