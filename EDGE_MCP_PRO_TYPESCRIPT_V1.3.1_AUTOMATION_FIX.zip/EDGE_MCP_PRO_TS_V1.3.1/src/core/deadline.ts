export class DeadlineError extends Error {
  readonly code = 'OPERATION_TIMEOUT';

  constructor(readonly label: string, readonly timeoutMs: number) {
    super(`${label} excedeu o limite de ${Math.ceil(timeoutMs / 1000)}s.`);
    this.name = 'DeadlineError';
  }
}

export async function withDeadline<T>(
  work: Promise<T> | (() => Promise<T> | T),
  timeoutMs: number,
  label = 'Operação',
  signal?: AbortSignal
): Promise<T> {
  const boundedTimeout = Math.max(100, timeoutMs);
  let timer: NodeJS.Timeout | undefined;
  let onAbort: (() => void) | undefined;

  const task = typeof work === 'function'
    ? Promise.resolve().then(work)
    : work;

  const guards: Promise<never>[] = [
    new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new DeadlineError(label, boundedTimeout)), boundedTimeout);
    })
  ];

  if (signal) {
    guards.push(new Promise<never>((_, reject) => {
      onAbort = () => reject(new Error('Operação cancelada pelo cliente.'));
      if (signal.aborted) onAbort();
      else signal.addEventListener('abort', onAbort, { once: true });
    }));
  }

  try {
    return await Promise.race([task, ...guards]);
  } finally {
    if (timer) clearTimeout(timer);
    if (signal && onAbort) signal.removeEventListener('abort', onAbort);
  }
}
