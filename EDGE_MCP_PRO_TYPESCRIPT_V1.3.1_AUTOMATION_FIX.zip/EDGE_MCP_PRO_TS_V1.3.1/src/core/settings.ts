import { getPaths, ensureDirectories } from './paths.js';
import { readJson, writeJsonAtomic } from './json.js';

export interface PersistentConfig {
  publicBaseUrl: string;
  port: number;
  cdpUrl: string;
  maxFileBytes: number;
}

export interface RuntimeSettings {
  allowBrowserActions: boolean;
  allowWorkspaceWrite: boolean;
  allowWorkspaceDelete: boolean;
  allowDirectJavaScript: boolean;
  allowSavedScripts: boolean;
  allowNetworkScripts: boolean;
  allowGlobalScriptHosts: boolean;
  requireApprovalForDirectJavaScript: boolean;
  requireApprovalForNetworkScripts: boolean;
  autoRunTrustedScripts: boolean;
  allowPrivateNetwork: boolean;
}

const DEFAULT_CONFIG: PersistentConfig = {
  publicBaseUrl: 'https://mcp.jaowzin.qzz.io',
  port: 8765,
  cdpUrl: 'http://127.0.0.1:9222',
  maxFileBytes: 1_000_000
};

const DEFAULT_RUNTIME: RuntimeSettings = {
  allowBrowserActions: true,
  allowWorkspaceWrite: true,
  allowWorkspaceDelete: true,
  allowDirectJavaScript: true,
  allowSavedScripts: true,
  allowNetworkScripts: true,
  allowGlobalScriptHosts: true,
  requireApprovalForDirectJavaScript: false,
  requireApprovalForNetworkScripts: false,
  autoRunTrustedScripts: true,
  allowPrivateNetwork: true
};

// Modo de desenvolvimento local liberado. Estas opções prevalecem sobre
// runtime-settings.json antigo para evitar que configurações persistidas de
// versões anteriores voltem a bloquear o fluxo após a atualização.
const UNLOCKED_RUNTIME: RuntimeSettings = { ...DEFAULT_RUNTIME };

function normalizeBaseUrl(input: string): string {
  const url = new URL(input);
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('A URL pública precisa usar HTTP ou HTTPS.');
  url.pathname = '';
  url.search = '';
  url.hash = '';
  return url.toString().replace(/\/$/, '');
}

export function loadConfig(): PersistentConfig {
  const paths = getPaths();
  ensureDirectories(paths);
  const stored = readJson<Partial<PersistentConfig>>(paths.configFile, {});
  const envPort = Number(process.env.EDGE_MCP_PORT ?? '');
  const merged: PersistentConfig = {
    ...DEFAULT_CONFIG,
    ...stored,
    publicBaseUrl: process.env.EDGE_MCP_PUBLIC_BASE_URL ?? stored.publicBaseUrl ?? DEFAULT_CONFIG.publicBaseUrl,
    port: Number.isInteger(envPort) && envPort > 0 ? envPort : stored.port ?? DEFAULT_CONFIG.port,
    cdpUrl: process.env.EDGE_MCP_CDP_URL ?? stored.cdpUrl ?? DEFAULT_CONFIG.cdpUrl
  };
  merged.publicBaseUrl = normalizeBaseUrl(merged.publicBaseUrl);
  writeJsonAtomic(paths.configFile, merged);
  return merged;
}

export function saveConfig(update: Partial<PersistentConfig>): PersistentConfig {
  const current = loadConfig();
  const next = { ...current, ...update };
  next.publicBaseUrl = normalizeBaseUrl(next.publicBaseUrl);
  if (!Number.isInteger(next.port) || next.port < 1 || next.port > 65535) throw new Error('Porta inválida.');
  writeJsonAtomic(getPaths().configFile, next);
  return next;
}

export class RuntimeSettingsStore {
  private value: RuntimeSettings;
  constructor() {
    const paths = getPaths();
    ensureDirectories(paths);
    const stored = readJson<Partial<RuntimeSettings>>(paths.runtimeSettingsFile, {});
    this.value = { ...DEFAULT_RUNTIME, ...stored, ...UNLOCKED_RUNTIME };
    this.save();
  }

  get(): RuntimeSettings {
    return { ...this.value };
  }

  update(patch: Partial<RuntimeSettings>): RuntimeSettings {
    const allowed = new Set(Object.keys(DEFAULT_RUNTIME));
    for (const key of Object.keys(patch)) {
      if (!allowed.has(key)) throw new Error(`Configuração desconhecida: ${key}`);
    }
    this.value = { ...this.value, ...patch, ...UNLOCKED_RUNTIME };
    this.save();
    return this.get();
  }

  assertEnabled(key: keyof RuntimeSettings, message?: string): void {
    if (!this.value[key]) throw new Error(message ?? `A opção ${key} está desativada no painel.`);
  }

  private save(): void {
    writeJsonAtomic(getPaths().runtimeSettingsFile, this.value);
  }
}
