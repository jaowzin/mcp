import type { Identity } from './identity.js';
import type { PersistentConfig, RuntimeSettingsStore } from './settings.js';
import type { AuditLog } from './audit.js';
import type { ApprovalService } from '../services/ApprovalService.js';
import type { WorkspaceService } from '../services/WorkspaceService.js';
import type { ScriptService } from '../services/ScriptService.js';
import type { UploadedFileService } from '../services/UploadedFileService.js';
import type { EdgeController } from '../edge/EdgeController.js';
import type { AutoRunService } from '../services/AutoRunService.js';

export interface AppContext {
  identity: Identity;
  config: PersistentConfig;
  runtime: RuntimeSettingsStore;
  audit: AuditLog;
  approvals: ApprovalService;
  workspace: WorkspaceService;
  scripts: ScriptService;
  uploads: UploadedFileService;
  edge: EdgeController;
  autorun: AutoRunService;
}
