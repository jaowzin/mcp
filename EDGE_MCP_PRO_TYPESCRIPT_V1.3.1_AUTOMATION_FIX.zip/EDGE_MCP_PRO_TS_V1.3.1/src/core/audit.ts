import fs from 'node:fs';
import { appendJsonLine } from './json.js';
import { getPaths } from './paths.js';

export interface AuditEvent {
  at: string;
  actor: 'mcp' | 'dashboard' | 'system';
  action: string;
  subject?: string;
  details?: Record<string, unknown>;
}

export class AuditLog {
  write(event: Omit<AuditEvent, 'at'>): void {
    appendJsonLine(getPaths().auditFile, { at: new Date().toISOString(), ...event });
  }

  recent(limit = 100): AuditEvent[] {
    try {
      const lines = fs.readFileSync(getPaths().auditFile, 'utf8').trim().split(/\r?\n/).filter(Boolean);
      return lines.slice(-Math.max(1, Math.min(limit, 500))).reverse().map(line => JSON.parse(line) as AuditEvent);
    } catch {
      return [];
    }
  }
}
