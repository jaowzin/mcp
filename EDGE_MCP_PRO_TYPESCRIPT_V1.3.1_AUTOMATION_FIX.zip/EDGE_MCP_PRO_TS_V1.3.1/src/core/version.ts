export const APP_NAME = 'Edge MCP Pro TypeScript';
export const APP_VERSION = '1.3.1-automation-edge';
