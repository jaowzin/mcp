import dns from 'node:dns/promises';
import net from 'node:net';

export function normalizeHostname(value: string): string {
  return value.trim().toLowerCase().replace(/^\.+|\.+$/g, '');
}

export function hostMatches(host: string, patterns: string[], allowGlobal: boolean): boolean {
  const normalized = normalizeHostname(host);
  return patterns.some(patternRaw => {
    const pattern = normalizeHostname(patternRaw);
    if (pattern === '*') return allowGlobal;
    if (pattern.startsWith('*.')) {
      const suffix = pattern.slice(1);
      return normalized.endsWith(suffix) && normalized !== suffix.slice(1);
    }
    return normalized === pattern;
  });
}

function privateIpv4(ip: string): boolean {
  const parts = ip.split('.').map(Number);
  if (parts.length !== 4 || parts.some(n => Number.isNaN(n))) return false;
  const [a = 0, b = 0] = parts;
  return a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || a === 0;
}

function privateIpv6(ip: string): boolean {
  const normalized = ip.toLowerCase();
  return normalized === '::1' || normalized.startsWith('fc') || normalized.startsWith('fd') || normalized.startsWith('fe80:') || normalized === '::';
}

export function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) return privateIpv4(ip);
  if (net.isIPv6(ip)) return privateIpv6(ip);
  return false;
}

export function normalizeHttpUrlInput(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) throw new Error('URL vazia.');
  const withScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(trimmed) ? trimmed : `https://${trimmed}`;
  const url = new URL(withScheme);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Somente HTTP e HTTPS são permitidos.');
  if (url.username || url.password) throw new Error('Credenciais na URL não são permitidas.');
  return url.href;
}

export async function assertSafeRemoteUrl(input: string, allowPrivateNetwork: boolean): Promise<URL> {
  const url = new URL(normalizeHttpUrlInput(input));
  const records = await dns.lookup(url.hostname, { all: true });
  if (!allowPrivateNetwork && records.some(record => isPrivateIp(record.address))) {
    throw new Error('Destino de rede privada bloqueado. Ative a opção no painel para laboratórios locais.');
  }
  return url;
}

export function redactHeaders(headers: Record<string, string | string[] | undefined>): Record<string, string> {
  const sensitive = /authorization|cookie|token|secret|password|api[-_]?key|set-cookie/i;
  return Object.fromEntries(
    Object.entries(headers).map(([key, value]) => [key, sensitive.test(key) ? '[REDACTED]' : Array.isArray(value) ? value.join(', ') : value ?? ''])
  );
}
