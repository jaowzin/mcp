import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { getPaths, ensureDirectories } from './paths.js';
import { readJson, writeJsonAtomic } from './json.js';

export interface Identity {
  mcpPath: string;
  dashboardToken: string;
  createdAt: string;
  migratedFrom?: string;
}

const TOKEN_RE = /^[A-Za-z0-9_-]{30,200}$/;

function generateIdentity(): Identity {
  const envPath = process.env.EDGE_MCP_PUBLIC_PATH;
  const envAdminToken = process.env.EDGE_MCP_ADMIN_TOKEN;
  const preconfigured: Identity = {
    mcpPath: envPath && /^\/mcp\/[A-Za-z0-9_-]{30,200}$/.test(envPath)
      ? envPath
      : '/mcp/tHkam4tNZY9Oyr5rljc4vEn0IURK1rvZ7Lp5isSpxFs',
    dashboardToken: envAdminToken && TOKEN_RE.test(envAdminToken)
      ? envAdminToken
      : crypto.randomBytes(32).toString('base64url'),
    createdAt: new Date().toISOString()
  };
  return validIdentity(preconfigured) ? preconfigured : {
    mcpPath: `/mcp/${crypto.randomBytes(32).toString('base64url')}`,
    dashboardToken: crypto.randomBytes(32).toString('base64url'),
    createdAt: new Date().toISOString()
  };
}

function validIdentity(value: Identity | undefined): value is Identity {
  return Boolean(
    value &&
      /^\/mcp\/[A-Za-z0-9_-]{30,200}$/.test(value.mcpPath) &&
      TOKEN_RE.test(value.dashboardToken)
  );
}

function parseEnv(raw: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const index = trimmed.indexOf('=');
    if (index < 1) continue;
    const key = trimmed.slice(0, index).trim();
    let value = trimmed.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

function migratePythonIdentity(target: string): Identity | undefined {
  const localAppData = process.env.LOCALAPPDATA;
  const candidates = [
    localAppData ? path.join(localAppData, 'EdgeMCPPro', 'identity.env') : '',
    path.join(process.env.USERPROFILE ?? '', '.edge-mcp-pro', 'identity.env')
  ].filter(Boolean);

  for (const candidate of candidates) {
    try {
      const values = parseEnv(fs.readFileSync(candidate, 'utf8'));
      const migrated: Identity = {
        mcpPath: values.EDGE_MCP_PUBLIC_PATH ?? '',
        dashboardToken: values.EDGE_MCP_ADMIN_TOKEN ?? '',
        createdAt: new Date().toISOString(),
        migratedFrom: candidate
      };
      if (validIdentity(migrated)) {
        writeJsonAtomic(target, migrated);
        return migrated;
      }
    } catch {
      // Continue searching.
    }
  }
  return undefined;
}

export function loadIdentity(): Identity {
  const paths = getPaths();
  ensureDirectories(paths);
  const existing = readJson<Identity | undefined>(paths.identityFile, undefined);
  if (validIdentity(existing)) return existing;

  const migrated = migratePythonIdentity(paths.identityFile);
  if (migrated) return migrated;

  const created = generateIdentity();
  writeJsonAtomic(paths.identityFile, created);
  return created;
}

export function rotateIdentity(): Identity {
  const paths = getPaths();
  ensureDirectories(paths);
  const created = generateIdentity();
  writeJsonAtomic(paths.identityFile, created);
  return created;
}
