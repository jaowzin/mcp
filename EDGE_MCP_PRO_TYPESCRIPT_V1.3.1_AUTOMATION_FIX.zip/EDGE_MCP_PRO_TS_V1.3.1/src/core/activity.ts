import crypto from 'node:crypto';

export interface ActivityRecord {
  id: string;
  kind: 'mcp_request' | 'tool';
  name: string;
  started_at: string;
  finished_at?: string;
  duration_ms?: number;
  status: 'running' | 'ok' | 'error' | 'timeout' | 'cancelled';
  details?: Record<string, unknown>;
  error?: string;
}

const active = new Map<string, ActivityRecord>();
const recent: ActivityRecord[] = [];
const RECENT_LIMIT = 60;

export function beginActivity(kind: ActivityRecord['kind'], name: string, details?: Record<string, unknown>): ActivityRecord {
  const record: ActivityRecord = {
    id: crypto.randomBytes(8).toString('hex'),
    kind,
    name,
    started_at: new Date().toISOString(),
    status: 'running',
    details
  };
  active.set(record.id, record);
  return record;
}

export function finishActivity(
  record: ActivityRecord,
  status: Exclude<ActivityRecord['status'], 'running'>,
  error?: string,
  details?: Record<string, unknown>
): void {
  const started = Date.parse(record.started_at);
  const finishedAt = new Date();
  const completed: ActivityRecord = {
    ...record,
    status,
    finished_at: finishedAt.toISOString(),
    duration_ms: Math.max(0, finishedAt.getTime() - started),
    error,
    details: { ...(record.details ?? {}), ...(details ?? {}) }
  };
  active.delete(record.id);
  recent.push(completed);
  if (recent.length > RECENT_LIMIT) recent.splice(0, recent.length - RECENT_LIMIT);
}

export function activitySnapshot(limit = 25): { active: ActivityRecord[]; recent: ActivityRecord[]; counts: { active: number; recent: number } } {
  const cappedLimit = Math.max(1, Math.min(limit, RECENT_LIMIT));
  return {
    active: [...active.values()].map(item => ({ ...item })),
    recent: recent.slice(-cappedLimit).reverse().map(item => ({ ...item })),
    counts: { active: active.size, recent: recent.length }
  };
}

export function clearActivityHistory(): { cleared_recent: number; active: number } {
  const cleared = recent.length;
  recent.length = 0;
  return { cleared_recent: cleared, active: active.size };
}
