import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { chromium, type Browser, type BrowserContext, type ConsoleMessage, type Frame, type Page, type Request, type Response } from 'playwright-core';
import { normalizeHttpUrlInput } from '../core/security.js';
import type { RuntimeSettingsStore } from '../core/settings.js';
import { getPaths } from '../core/paths.js';
import { withDeadline } from '../core/deadline.js';

interface ConsoleEvent {
  at: string;
  type: string;
  text: string;
  location?: { url?: string; lineNumber?: number; columnNumber?: number };
}

interface NetworkEvent {
  at: string;
  phase: 'request' | 'response' | 'failed' | 'websocket';
  method?: string;
  url: string;
  status?: number;
  resourceType?: string;
  error?: string;
}


interface WebSocketCaptureFrame {
  direction: 'sent' | 'received';
  request_id: string;
  url: string;
  opcode: number;
  mask?: boolean;
  timestamp?: number;
  payload_chars: number;
  payload_bytes: number;
  decoded_as: 'utf8' | 'base64' | 'raw-string';
  sample_hex: string;
  sample_base64: string;
  sample_text?: string;
  truncated: boolean;
}

interface WebSocketCaptureOptions {
  pageId?: string;
  url?: string;
  urlContains?: string;
  durationMs?: number;
  maxFrames?: number;
  maxPayloadBytes?: number;
  includeSent?: boolean;
  includeReceived?: boolean;
  reload?: boolean;
  clickSelector?: string;
  clickText?: string;
  clickDelayMs?: number;
}

interface FrameSelectorOptions {
  frameUrlContains?: string;
  frameName?: string;
  frameIndex?: number;
}

interface QuickScanOptions extends FrameSelectorOptions {
  pageId?: string;
  eventLimit?: number;
  frameLimit?: number;
  termSearch?: string[];
  termTextChars?: number;
}

interface FrameScanOptions extends FrameSelectorOptions {
  pageId?: string;
  maxTextChars?: number;
  elementLimit?: number;
  scriptLimit?: number;
  stepTimeoutMs?: number;
}

interface SnapshotRef {
  selector: string;
  text: string;
  tag: string;
}

export interface PageAnalysisOptions {
  includeHtml?: boolean;
  maxTextChars?: number;
  maxHtmlChars?: number;
  elementLimit?: number;
  scriptLimit?: number;
  eventLimit?: number;
  stepTimeoutMs?: number;
}

export interface PageAnalysisProgress {
  progress: number;
  total: number;
  message: string;
}

interface AnalysisSection {
  ok: boolean;
  duration_ms: number;
  data?: unknown;
  error?: string;
}

export class EdgeController {
  private browser?: Browser;
  private context?: BrowserContext;
  private activePageId = '';
  private readonly pageIds = new WeakMap<Page, string>();
  private readonly pagesById = new Map<string, Page>();
  private readonly consoleEvents = new Map<string, ConsoleEvent[]>();
  private readonly networkEvents = new Map<string, NetworkEvent[]>();
  private readonly snapshotRefs = new Map<string, Map<string, SnapshotRef>>();
  private connecting?: Promise<void>;

  constructor(private readonly cdpUrl: string, private readonly runtime: RuntimeSettingsStore) {}

  private connectionMode(): 'automation' | 'cdp_legacy' {
    const mode = (process.env.EDGE_MCP_EDGE_MODE ?? process.env.EDGE_MCP_BROWSER_MODE ?? 'automation').toLowerCase();
    return mode.includes('cdp') || mode.includes('legacy') ? 'cdp_legacy' : 'automation';
  }

  private isConnected(): boolean {
    if (!this.context) return false;
    if (this.connectionMode() === 'automation') return true;
    return Boolean(this.browser?.isConnected());
  }

  async status(): Promise<Record<string, unknown>> {
    try {
      await this.ensureConnected();
      return {
        connected: this.isConnected(),
        connection_mode: this.connectionMode() === 'automation' ? 'playwright_automation_no_external_cdp' : 'legacy_external_cdp',
        automation_notice: this.connectionMode() === 'automation' ? 'Edge aberto/controlado por software de automação Playwright.' : 'Modo legado via porta CDP externa.',
        cdp_url: this.connectionMode() === 'cdp_legacy' ? this.cdpUrl : undefined,
        pages: this.pagesById.size,
        active_page_id: this.activePageId
      };
    } catch (error) {
      return { connected: false, connection_mode: this.connectionMode(), error: error instanceof Error ? error.message : String(error) };
    }
  }

  async resetSession(options: { closeExtraTabs?: boolean; clearEvents?: boolean } = {}): Promise<Record<string, unknown>> {
    await this.ensureConnected();
    this.refreshPages();
    const before = {
      pages: this.pagesById.size,
      console_buffers: this.consoleEvents.size,
      network_buffers: this.networkEvents.size,
      snapshots: this.snapshotRefs.size
    };

    if (options.clearEvents ?? true) {
      for (const key of this.consoleEvents.keys()) this.consoleEvents.set(key, []);
      for (const key of this.networkEvents.keys()) this.networkEvents.set(key, []);
      this.snapshotRefs.clear();
    }

    let closed_tabs = 0;
    if (options.closeExtraTabs) {
      const active = this.activePageId;
      for (const [id, page] of [...this.pagesById]) {
        if (id === active) continue;
        try { await page.close({ runBeforeUnload: false }); closed_tabs += 1; } catch { /* best effort */ }
      }
      this.refreshPages();
    }

    return {
      reset: true,
      before,
      after: { pages: this.pagesById.size, active_page_id: this.activePageId },
      closed_tabs,
      guidance: 'Sessão MCP limpa. Continue pela aba ativa ou use browser_open_and_analyze para abrir a URL em uma chamada.'
    };
  }

  async ensureConnected(): Promise<void> {
    if (this.isConnected()) {
      this.refreshPages();
      return;
    }
    if (this.connecting) return this.connecting;
    this.connecting = this.connect();
    try { await this.connecting; } finally { this.connecting = undefined; }
  }

  private async connect(): Promise<void> {
    this.pagesById.clear();
    this.pageIdsClearBestEffort();
    if (this.connectionMode() === 'cdp_legacy') {
      await this.connectLegacyCdp();
    } else {
      await this.launchAutomationEdge();
    }
  }

  private pageIdsClearBestEffort(): void {
    this.activePageId = '';
    this.consoleEvents.clear();
    this.networkEvents.clear();
    this.snapshotRefs.clear();
  }

  private wireContext(context: BrowserContext): void {
    this.context = context;
    this.context.setDefaultTimeout(15_000);
    this.context.setDefaultNavigationTimeout(45_000);
    this.context.on('page', page => this.registerPage(page));
    this.context.on('request', request => this.onRequest(request));
    this.context.on('response', response => this.onResponse(response));
    this.context.on('requestfailed', request => this.onRequestFailed(request));
  }

  private async launchAutomationEdge(): Promise<void> {
    const profileDir = path.join(getPaths().globalRoot, 'edge-profile-automation');
    fs.mkdirSync(profileDir, { recursive: true });
    const context = await chromium.launchPersistentContext(profileDir, {
      channel: 'msedge',
      headless: false,
      timeout: 20_000,
      viewport: null,
      // No Windows, deixa o sandbox ligado para evitar o aviso visual:
      // "voce esta usando um sinalizador de linha de comando sem suporte: --no-sandbox".
      chromiumSandbox: process.platform === 'win32',
      args: [
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-features=Translate'
      ]
    });
    this.browser = context.browser() ?? undefined;
    this.browser?.on('disconnected', () => {
      this.browser = undefined;
      this.context = undefined;
      this.pagesById.clear();
      this.activePageId = '';
    });
    this.wireContext(context);
    if (context.pages().length === 0) await context.newPage();
    this.refreshPages();
  }

  private async connectLegacyCdp(): Promise<void> {
    this.browser = await chromium.connectOverCDP(this.cdpUrl, { timeout: 7_000 });
    this.browser.on('disconnected', () => {
      this.browser = undefined;
      this.context = undefined;
      this.pagesById.clear();
      this.activePageId = '';
    });
    const contexts = this.browser.contexts();
    const context = contexts[0];
    if (!context) throw new Error('Nenhum contexto do Edge foi encontrado.');
    this.wireContext(context);
    this.refreshPages();
  }

  private refreshPages(): void {
    if (!this.context) return;
    for (const page of this.context.pages()) this.registerPage(page);
    for (const [id, page] of this.pagesById) {
      if (page.isClosed()) this.pagesById.delete(id);
    }
    if (!this.activePageId || !this.pagesById.has(this.activePageId)) {
      this.activePageId = [...this.pagesById.keys()][0] ?? '';
    }
  }

  private registerPage(page: Page): string {
    let id = this.pageIds.get(page);
    if (id) return id;
    id = crypto.randomBytes(9).toString('base64url');
    this.pageIds.set(page, id);
    this.pagesById.set(id, page);
    this.consoleEvents.set(id, []);
    this.networkEvents.set(id, []);
    page.on('console', message => this.onConsole(page, message));
    page.on('pageerror', error => this.pushConsole(page, { at: new Date().toISOString(), type: 'pageerror', text: error.message }));
    page.on('websocket', socket => {
      this.pushNetwork(page, { at: new Date().toISOString(), phase: 'websocket', url: socket.url() });
      socket.on('socketerror', error => this.pushNetwork(page, { at: new Date().toISOString(), phase: 'failed', url: socket.url(), error }));
    });
    page.on('close', () => {
      this.pagesById.delete(id!);
      if (this.activePageId === id) this.activePageId = '';
    });
    if (!this.activePageId) this.activePageId = id;
    return id;
  }

  private trimTransientBuffers(pageId = '', eventLimit = 80): void {
    const keep = Math.max(20, Math.min(eventLimit * 2, 180));
    const ids = pageId ? [pageId] : [...this.pagesById.keys()];
    for (const id of ids) {
      const consoleList = this.consoleEvents.get(id);
      if (consoleList && consoleList.length > keep) consoleList.splice(0, consoleList.length - keep);
      const networkList = this.networkEvents.get(id);
      if (networkList && networkList.length > keep) networkList.splice(0, networkList.length - keep);
    }
    if (this.snapshotRefs.size > 10) {
      for (const id of [...this.snapshotRefs.keys()].slice(0, this.snapshotRefs.size - 10)) this.snapshotRefs.delete(id);
    }
  }

  private pageIdFor(page: Page | null): string | undefined {
    if (!page) return undefined;
    return this.registerPage(page);
  }


  private frameLabel(page: Page, frame: Frame): Record<string, unknown> {
    const frames = page.frames();
    return {
      index: frames.indexOf(frame),
      url: frame.url(),
      name: frame.name(),
      is_main: frame === page.mainFrame()
    };
  }

  private selectFrame(page: Page, options: FrameSelectorOptions = {}): Frame {
    const frames = page.frames();
    if (typeof options.frameIndex === 'number' && Number.isFinite(options.frameIndex)) {
      const frame = frames[options.frameIndex];
      if (!frame) throw new Error(`Frame index ${options.frameIndex} não encontrado. Frames disponíveis: ${frames.length}.`);
      return frame;
    }
    if (options.frameUrlContains) {
      const frame = frames.find(item => item.url().includes(options.frameUrlContains!));
      if (!frame) throw new Error(`Nenhum frame contém na URL: ${options.frameUrlContains}`);
      return frame;
    }
    if (options.frameName) {
      const frame = frames.find(item => item.name() === options.frameName);
      if (!frame) throw new Error(`Nenhum frame com nome: ${options.frameName}`);
      return frame;
    }
    return page.mainFrame();
  }

  private async clickInAnyFrame(page: Page, options: { selector?: string; text?: string; timeoutMs?: number }): Promise<Record<string, unknown>> {
    const timeout = Math.max(250, Math.min(options.timeoutMs ?? 8_000, 30_000));
    const selector = options.selector?.trim() ?? '';
    const text = options.text?.trim() ?? '';
    if (!selector && !text) return { attempted: false };
    const tries: Array<{ frame: Frame; frame_index: number }> = page.frames().map((frame, frame_index) => ({ frame, frame_index }));
    for (const item of tries) {
      try {
        if (selector) {
          await item.frame.locator(selector).first().click({ timeout });
          return { attempted: true, clicked: true, by: 'selector', selector, frame: this.frameLabel(page, item.frame) };
        }
        await item.frame.getByText(text, { exact: false }).first().click({ timeout });
        return { attempted: true, clicked: true, by: 'text', text, frame: this.frameLabel(page, item.frame) };
      } catch {
        // try next frame
      }
    }
    return { attempted: true, clicked: false, selector: selector || undefined, text: text || undefined, frame_count: tries.length };
  }

  private onConsole(page: Page, message: ConsoleMessage): void {
    const location = message.location();
    this.pushConsole(page, { at: new Date().toISOString(), type: message.type(), text: message.text(), location });
  }

  private pushConsole(page: Page, event: ConsoleEvent): void {
    const id = this.registerPage(page);
    const list = this.consoleEvents.get(id) ?? [];
    list.push(event);
    if (list.length > 180) list.splice(0, list.length - 180);
    this.consoleEvents.set(id, list);
  }

  private pushNetwork(page: Page, event: NetworkEvent): void {
    const id = this.registerPage(page);
    const list = this.networkEvents.get(id) ?? [];
    list.push(event);
    if (list.length > 300) list.splice(0, list.length - 300);
    this.networkEvents.set(id, list);
  }

  private onRequest(request: Request): void {
    let page: Page | null = null;
    try { page = request.frame().page(); } catch { return; }
    this.pushNetwork(page, { at: new Date().toISOString(), phase: 'request', method: request.method(), url: request.url(), resourceType: request.resourceType() });
  }

  private onResponse(response: Response): void {
    let page: Page | null = null;
    try { page = response.request().frame().page(); } catch { return; }
    this.pushNetwork(page, { at: new Date().toISOString(), phase: 'response', method: response.request().method(), url: response.url(), status: response.status(), resourceType: response.request().resourceType() });
  }

  private onRequestFailed(request: Request): void {
    let page: Page | null = null;
    try { page = request.frame().page(); } catch { return; }
    this.pushNetwork(page, { at: new Date().toISOString(), phase: 'failed', method: request.method(), url: request.url(), resourceType: request.resourceType(), error: request.failure()?.errorText });
  }

  async getPage(pageId = ''): Promise<Page> {
    await this.ensureConnected();
    this.refreshPages();
    const id = pageId || this.activePageId;
    const page = id ? this.pagesById.get(id) : undefined;
    if (!page || page.isClosed()) throw new Error('Aba não encontrada. Use browser_list_tabs.');
    return page;
  }

  async listTabs(): Promise<Array<Record<string, unknown>>> {
    await this.ensureConnected();
    this.refreshPages();
    return Promise.all([...this.pagesById].map(async ([id, page]) => {
      const title = await withDeadline(() => page.title(), 2_500, `Título da aba ${id}`).catch(() => '');
      return { page_id: id, title, url: page.url(), active: id === this.activePageId };
    }));
  }

  async pageInfo(pageId = ''): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const id = this.registerPage(page);
    const data = await withDeadline(() => page.evaluate(() => ({
      readyState: document.readyState,
      viewport: { width: innerWidth, height: innerHeight, devicePixelRatio },
      elements: document.querySelectorAll('*').length,
      links: document.links.length,
      forms: document.forms.length,
      scripts: document.scripts.length,
      stylesheets: document.styleSheets.length
    })), 8_000, 'Leitura das informações da página');
    const title = await withDeadline(() => page.title(), 3_000, 'Leitura do título da página').catch(() => '');
    return { page_id: id, title, url: page.url(), ...data };
  }


  async quickScan(options: QuickScanOptions = {}): Promise<Record<string, unknown>> {
    const started = Date.now();
    const page = await this.getPage(options.pageId ?? '');
    const id = this.registerPage(page);
    const eventLimit = Math.max(1, Math.min(options.eventLimit ?? 40, 120));
    const frameLimit = Math.max(1, Math.min(options.frameLimit ?? 40, 120));
    this.trimTransientBuffers(id, eventLimit);
    const title = await withDeadline(() => page.title(), 2_000, 'Título rápido').catch(() => '');
    const metrics = await withDeadline(() => page.evaluate(() => ({
      readyState: document.readyState,
      url: location.href,
      title: document.title,
      viewport: { width: innerWidth, height: innerHeight, devicePixelRatio },
      counts: {
        elements: document.querySelectorAll('*').length,
        links: document.links.length,
        forms: document.forms.length,
        scripts: document.scripts.length,
        stylesheets: document.styleSheets.length,
        iframes: document.querySelectorAll('iframe').length,
        buttons: document.querySelectorAll('button,[role="button"],input[type="button"],input[type="submit"]').length
      }
    })), 3_500, 'Quick scan DOM').catch(error => ({ error: error instanceof Error ? error.message : String(error) }));

    const frames = page.frames().slice(0, frameLimit).map((frame, index) => ({
      index,
      url: frame.url(),
      name: frame.name(),
      is_main: frame === page.mainFrame()
    }));

    const terms = (options.termSearch ?? []).slice(0, 30).filter(Boolean);
    const termHits: Record<string, unknown>[] = [];
    if (terms.length > 0) {
      const textLimit = Math.max(1_000, Math.min(options.termTextChars ?? 30_000, 80_000));
      for (const [index, frame] of page.frames().entries()) {
        const text = await withDeadline(() => frame.evaluate(max => (document.body?.innerText ?? '').slice(0, max), textLimit), 2_500, `Busca rápida no frame ${index}`).catch(() => '');
        if (!text) continue;
        const hits: Record<string, number> = {};
        for (const term of terms) hits[term] = (String(text).toLowerCase().match(new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').toLowerCase(), 'g')) ?? []).length;
        if (Object.values(hits).some(count => count > 0)) termHits.push({ frame_index: index, frame_url: frame.url(), hits });
      }
    }

    return {
      profile: 'quick_scan_no_full_dom',
      page_id: id,
      title,
      url: page.url(),
      duration_ms: Date.now() - started,
      metrics,
      frames,
      term_hits: termHits,
      recent_console_count: (this.consoleEvents.get(id) ?? []).length,
      recent_network_count: (this.networkEvents.get(id) ?? []).length,
      recent_network_sample: (this.networkEvents.get(id) ?? []).slice(-eventLimit),
      guidance: 'Use browser_frame_scan com frame_url_contains para analisar apenas o iframe do jogo; use ctf_game_runtime_capture para capturar WebSocket enquanto a partida roda.'
    };
  }

  async frameScan(options: FrameScanOptions = {}): Promise<Record<string, unknown>> {
    const started = Date.now();
    const page = await this.getPage(options.pageId ?? '');
    const id = this.registerPage(page);
    const frame = this.selectFrame(page, options);
    const stepTimeoutMs = Math.max(800, Math.min(options.stepTimeoutMs ?? 5_000, 15_000));
    const maxTextChars = Math.max(500, Math.min(options.maxTextChars ?? 12_000, 80_000));
    const elementLimit = Math.max(1, Math.min(options.elementLimit ?? 80, 300));
    const scriptLimit = Math.max(1, Math.min(options.scriptLimit ?? 60, 200));

    const data = await withDeadline(() => frame.evaluate(({ maxTextChars, elementLimit, scriptLimit }) => {
      const visible = (el: Element): boolean => {
        const style = getComputedStyle(el);
        const rect = (el as HTMLElement).getBoundingClientRect();
        return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0;
      };
      const cssPath = (el: Element): string => {
        const parts: string[] = [];
        let current: Element | null = el;
        while (current && current !== document.documentElement && parts.length < 5) {
          let part = current.tagName.toLowerCase();
          if (current.id) { part += `#${CSS.escape(current.id)}`; parts.unshift(part); break; }
          const parent: Element | null = current.parentElement;
          if (parent) {
            const siblings = [...parent.children].filter(child => child.tagName === current!.tagName);
            if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
          }
          parts.unshift(part);
          current = parent;
        }
        return parts.join(' > ');
      };
      const interactive = [...document.querySelectorAll('a,button,input,textarea,select,[role="button"],[role="link"],[tabindex]:not([tabindex="-1"])')]
        .filter(visible)
        .slice(0, elementLimit)
        .map(el => ({
          selector: cssPath(el),
          tag: el.tagName.toLowerCase(),
          text: ((el as HTMLElement).innerText || (el as HTMLInputElement).value || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 200),
          type: (el as HTMLInputElement).type || '',
          name: (el as HTMLInputElement).name || ''
        }));
      return {
        url: location.href,
        title: document.title,
        readyState: document.readyState,
        text: (document.body?.innerText ?? '').slice(0, maxTextChars),
        text_truncated: (document.body?.innerText ?? '').length > maxTextChars,
        counts: {
          elements: document.querySelectorAll('*').length,
          scripts: document.scripts.length,
          stylesheets: document.styleSheets.length,
          forms: document.forms.length,
          iframes: document.querySelectorAll('iframe').length
        },
        interactive,
        scripts: [...document.scripts].slice(0, scriptLimit).map((script, index) => ({ index, src: script.src, type: script.type, inline_chars: script.src ? 0 : (script.textContent?.length ?? 0) }))
      };
    }, { maxTextChars, elementLimit, scriptLimit }), stepTimeoutMs, 'Frame scan direcionado');

    return {
      profile: 'targeted_frame_scan',
      page_id: id,
      page_url: page.url(),
      frame: this.frameLabel(page, frame),
      duration_ms: Date.now() - started,
      data,
      guidance: 'Esta análise evita varrer a página inteira. Para Telegram/Gamee, escolha o frame do jogo por frame_url_contains e capture WebSocket com ctf_game_runtime_capture.'
    };
  }

  async analyzePage(
    pageId = '',
    options: PageAnalysisOptions = {},
    onProgress?: (event: PageAnalysisProgress) => Promise<void> | void
  ): Promise<Record<string, unknown>> {
    const startedAt = Date.now();
    const page = await this.getPage(pageId);
    const id = this.registerPage(page);
    const stepTimeoutMs = Math.max(1_000, Math.min(options.stepTimeoutMs ?? 10_000, 20_000));
    const elementLimit = Math.max(1, Math.min(options.elementLimit ?? 200, 500));
    const scriptLimit = Math.max(1, Math.min(options.scriptLimit ?? 200, 500));
    const eventLimit = Math.max(1, Math.min(options.eventLimit ?? 80, 200));
    const maxTextChars = Math.max(1_000, Math.min(options.maxTextChars ?? 30_000, 120_000));
    const maxHtmlChars = Math.max(1_000, Math.min(options.maxHtmlChars ?? 40_000, 160_000));
    this.trimTransientBuffers(id, eventLimit);
    const total = options.includeHtml ? 5 : 4;
    const sections: Record<string, AnalysisSection> = {};

    const notify = async (progress: number, message: string): Promise<void> => {
      try { await onProgress?.({ progress, total, message }); } catch { /* Progress is best effort. */ }
    };

    const capture = async <T>(name: string, work: () => Promise<T> | T): Promise<AnalysisSection> => {
      const started = Date.now();
      try {
        const data = await withDeadline(work, stepTimeoutMs, `Análise: ${name}`);
        return { ok: true, duration_ms: Date.now() - started, data };
      } catch (error) {
        return { ok: false, duration_ms: Date.now() - started, error: error instanceof Error ? error.message : String(error) };
      }
    };

    await notify(0, 'Identificando a aba e o estado do documento.');
    sections.page = await capture('informações da página', () => this.pageInfo(id));
    await notify(1, 'Lendo DOM visível e elementos interativos.');

    const [snapshot, text] = await Promise.all([
      capture('snapshot interativo', () => this.snapshot(id, elementLimit)),
      capture('texto visível', () => this.getText('body', id, maxTextChars))
    ]);
    sections.snapshot = snapshot;
    sections.text = text;
    await notify(2, 'Mapeando scripts, estilos e frames.');

    const [scripts, stylesheets, frames] = await Promise.all([
      capture('scripts', () => this.listScripts(id, scriptLimit)),
      capture('stylesheets', () => this.listStylesheets(id, scriptLimit)),
      capture('frames', () => page.frames().map(frame => ({
        url: frame.url(),
        name: frame.name(),
        is_main: frame === page.mainFrame()
      })))
    ]);
    sections.scripts = scripts;
    sections.stylesheets = stylesheets;
    sections.frames = frames;
    await notify(3, 'Coletando console e tráfego recente.');

    const [consoleEvents, networkEvents] = await Promise.all([
      capture('console', () => this.recentConsole(id, eventLimit)),
      capture('rede', () => this.recentNetwork(id, eventLimit))
    ]);
    sections.console = consoleEvents;
    sections.network = networkEvents;

    if (options.includeHtml) {
      await notify(4, 'Capturando uma amostra limitada do HTML renderizado.');
      sections.html = await capture('HTML renderizado', () => this.getHtml('', id, maxHtmlChars));
    }

    await notify(total, 'Pacote de análise concluído.');
    const failedSections = Object.entries(sections).filter(([, section]) => !section.ok).map(([name]) => name);
    return {
      completed: true,
      partial: failedSections.length > 0,
      page_id: id,
      url: page.url(),
      started_at: new Date(startedAt).toISOString(),
      finished_at: new Date().toISOString(),
      duration_ms: Date.now() - startedAt,
      failed_sections: failedSections,
      guidance: failedSections.length > 0
        ? 'Continue usando as seções concluídas; repita somente as seções que falharam com as ferramentas específicas.'
        : 'Use este pacote para continuar a análise sem pesquisar ferramentas novamente.',
      sections
    };
  }

  async openAndAnalyze(
    url: string,
    options: PageAnalysisOptions = {},
    reuseExisting = true,
    onProgress?: (event: PageAnalysisProgress) => Promise<void> | void
  ): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    await this.ensureConnected();
    this.refreshPages();

    const requestedUrl = normalizeHttpUrlInput(url);
    let page: Page | undefined;
    let reused = false;

    if (reuseExisting) {
      page = [...this.pagesById.values()].find(candidate => {
        try { return new URL(candidate.url()).href === requestedUrl; } catch { return false; }
      });
      reused = Boolean(page);
    }

    if (!page) {
      page = await this.context!.newPage();
      this.registerPage(page);
    }

    const id = this.registerPage(page);
    this.activePageId = id;
    await page.bringToFront().catch(() => undefined);

    try { await onProgress?.({ progress: 0, total: options.includeHtml ? 6 : 5, message: reused ? 'Usando a aba que já contém a URL.' : 'Abrindo a URL no Edge isolado.' }); } catch { /* best effort */ }

    const navigationStarted = Date.now();
    let navigation: Record<string, unknown>;
    if (reused) {
      navigation = { ok: true, reused: true, duration_ms: 0, url: page.url() };
    } else {
      try {
        const response = await page.goto(requestedUrl, { waitUntil: 'domcontentloaded', timeout: 45_000 });
        navigation = {
          ok: true,
          reused: false,
          duration_ms: Date.now() - navigationStarted,
          status: response?.status() ?? null,
          url: page.url()
        };
      } catch (error) {
        navigation = {
          ok: false,
          reused: false,
          duration_ms: Date.now() - navigationStarted,
          url: page.url(),
          error: error instanceof Error ? error.message : String(error)
        };
      }
    }

    const analysis = await this.analyzePage(id, options, async event => {
      await onProgress?.({
        progress: event.progress + 1,
        total: event.total + 1,
        message: event.message
      });
    });

    return {
      completed: true,
      requested_url: requestedUrl,
      page_id: id,
      navigation,
      analysis
    };
  }


  async captureWebSocketFrames(options: WebSocketCaptureOptions = {}): Promise<Record<string, unknown>> {
    await this.ensureConnected();
    this.refreshPages();
    const durationMs = Math.max(1_000, Math.min(options.durationMs ?? 20_000, 120_000));
    const maxFrames = Math.max(1, Math.min(options.maxFrames ?? 80, 500));
    const maxPayloadBytes = Math.max(1, Math.min(options.maxPayloadBytes ?? 256, 4096));
    const includeSent = options.includeSent ?? true;
    const includeReceived = options.includeReceived ?? true;
    const urlContains = options.urlContains ?? '';

    let page: Page;
    let openedNewPage = false;
    const requestedUrl = options.url?.trim();
    if (requestedUrl) {
      page = await this.context!.newPage();
      openedNewPage = true;
      const id = this.registerPage(page);
      this.activePageId = id;
      await page.bringToFront().catch(() => undefined);
    } else {
      page = await this.getPage(options.pageId ?? '');
    }

    const pageId = this.registerPage(page);
    const sockets = new Map<string, { url: string; created_at: string; handshake_status?: number }>();
    const socketIds = new WeakMap<object, string>();
    const events: Record<string, unknown>[] = [];
    const frames: WebSocketCaptureFrame[] = [];

    const socketUrl = (requestId: string): string => sockets.get(requestId)?.url ?? '';
    const matches = (requestId: string, candidateUrl = ''): boolean => {
      if (!urlContains) return true;
      return (candidateUrl || socketUrl(requestId)).includes(urlContains);
    };

    const bytesForPayload = (payload: unknown): { bytes: Buffer; decodedAs: 'utf8' | 'base64' | 'raw-string'; opcode: number; text?: string } => {
      const raw = (payload as { payload?: unknown })?.payload ?? payload;
      if (Buffer.isBuffer(raw)) return { bytes: raw, decodedAs: 'base64', opcode: 2 };
      if (raw instanceof ArrayBuffer) return { bytes: Buffer.from(raw), decodedAs: 'base64', opcode: 2 };
      if (ArrayBuffer.isView(raw)) return { bytes: Buffer.from(raw.buffer, raw.byteOffset, raw.byteLength), decodedAs: 'base64', opcode: 2 };
      const text = String(raw ?? '');
      return { bytes: Buffer.from(text, 'utf8'), decodedAs: 'utf8', opcode: 1, text };
    };

    const addFrame = (direction: 'sent' | 'received', requestId: string, payload: unknown): void => {
      if ((direction === 'sent' && !includeSent) || (direction === 'received' && !includeReceived)) return;
      if (frames.length >= maxFrames) return;
      const url = socketUrl(requestId);
      if (!matches(requestId, url)) return;
      const { bytes, decodedAs, opcode, text } = bytesForPayload(payload);
      const sample = bytes.subarray(0, maxPayloadBytes);
      const item: WebSocketCaptureFrame = {
        direction,
        request_id: requestId,
        url,
        opcode,
        timestamp: Date.now() / 1000,
        payload_chars: text?.length ?? bytes.length,
        payload_bytes: bytes.length,
        decoded_as: decodedAs,
        sample_hex: sample.toString('hex'),
        sample_base64: sample.toString('base64'),
        truncated: bytes.length > maxPayloadBytes
      };
      if (text !== undefined) item.sample_text = text.slice(0, Math.min(300, maxPayloadBytes));
      frames.push(item);
    };

    const attachSocket = (socket: any): void => {
      const requestId = crypto.randomBytes(8).toString('base64url');
      socketIds.set(socket, requestId);
      const url = String(typeof socket.url === 'function' ? socket.url() : socket.url ?? '');
      sockets.set(requestId, { url, created_at: new Date().toISOString() });
      if (matches(requestId, url)) events.push({ type: 'created', request_id: requestId, url });
      socket.on('framesent', (payload: unknown) => addFrame('sent', requestId, payload));
      socket.on('framereceived', (payload: unknown) => addFrame('received', requestId, payload));
      socket.on('close', () => {
        if (matches(requestId)) events.push({ type: 'closed', request_id: requestId, url: socketUrl(requestId), timestamp: Date.now() / 1000 });
      });
      socket.on('socketerror', (error: unknown) => {
        if (matches(requestId)) events.push({ type: 'socket_error', request_id: requestId, url: socketUrl(requestId), error: String(error) });
      });
    };

    const onWebSocket = (socket: any): void => attachSocket(socket);
    page.on('websocket', onWebSocket);

    const startedAt = Date.now();
    try {
      if (requestedUrl) {
        await page.goto(normalizeHttpUrlInput(requestedUrl), { waitUntil: 'domcontentloaded', timeout: 45_000 }).catch(error => {
          events.push({ type: 'navigation_error', error: error instanceof Error ? error.message : String(error) });
        });
      } else if (options.reload) {
        await page.reload({ waitUntil: 'domcontentloaded', timeout: 45_000 }).catch(error => {
          events.push({ type: 'reload_error', error: error instanceof Error ? error.message : String(error) });
        });
      }
      const clickDelay = Math.max(0, Math.min(options.clickDelayMs ?? 0, 30_000));
      if (options.clickSelector || options.clickText) {
        if (clickDelay > 0) await new Promise(resolve => setTimeout(resolve, clickDelay));
        const clickResult = await this.clickInAnyFrame(page, { selector: options.clickSelector, text: options.clickText, timeoutMs: 8_000 });
        events.push({ type: 'optional_click', ...clickResult });
      }
      await new Promise(resolve => setTimeout(resolve, durationMs));
    } finally {
      page.off('websocket', onWebSocket);
    }

    return {
      mode: 'playwright_websocket_frame_capture_no_external_cdp',
      page_id: pageId,
      opened_new_page: openedNewPage,
      page_url: page.url(),
      duration_ms: Date.now() - startedAt,
      filter: { url_contains: urlContains || null, include_sent: includeSent, include_received: includeReceived },
      sockets: [...sockets].map(([request_id, value]) => ({ request_id, ...value })),
      events: events.slice(-200),
      frames_captured: frames.length,
      max_frames: maxFrames,
      max_payload_bytes: maxPayloadBytes,
      frames,
      guidance: frames.length === 0
        ? 'Nenhum frame foi capturado no intervalo. Rode novamente com duration_ms maior e entre na partida enquanto a ferramenta está ativa; use reload=true se o WebSocket nasce no carregamento.'
        : 'Use opcode, payload_bytes e sample_hex/sample_base64 para mapear o protocolo. A amostra é truncada por segurança de tamanho.'
    };
  }

  async openTab(url = 'about:blank'): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    await this.ensureConnected();
    const page = await this.context!.newPage();
    const id = this.registerPage(page);
    this.activePageId = id;
    if (url && url !== 'about:blank') await page.goto(normalizeHttpUrlInput(url), { waitUntil: 'domcontentloaded', timeout: 30_000 });
    return this.pageInfo(id);
  }

  async closeTab(pageId: string): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    await page.close();
    return { closed: pageId };
  }

  async switchTab(pageId: string): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    this.activePageId = pageId;
    await page.bringToFront();
    return this.pageInfo(pageId);
  }

  async navigate(url: string, pageId = '', waitUntil: 'load' | 'domcontentloaded' | 'networkidle' = 'domcontentloaded'): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    await page.goto(normalizeHttpUrlInput(url), { waitUntil, timeout: 45_000 });
    return this.pageInfo(this.registerPage(page));
  }

  async reload(pageId = ''): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 45_000 });
    return this.pageInfo(this.registerPage(page));
  }

  async goBack(pageId = ''): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    await page.goBack({ waitUntil: 'domcontentloaded', timeout: 30_000 });
    return this.pageInfo(this.registerPage(page));
  }

  async goForward(pageId = ''): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    await page.goForward({ waitUntil: 'domcontentloaded', timeout: 30_000 });
    return this.pageInfo(this.registerPage(page));
  }

  async snapshot(pageId = '', limit = 300): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const id = this.registerPage(page);
    const items = await page.evaluate((max) => {
      const isVisible = (el: Element): boolean => {
        const html = el as HTMLElement;
        const style = getComputedStyle(html);
        const rect = html.getBoundingClientRect();
        return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0;
      };
      const cssPath = (el: Element): string => {
        if (el.id) return `#${CSS.escape(el.id)}`;
        const parts: string[] = [];
        let current: Element | null = el;
        while (current && current !== document.documentElement && parts.length < 6) {
          let part = current.tagName.toLowerCase();
          const parentEl: Element | null = current.parentElement;
          if (parentEl) {
            const siblings = [...parentEl.children].filter(child => child.tagName === current!.tagName);
            if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
          }
          parts.unshift(part);
          current = parentEl;
        }
        return parts.join(' > ');
      };
      const selector = 'a,button,input,textarea,select,[role="button"],[role="link"],[tabindex]:not([tabindex="-1"])';
      return [...document.querySelectorAll(selector)].filter(isVisible).slice(0, max).map(el => {
        const html = el as HTMLInputElement;
        return {
          selector: cssPath(el),
          tag: el.tagName.toLowerCase(),
          text: (html.innerText || html.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 300),
          type: html.type || '',
          name: html.name || '',
          placeholder: html.placeholder || ''
        };
      });
    }, Math.max(1, Math.min(limit, 1000)));
    const refs = new Map<string, SnapshotRef>();
    const output = items.map((item, index) => {
      const ref = `e${index + 1}`;
      refs.set(ref, { selector: item.selector, text: item.text, tag: item.tag });
      return { ref, ...item };
    });
    this.snapshotRefs.set(id, refs);
    return { page_id: id, url: page.url(), elements: output };
  }

  private selectorFor(page: Page, ref: string, selector: string): string {
    if (selector) return selector;
    if (!ref) throw new Error('Informe ref ou selector.');
    const id = this.registerPage(page);
    const item = this.snapshotRefs.get(id)?.get(ref);
    if (!item) throw new Error('Ref inválida ou expirada. Gere browser_snapshot novamente.');
    return item.selector;
  }

  async click(options: { pageId?: string; ref?: string; selector?: string; text?: string }): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(options.pageId);
    if (options.text) await page.getByText(options.text, { exact: true }).first().click({ timeout: 15_000 });
    else await page.locator(this.selectorFor(page, options.ref ?? '', options.selector ?? '')).first().click({ timeout: 15_000 });
    return { clicked: true, page_id: this.registerPage(page), url: page.url() };
  }

  async fill(options: { pageId?: string; ref?: string; selector?: string; value: string }): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(options.pageId);
    await page.locator(this.selectorFor(page, options.ref ?? '', options.selector ?? '')).first().fill(options.value, { timeout: 15_000 });
    return { filled: true, page_id: this.registerPage(page) };
  }

  async typeText(options: { pageId?: string; ref?: string; selector?: string; value: string; delayMs?: number }): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(options.pageId);
    await page.locator(this.selectorFor(page, options.ref ?? '', options.selector ?? '')).first().pressSequentially(options.value, { delay: options.delayMs ?? 0, timeout: 30_000 });
    return { typed: true, page_id: this.registerPage(page) };
  }

  async press(key: string, pageId = '', selector = ''): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    if (selector) await page.locator(selector).first().press(key);
    else await page.keyboard.press(key);
    return { pressed: key, page_id: this.registerPage(page) };
  }

  async selectOption(selector: string, values: string[], pageId = ''): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    const selected = await page.locator(selector).first().selectOption(values);
    return { selected, page_id: this.registerPage(page) };
  }

  async hover(selector: string, pageId = ''): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    await page.locator(selector).first().hover();
    return { hovered: selector, page_id: this.registerPage(page) };
  }

  async scroll(deltaX = 0, deltaY = 700, pageId = ''): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowBrowserActions');
    const page = await this.getPage(pageId);
    await page.mouse.wheel(deltaX, deltaY);
    return { scrolled: { delta_x: deltaX, delta_y: deltaY }, page_id: this.registerPage(page) };
  }

  async getText(selector = 'body', pageId = '', maxChars = 200_000): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const text = await page.locator(selector).first().innerText({ timeout: 15_000 });
    return { page_id: this.registerPage(page), selector, text: text.slice(0, maxChars), truncated: text.length > maxChars };
  }

  async getHtml(selector = '', pageId = '', maxChars = 500_000): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const html = selector ? await page.locator(selector).first().evaluate(el => el.outerHTML) : await page.content();
    return { page_id: this.registerPage(page), selector: selector || 'document', html: html.slice(0, maxChars), truncated: html.length > maxChars };
  }

  async screenshot(pageId = '', fullPage = false): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const id = this.registerPage(page);
    const filename = `screenshot-${new Date().toISOString().replaceAll(':', '-')}-${id}.png`;
    const output = path.join(getPaths().artifactsDir, filename);
    fs.mkdirSync(path.dirname(output), { recursive: true });
    await page.screenshot({ path: output, fullPage });
    return { page_id: id, path: output, filename, full_page: fullPage };
  }

  async listScripts(pageId = '', limit = 300): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const scripts = await page.evaluate(max => [...document.scripts].slice(0, max).map((script, index) => ({ index, src: script.src, type: script.type, async: script.async, defer: script.defer, inline_chars: script.src ? 0 : (script.textContent?.length ?? 0) })), Math.max(1, Math.min(limit, 1000)));
    return { page_id: this.registerPage(page), scripts };
  }

  async readInlineScript(index: number, pageId = '', maxChars = 200_000): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const source = await page.evaluate(i => {
      const script = document.scripts.item(i);
      if (!script) throw new Error('Índice de script inválido.');
      if (script.src) throw new Error('Este script é externo. Use source_fetch_url.');
      return script.textContent ?? '';
    }, index);
    return { page_id: this.registerPage(page), index, source: source.slice(0, maxChars), truncated: source.length > maxChars };
  }

  async listStylesheets(pageId = '', limit = 300): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const stylesheets = await page.evaluate(max => [...document.styleSheets].slice(0, max).map((sheet, index) => {
      let rules: number | null = null;
      try { rules = sheet.cssRules.length; } catch { rules = null; }
      return { index, href: sheet.href, disabled: sheet.disabled, rules };
    }), Math.max(1, Math.min(limit, 1000)));
    return { page_id: this.registerPage(page), stylesheets };
  }

  async recentConsole(pageId = '', limit = 100): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const id = this.registerPage(page);
    return { page_id: id, events: (this.consoleEvents.get(id) ?? []).slice(-Math.max(1, Math.min(limit, 500))) };
  }

  async recentNetwork(pageId = '', limit = 100, urlContains = '', phase = ''): Promise<Record<string, unknown>> {
    const page = await this.getPage(pageId);
    const id = this.registerPage(page);
    let events = this.networkEvents.get(id) ?? [];
    if (urlContains) events = events.filter(event => event.url.includes(urlContains));
    if (phase) events = events.filter(event => event.phase === phase);
    return { page_id: id, events: events.slice(-Math.max(1, Math.min(limit, 500))) };
  }

  async evaluate(expression: string, pageId = '', timeoutMs = 15_000): Promise<Record<string, unknown>> {
    this.runtime.assertEnabled('allowDirectJavaScript', 'JavaScript direto está desativado no painel.');
    const page = await this.getPage(pageId);
    const result = await Promise.race([
      page.evaluate(code => (0, eval)(code), expression),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Tempo limite do JavaScript excedido.')), Math.max(250, Math.min(timeoutMs, 120_000))))
    ]);
    return { page_id: this.registerPage(page), result: safeSerializable(result) };
  }

  async runSavedScript(source: string, options: { pageId?: string; allowedNetworkHosts: string[]; allowGlobalHosts: boolean; timeoutMs?: number }): Promise<Record<string, unknown>> {
    const page = await this.getPage(options.pageId);
    const result = await Promise.race([
      page.evaluate(code => (0, eval)(code), source),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Tempo limite do script excedido.')), Math.max(250, Math.min(options.timeoutMs ?? 30_000, 120_000))))
    ]);
    return { page_id: this.registerPage(page), url: page.url(), result: safeSerializable(result) };
  }


}

function safeSerializable(value: unknown): unknown {
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return String(value);
  }
}
