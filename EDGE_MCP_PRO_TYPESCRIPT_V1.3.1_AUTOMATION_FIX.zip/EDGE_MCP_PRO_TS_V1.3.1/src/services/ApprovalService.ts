import crypto from 'node:crypto';
import { getPaths } from '../core/paths.js';
import { readJson, writeJsonAtomic } from '../core/json.js';
import type { AuditLog } from '../core/audit.js';

export interface ApprovalRecord {
  id: string;
  tool: string;
  fingerprint: string;
  summary: string;
  risk: string;
  status: 'pending' | 'approved' | 'denied' | 'consumed';
  createdAt: string;
  decidedAt?: string;
}

export class ApprovalService {
  private records: ApprovalRecord[];

  constructor(private readonly audit: AuditLog) {
    this.records = readJson<ApprovalRecord[]>(getPaths().approvalsFile, []);
    this.prune();
  }

  private fingerprint(tool: string, payload: unknown): string {
    return crypto.createHash('sha256').update(JSON.stringify({ tool, payload })).digest('hex');
  }

  require(tool: string, payload: unknown, summary: string, risk: string, approvalId = ''): { approved: true } | { approved: false; response: Record<string, unknown> } {
    const fingerprint = this.fingerprint(tool, payload);
    if (approvalId) {
      const record = this.records.find(item => item.id === approvalId);
      if (!record || record.tool !== tool || record.fingerprint !== fingerprint) {
        return { approved: false, response: { approval_required: true, error: 'A aprovação não corresponde a esta ação.' } };
      }
      if (record.status !== 'approved') {
        return { approved: false, response: { approval_required: true, approval_id: record.id, status: record.status } };
      }
      record.status = 'consumed';
      record.decidedAt = new Date().toISOString();
      this.save();
      this.audit.write({ actor: 'mcp', action: 'approval_consumed', subject: record.id, details: { tool } });
      return { approved: true };
    }

    const existing = this.records.find(item => item.tool === tool && item.fingerprint === fingerprint && item.status === 'pending');
    const record = existing ?? {
      id: crypto.randomBytes(18).toString('base64url'),
      tool,
      fingerprint,
      summary,
      risk,
      status: 'pending' as const,
      createdAt: new Date().toISOString()
    };
    if (!existing) {
      this.records.push(record);
      this.save();
      this.audit.write({ actor: 'mcp', action: 'approval_requested', subject: record.id, details: { tool, summary, risk } });
    }
    return {
      approved: false,
      response: {
        approval_required: true,
        approval_id: record.id,
        summary,
        risk,
        instructions: 'Abra o painel local, aprove esta solicitação uma vez e repita a chamada com approval_id.'
      }
    };
  }

  list(): ApprovalRecord[] {
    this.prune();
    return [...this.records].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  decide(id: string, approved: boolean): ApprovalRecord {
    const record = this.records.find(item => item.id === id);
    if (!record) throw new Error('Aprovação não encontrada.');
    if (record.status !== 'pending') throw new Error('Esta aprovação já foi decidida.');
    record.status = approved ? 'approved' : 'denied';
    record.decidedAt = new Date().toISOString();
    this.save();
    this.audit.write({ actor: 'dashboard', action: approved ? 'approval_approved' : 'approval_denied', subject: id, details: { tool: record.tool } });
    return record;
  }

  private prune(): void {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    this.records = this.records.filter(item => item.status === 'pending' || new Date(item.createdAt).getTime() >= cutoff);
    this.save();
  }

  private save(): void {
    writeJsonAtomic(getPaths().approvalsFile, this.records);
  }
}
