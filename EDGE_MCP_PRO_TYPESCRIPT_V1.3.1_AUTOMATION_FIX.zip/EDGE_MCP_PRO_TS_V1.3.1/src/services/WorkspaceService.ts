import fs from 'node:fs';
import path from 'node:path';
import { getPaths, safeJoin } from '../core/paths.js';

export interface WorkspaceEntry {
  path: string;
  type: 'file' | 'directory';
  bytes?: number;
  modifiedAt: string;
}

export class WorkspaceService {
  private readonly root = getPaths().workspaceDir;

  constructor(private readonly maxBytes: number) {
    fs.mkdirSync(this.root, { recursive: true });
  }

  resolve(relativePath: string): string {
    return safeJoin(this.root, relativePath);
  }

  list(relativePath = '.', recursive = true, limit = 300): WorkspaceEntry[] {
    const start = safeJoin(this.root, relativePath === '.' ? '' : relativePath);
    if (!fs.existsSync(start)) return [];
    const out: WorkspaceEntry[] = [];
    const walk = (dir: string): void => {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        if (out.length >= limit) return;
        const absolute = path.join(dir, entry.name);
        const stat = fs.statSync(absolute);
        const rel = path.relative(this.root, absolute).replaceAll('\\', '/');
        out.push({ path: rel, type: entry.isDirectory() ? 'directory' : 'file', bytes: entry.isFile() ? stat.size : undefined, modifiedAt: stat.mtime.toISOString() });
        if (recursive && entry.isDirectory()) walk(absolute);
      }
    };
    if (fs.statSync(start).isDirectory()) walk(start);
    else {
      const stat = fs.statSync(start);
      out.push({ path: path.relative(this.root, start).replaceAll('\\', '/'), type: 'file', bytes: stat.size, modifiedAt: stat.mtime.toISOString() });
    }
    return out;
  }

  read(relativePath: string, offset = 0, maxChars = 200_000): { path: string; content: string; bytes: number; truncated: boolean } {
    const absolute = this.resolve(relativePath);
    const stat = fs.statSync(absolute);
    if (!stat.isFile()) throw new Error('O caminho não é um arquivo.');
    if (stat.size > this.maxBytes) throw new Error(`Arquivo maior que o limite de ${this.maxBytes} bytes.`);
    const text = fs.readFileSync(absolute, 'utf8');
    const content = text.slice(Math.max(0, offset), Math.max(0, offset) + Math.max(1, maxChars));
    return { path: relativePath.replaceAll('\\', '/'), content, bytes: stat.size, truncated: offset + content.length < text.length };
  }

  write(relativePath: string, content: string, overwrite = false): { path: string; bytes: number; created: boolean } {
    if (Buffer.byteLength(content, 'utf8') > this.maxBytes) throw new Error(`Conteúdo maior que ${this.maxBytes} bytes.`);
    const absolute = this.resolve(relativePath);
    const existed = fs.existsSync(absolute);
    if (existed && !overwrite) throw new Error('O arquivo já existe. Use overwrite=true para substituir.');
    fs.mkdirSync(path.dirname(absolute), { recursive: true });
    const tmp = `${absolute}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, content, 'utf8');
    fs.renameSync(tmp, absolute);
    return { path: path.relative(this.root, absolute).replaceAll('\\', '/'), bytes: Buffer.byteLength(content, 'utf8'), created: !existed };
  }

  delete(relativePath: string): { deleted: string } {
    const absolute = this.resolve(relativePath);
    if (!fs.existsSync(absolute)) throw new Error('Arquivo não encontrado.');
    const stat = fs.statSync(absolute);
    if (stat.isDirectory()) {
      if (fs.readdirSync(absolute).length > 0) throw new Error('Somente diretórios vazios podem ser removidos.');
      fs.rmdirSync(absolute);
    } else {
      fs.unlinkSync(absolute);
    }
    return { deleted: relativePath.replaceAll('\\', '/') };
  }

  search(query: string, relativePath = '.', limit = 100): Array<{ path: string; line: number; text: string }> {
    const needle = query.toLowerCase();
    if (!needle) return [];
    const matches: Array<{ path: string; line: number; text: string }> = [];
    for (const entry of this.list(relativePath, true, 1000)) {
      if (entry.type !== 'file' || matches.length >= limit) continue;
      if ((entry.bytes ?? 0) > this.maxBytes) continue;
      const absolute = this.resolve(entry.path);
      let text: string;
      try { text = fs.readFileSync(absolute, 'utf8'); } catch { continue; }
      text.split(/\r?\n/).forEach((line, index) => {
        if (matches.length < limit && line.toLowerCase().includes(needle)) matches.push({ path: entry.path, line: index + 1, text: line.slice(0, 500) });
      });
    }
    return matches;
  }
}
