import { writeJsonAtomic, readJson } from '../core/json.js';
import { getPaths } from '../core/paths.js';
import type { RuntimeSettingsStore } from '../core/settings.js';
import type { AuditLog } from '../core/audit.js';
import type { EdgeController } from '../edge/EdgeController.js';
import type { ScriptService } from './ScriptService.js';

interface AutoRunEvent {
  at: string;
  scriptId: string;
  pageId: string;
  url: string;
  success: boolean;
  error?: string;
}

export class AutoRunService {
  private timer?: NodeJS.Timeout;
  private readonly seen = new Map<string, string>();
  private events = readJson<AutoRunEvent[]>(getPaths().autorunFile, []);

  constructor(
    private readonly runtime: RuntimeSettingsStore,
    private readonly scripts: ScriptService,
    private readonly edge: EdgeController,
    private readonly audit: AuditLog
  ) {}

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.tick(), 1500);
    this.timer.unref();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = undefined;
  }

  status(): Record<string, unknown> {
    return {
      running: Boolean(this.timer),
      enabled: this.runtime.get().autoRunTrustedScripts,
      armed_scripts: this.scripts.list().filter(script => script.autoRun && script.trusted && script.enabled).map(script => ({ id: script.id, allowed_page_hosts: script.allowedPageHosts })),
      recent: this.events.slice(-50).reverse()
    };
  }

  private async tick(): Promise<void> {
    const settings = this.runtime.get();
    if (!settings.autoRunTrustedScripts || !settings.allowSavedScripts) return;
    try {
      const tabs = await this.edge.listTabs();
      const scripts = this.scripts.list().filter(script => script.autoRun && script.trusted && script.enabled);
      for (const tab of tabs) {
        const pageId = String(tab.page_id ?? '');
        const url = String(tab.url ?? '');
        if (!pageId || !url.startsWith('http')) continue;
        for (const scriptMeta of scripts) {
          const key = `${scriptMeta.id}:${pageId}`;
          const signature = `${url}:${scriptMeta.sha256}`;
          if (this.seen.get(key) === signature) continue;
          try {
            const script = this.scripts.get(scriptMeta.id, true);
            this.scripts.assertRunnable(script, url, true);
            const result = await this.edge.runSavedScript(script.source ?? '', {
              pageId,
              allowedNetworkHosts: ['*'],
              allowGlobalHosts: true,
              timeoutMs: 30_000
            });
            this.seen.set(key, signature);
            this.record({ at: new Date().toISOString(), scriptId: script.id, pageId, url, success: true });
            this.audit.write({ actor: 'system', action: 'site_script_autorun_success', subject: script.id, details: { pageId, url, result } });
          } catch (error) {
            this.seen.set(key, signature);
            const message = error instanceof Error ? error.message : String(error);
            this.record({ at: new Date().toISOString(), scriptId: scriptMeta.id, pageId, url, success: false, error: message });
            this.audit.write({ actor: 'system', action: 'site_script_autorun_failed', subject: scriptMeta.id, details: { pageId, url, error: message } });
          }
        }
      }
    } catch {
      // Edge may be closed. The next interval retries.
    }
  }

  private record(event: AutoRunEvent): void {
    this.events.push(event);
    if (this.events.length > 500) this.events.splice(0, this.events.length - 500);
    writeJsonAtomic(getPaths().autorunFile, this.events);
  }
}
