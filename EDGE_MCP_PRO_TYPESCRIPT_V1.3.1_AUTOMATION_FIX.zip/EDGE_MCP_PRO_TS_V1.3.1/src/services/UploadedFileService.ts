import { assertSafeRemoteUrl } from '../core/security.js';

export interface UploadedFileObject {
  download_url?: string;
  file_id?: string;
  mime_type?: string;
  file_name?: string;
}

export class UploadedFileService {
  constructor(private readonly maxBytes: number) {}

  async downloadJavaScript(file: UploadedFileObject): Promise<{ text: string; name: string; fileId: string; mimeType: string; bytes: number }> {
    const downloadUrl = file.download_url?.trim();
    if (!downloadUrl) throw new Error('O anexo não contém download_url.');
    const url = await assertSafeRemoteUrl(downloadUrl, false);
    const response = await fetch(url, { redirect: 'follow', signal: AbortSignal.timeout(30_000) });
    if (!response.ok) throw new Error(`Falha ao baixar anexo: HTTP ${response.status}.`);
    const declared = Number(response.headers.get('content-length') ?? 0);
    if (declared > this.maxBytes) throw new Error('O anexo excede o limite permitido.');
    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.length < 1) throw new Error('O anexo está vazio.');
    if (buffer.length > this.maxBytes) throw new Error('O anexo excede o limite permitido.');
    if (buffer.includes(0)) throw new Error('O anexo parece binário.');
    const name = (file.file_name || 'script.js').trim();
    if (!name.toLowerCase().endsWith('.js')) throw new Error('Somente arquivos .js são aceitos.');
    const text = buffer.toString('utf8');
    if (!text.trim()) throw new Error('O JavaScript está vazio.');
    return { text, name, fileId: file.file_id ?? '', mimeType: file.mime_type ?? 'text/javascript', bytes: buffer.length };
  }
}
