import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { getPaths, safeJoin } from '../core/paths.js';
import { readJson, writeJsonAtomic } from '../core/json.js';
import { normalizeHostname } from '../core/security.js';

export type ScriptProfile = 'visual_preview' | 'authorized_web_test' | 'review_required';

export interface ScriptRecord {
  id: string;
  name: string;
  description: string;
  file: string;
  sha256: string;
  bytes: number;
  enabled: boolean;
  trusted: boolean;
  autoRun: boolean;
  allowedPageHosts: string[];
  allowedNetworkHosts: string[];
  profile: ScriptProfile;
  reviewFlags: string[];
  origin: 'workspace' | 'upload' | 'dashboard';
  createdAt: string;
  updatedAt: string;
}

const NETWORK_PATTERNS: Array<[RegExp, string]> = [
  [/\bfetch\s*\(/i, 'fetch'],
  [/\bXMLHttpRequest\b/i, 'XMLHttpRequest'],
  [/\bWebSocket\b/i, 'WebSocket'],
  [/\bEventSource\b/i, 'EventSource'],
  [/\bsendBeacon\s*\(/i, 'sendBeacon'],
  [/\blocalStorage\b|\bsessionStorage\b|\bindexedDB\b|\bcaches\b/i, 'browser_storage']
];

const REVIEW_PATTERNS: Array<[RegExp, string]> = [
  [/\beval\s*\(/i, 'eval'],
  [/\bnew\s+Function\b|\bFunction\s*\(/i, 'dynamic_function'],
  [/\bWorker\s*\(|\bSharedWorker\s*\(/i, 'worker'],
  [/\blocation\s*=|location\.(assign|replace)\s*\(/i, 'navigation'],
  [/\.submit\s*\(|requestSubmit\s*\(/i, 'form_submit']
];

function cleanId(value: string): string {
  const id = value.trim().toLowerCase().replace(/\.js$/i, '').replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
  if (!id || id.length > 100) throw new Error('script_id inválido. Use letras, números, hífen ou underscore.');
  return id;
}

function normalizePatterns(values: string[]): string[] {
  const out = [...new Set(values.map(normalizeHostname).filter(Boolean))];
  for (const value of out) {
    if (value !== '*' && !/^\*\.[a-z0-9.-]+$/.test(value) && !/^[a-z0-9.-]+$/.test(value)) {
      throw new Error(`Host inválido: ${value}`);
    }
  }
  return out;
}

export class ScriptService {
  private records: ScriptRecord[];
  private readonly scriptsDir = getPaths().scriptsDir;

  constructor(private readonly maxBytes: number) {
    fs.mkdirSync(this.scriptsDir, { recursive: true });
    this.records = readJson<ScriptRecord[]>(getPaths().scriptsIndexFile, []);
  }

  analyze(source: string): { profile: ScriptProfile; reviewFlags: string[] } {
    const reviewFlags = REVIEW_PATTERNS.filter(([pattern]) => pattern.test(source)).map(([, label]) => label);
    if (reviewFlags.length) return { profile: 'review_required', reviewFlags };
    const networkFlags = NETWORK_PATTERNS.filter(([pattern]) => pattern.test(source)).map(([, label]) => label);
    return { profile: networkFlags.length ? 'authorized_web_test' : 'visual_preview', reviewFlags: networkFlags };
  }

  list(): ScriptRecord[] {
    return this.records.map(item => this.withIntegrity(item));
  }

  get(id: string, includeSource = false): ScriptRecord & { source?: string; integrityOk: boolean } {
    const record = this.records.find(item => item.id === cleanId(id));
    if (!record) throw new Error('Script não encontrado.');
    const enriched = this.withIntegrity(record);
    return includeSource ? { ...enriched, source: fs.readFileSync(this.absolute(record.file), 'utf8') } : enriched;
  }

  registerWorkspaceFile(options: {
    path: string;
    scriptId?: string;
    name?: string;
    description?: string;
    allowedPageHosts?: string[];
    allowedNetworkHosts?: string[];
    trusted?: boolean;
    origin?: ScriptRecord['origin'];
  }): ScriptRecord {
    const relative = options.path.replaceAll('\\', '/').replace(/^\/+/, '');
    if (!relative.startsWith('site-scripts/') || !relative.toLowerCase().endsWith('.js')) {
      throw new Error('O arquivo precisa estar em site-scripts/<nome>.js.');
    }
    const absolute = safeJoin(getPaths().workspaceDir, relative);
    const source = fs.readFileSync(absolute, 'utf8');
    return this.saveSource({
      source,
      scriptId: options.scriptId || path.basename(relative, '.js'),
      name: options.name,
      description: options.description,
      allowedPageHosts: options.allowedPageHosts,
      allowedNetworkHosts: options.allowedNetworkHosts,
      trusted: options.trusted,
      origin: options.origin ?? 'workspace'
    });
  }

  saveSource(options: {
    source: string;
    scriptId: string;
    name?: string;
    description?: string;
    allowedPageHosts?: string[];
    allowedNetworkHosts?: string[];
    trusted?: boolean;
    origin?: ScriptRecord['origin'];
  }): ScriptRecord {
    const bytes = Buffer.byteLength(options.source, 'utf8');
    if (bytes < 1) throw new Error('O JavaScript está vazio.');
    if (bytes > this.maxBytes) throw new Error(`Script maior que ${this.maxBytes} bytes.`);
    if (options.source.includes('\0')) throw new Error('O arquivo parece binário.');
    const id = cleanId(options.scriptId);
    const file = `${id}.js`;
    const absolute = this.absolute(file);
    const now = new Date().toISOString();
    const existing = this.records.find(item => item.id === id);
    const analysis = this.analyze(options.source);
    const record: ScriptRecord = {
      id,
      name: options.name?.trim() || id.replaceAll('-', ' ').replaceAll('_', ' ').replace(/\b\w/g, char => char.toUpperCase()),
      description: options.description?.trim() || 'Script JavaScript local.',
      file,
      sha256: crypto.createHash('sha256').update(options.source).digest('hex'),
      bytes,
      enabled: existing?.enabled ?? true,
      trusted: options.trusted ?? existing?.trusted ?? false,
      autoRun: existing?.autoRun ?? false,
      allowedPageHosts: normalizePatterns(options.allowedPageHosts ?? existing?.allowedPageHosts ?? ['*']),
      allowedNetworkHosts: normalizePatterns(options.allowedNetworkHosts ?? existing?.allowedNetworkHosts ?? ['*']),
      profile: analysis.profile,
      reviewFlags: analysis.reviewFlags,
      origin: options.origin ?? existing?.origin ?? 'workspace',
      createdAt: existing?.createdAt ?? now,
      updatedAt: now
    };
    fs.mkdirSync(path.dirname(absolute), { recursive: true });
    const tmp = `${absolute}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, options.source, 'utf8');
    fs.renameSync(tmp, absolute);
    this.records = [...this.records.filter(item => item.id !== id), record];
    this.save();
    return record;
  }

  update(id: string, patch: Partial<Pick<ScriptRecord, 'name' | 'description' | 'enabled' | 'trusted' | 'autoRun' | 'allowedPageHosts' | 'allowedNetworkHosts'>>): ScriptRecord {
    const normalizedId = cleanId(id);
    const index = this.records.findIndex(item => item.id === normalizedId);
    if (index < 0) throw new Error('Script não encontrado.');
    const current = this.records[index]!;
    const cleanPatch = Object.fromEntries(Object.entries(patch).filter(([, value]) => value !== undefined)) as typeof patch;
    const next: ScriptRecord = {
      ...current,
      ...cleanPatch,
      allowedPageHosts: patch.allowedPageHosts ? normalizePatterns(patch.allowedPageHosts) : current.allowedPageHosts,
      allowedNetworkHosts: patch.allowedNetworkHosts ? normalizePatterns(patch.allowedNetworkHosts) : current.allowedNetworkHosts,
      updatedAt: new Date().toISOString()
    };
    this.records[index] = next;
    this.save();
    return next;
  }

  remove(id: string): void {
    const record = this.get(id);
    const absolute = this.absolute(record.file);
    if (fs.existsSync(absolute)) fs.unlinkSync(absolute);
    this.records = this.records.filter(item => item.id !== record.id);
    this.save();
  }

  assertRunnable(record: ScriptRecord, pageUrl: string, allowGlobal: boolean): string {
    if (!record.enabled) throw new Error('O script está desativado.');
    const current = this.withIntegrity(record);
    if (!current.integrityOk) throw new Error('O checksum mudou. Registre o script novamente.');
    const url = new URL(pageUrl);
    // No modo local liberado, o escopo de hosts é apenas informativo.
    // Mantemos a validação de URL para retornar um hostname legível.
    return url.hostname || url.protocol.replace(':', '') || 'local';
  }

  private withIntegrity(record: ScriptRecord): ScriptRecord & { integrityOk: boolean } {
    try {
      const source = fs.readFileSync(this.absolute(record.file));
      const hash = crypto.createHash('sha256').update(source).digest('hex');
      return { ...record, integrityOk: hash === record.sha256 };
    } catch {
      return { ...record, integrityOk: false };
    }
  }

  private absolute(file: string): string {
    return safeJoin(this.scriptsDir, file);
  }

  private save(): void {
    writeJsonAtomic(getPaths().scriptsIndexFile, this.records);
  }
}
