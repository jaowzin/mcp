import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express, { type NextFunction, type Request, type Response } from 'express';
import multer from 'multer';
import type { AppContext } from '../core/context.js';
import { APP_VERSION } from '../core/version.js';
import { activitySnapshot } from '../core/activity.js';
import { withDeadline } from '../core/deadline.js';

function isLocalHostHeader(hostHeader: string | undefined): boolean {
  const host = (hostHeader ?? '').toLowerCase().split(':')[0]?.replace(/^\[|\]$/g, '');
  return host === '127.0.0.1' || host === 'localhost' || host === '::1';
}

function localAdminGuard(ctx: AppContext) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!isLocalHostHeader(req.headers.host)) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    const token = String(req.query.token ?? req.headers['x-edge-mcp-admin-token'] ?? '');
    if (token !== ctx.identity.dashboardToken) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    next();
  };
}

export function createAdminRouter(ctx: AppContext): express.Router {
  const router = express.Router();
  const guard = localAdminGuard(ctx);
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: ctx.config.maxFileBytes, files: 1 } });
  const publicDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'public');

  router.get('/dashboard', guard, (_req, res) => {
    res.type('html').send(fs.readFileSync(path.join(publicDir, 'index.html'), 'utf8').replaceAll('__TOKEN__', encodeURIComponent(ctx.identity.dashboardToken)));
  });
  router.get('/admin/assets/app.css', guard, (_req, res) => res.type('text/css').send(fs.readFileSync(path.join(publicDir, 'app.css'), 'utf8')));
  router.get('/admin/assets/app.js', guard, (_req, res) => res.type('application/javascript').send(fs.readFileSync(path.join(publicDir, 'app.js'), 'utf8')));

  router.get('/admin/api/overview', guard, async (_req, res) => {
    const [edge, tabs] = await Promise.all([
      withDeadline(() => ctx.edge.status(), 5_000, 'Status do Edge').catch(error => ({ connected: false, error: error instanceof Error ? error.message : String(error) })),
      withDeadline(() => ctx.edge.listTabs(), 7_000, 'Lista de abas').catch(() => [])
    ]);
    res.json({
      version: APP_VERSION,
      config: ctx.config,
      mcpUrl: `${ctx.config.publicBaseUrl}${ctx.identity.mcpPath}`,
      settings: ctx.runtime.get(),
      edge,
      tabs,
      activity: activitySnapshot(),
      scripts: ctx.scripts.list(),
      approvals: ctx.approvals.list(),
      autorun: ctx.autorun.status(),
      audit: ctx.audit.recent(100)
    });
  });

  router.patch('/admin/api/settings', guard, express.json(), (req, res) => {
    try {
      const settings = ctx.runtime.update(req.body ?? {});
      ctx.audit.write({ actor: 'dashboard', action: 'runtime_settings_updated', details: { keys: Object.keys(req.body ?? {}) } });
      res.json(settings);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : String(error) });
    }
  });

  router.post('/admin/api/approvals/:id/:decision', guard, (req, res) => {
    try {
      const approved = req.params.decision === 'approve';
      if (!approved && req.params.decision !== 'deny') throw new Error('Decisão inválida.');
      res.json(ctx.approvals.decide(String(req.params.id), approved));
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : String(error) });
    }
  });

  router.post('/admin/api/scripts/import', guard, upload.single('file'), express.json(), (req, res) => {
    try {
      if (!req.file) throw new Error('Selecione um arquivo .js.');
      if (!req.file.originalname.toLowerCase().endsWith('.js')) throw new Error('Somente arquivos .js são aceitos.');
      if (!req.file.buffer.length) throw new Error('O arquivo está vazio.');
      if (req.file.buffer.includes(0)) throw new Error('O arquivo parece binário.');
      const source = req.file.buffer.toString('utf8');
      const body = req.body as Record<string, string>;
      const parseHosts = (value = '') => value.split(/[\n,]/).map(item => item.trim()).filter(Boolean);
      const record = ctx.scripts.saveSource({
        source,
        scriptId: body.script_id || req.file.originalname.replace(/\.js$/i, ''),
        name: body.name || undefined,
        description: body.description || `Importado pelo painel: ${req.file.originalname}`,
        allowedPageHosts: parseHosts(body.allowed_page_hosts),
        allowedNetworkHosts: parseHosts(body.allowed_network_hosts),
        trusted: body.trusted === 'true',
        origin: 'dashboard'
      });
      ctx.audit.write({ actor: 'dashboard', action: 'site_script_imported', subject: record.id, details: { bytes: record.bytes, sha256: record.sha256 } });
      res.json(record);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : String(error) });
    }
  });

  router.patch('/admin/api/scripts/:id', guard, express.json(), (req, res) => {
    try {
      const record = ctx.scripts.update(String(req.params.id), req.body ?? {});
      ctx.audit.write({ actor: 'dashboard', action: 'site_script_updated', subject: record.id });
      res.json(record);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : String(error) });
    }
  });

  router.delete('/admin/api/scripts/:id', guard, (req, res) => {
    try {
      ctx.scripts.remove(String(req.params.id));
      ctx.audit.write({ actor: 'dashboard', action: 'site_script_removed', subject: String(req.params.id) });
      res.json({ removed: String(req.params.id) });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : String(error) });
    }
  });

  router.post('/admin/api/scripts/:id/run', guard, express.json(), async (req, res) => {
    try {
      ctx.runtime.assertEnabled('allowSavedScripts');
      const script = ctx.scripts.get(String(req.params.id), true);
      const pageId = String(req.body?.page_id ?? '');
      const page = await ctx.edge.pageInfo(pageId);
      const settings = ctx.runtime.get();
      ctx.scripts.assertRunnable(script, String(page.url ?? ''), true);
      const result = await ctx.edge.runSavedScript(script.source ?? '', {
        pageId: String(page.page_id ?? pageId),
        allowedNetworkHosts: ['*'],
        allowGlobalHosts: true,
        timeoutMs: 60_000
      });
      ctx.audit.write({ actor: 'dashboard', action: 'site_script_executed', subject: script.id, details: { page_id: page.page_id, url: page.url } });
      res.json({ executed: true, ...result });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : String(error) });
    }
  });

  return router;
}
