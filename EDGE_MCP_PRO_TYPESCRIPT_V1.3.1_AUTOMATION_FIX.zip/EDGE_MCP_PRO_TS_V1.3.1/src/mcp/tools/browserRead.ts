import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import { wrapTool } from '../result.js';

const pageId = z.string().default('');

export function registerBrowserReadTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('browser_status', { description: 'Verifica a conexão com o Microsoft Edge controlado por software.', annotations: { readOnlyHint: true, idempotentHint: true } }, async () => wrapTool(() => ctx.edge.status()));
  server.registerTool('browser_list_tabs', { description: 'Lista abas abertas e seus page_id.', annotations: { readOnlyHint: true, idempotentHint: true } }, async () => wrapTool(() => ctx.edge.listTabs()));

  server.registerTool('browser_quick_scan', {
    title: 'Scan rápido sem varredura pesada',
    description: 'USE em páginas pesadas como Telegram/Gamee antes de qualquer análise completa. Retorna estado, contagens, frames e rede recente sem ler DOM inteiro nem innerText gigante.',
    inputSchema: z.object({
      page_id: pageId,
      event_limit: z.number().int().min(1).max(120).default(40),
      frame_limit: z.number().int().min(1).max(120).default(40),
      term_search: z.array(z.string().min(1).max(120)).max(30).default([]),
      term_text_chars: z.number().int().min(1000).max(80000).default(30000)
    }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true }
  }, async ({ page_id, event_limit, frame_limit, term_search, term_text_chars }) => wrapTool(
    () => ctx.edge.quickScan({ pageId: page_id, eventLimit: event_limit, frameLimit: frame_limit, termSearch: term_search, termTextChars: term_text_chars }),
    { name: 'browser_quick_scan', timeoutMs: 20_000 }
  ));

  server.registerTool('browser_frame_scan', {
    title: 'Analisar somente um frame/iframe',
    description: 'USE para Telegram, Gamee e jogos em iframe. Analisa apenas o frame escolhido por URL, nome ou índice; evita timeout de página com milhares de elementos.',
    inputSchema: z.object({
      page_id: pageId,
      frame_url_contains: z.string().max(500).default(''),
      frame_name: z.string().max(200).default(''),
      frame_index: z.number().int().min(0).max(500).optional(),
      max_text_chars: z.number().int().min(500).max(80000).default(12000),
      element_limit: z.number().int().min(1).max(300).default(80),
      script_limit: z.number().int().min(1).max(200).default(60),
      step_timeout_ms: z.number().int().min(800).max(15000).default(5000)
    }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true }
  }, async ({ page_id, frame_url_contains, frame_name, frame_index, max_text_chars, element_limit, script_limit, step_timeout_ms }) => wrapTool(
    () => ctx.edge.frameScan({ pageId: page_id, frameUrlContains: frame_url_contains || undefined, frameName: frame_name || undefined, frameIndex: frame_index, maxTextChars: max_text_chars, elementLimit: element_limit, scriptLimit: script_limit, stepTimeoutMs: step_timeout_ms }),
    { name: 'browser_frame_scan', timeoutMs: 25_000 }
  ));

  server.registerTool('browser_analyze_page', {
    title: 'Analisar página completa',
    description: 'USE PRIMEIRO em pedidos de análise. Coleta em uma única chamada o estado da aba, DOM interativo, texto, scripts, estilos, frames, console e rede. Retorna resultados parciais em vez de travar se uma seção falhar; evita pesquisar e chamar várias ferramentas separadamente.',
    inputSchema: z.object({
      page_id: pageId,
      include_html: z.boolean().default(false),
      max_text_chars: z.number().int().min(1_000).max(120_000).default(30_000),
      max_html_chars: z.number().int().min(1_000).max(160_000).default(40_000),
      element_limit: z.number().int().min(1).max(500).default(200),
      script_limit: z.number().int().min(1).max(500).default(200),
      event_limit: z.number().int().min(1).max(200).default(80),
      step_timeout_ms: z.number().int().min(1_000).max(20_000).default(10_000)
    }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false }
  }, async ({ page_id, include_html, max_text_chars, max_html_chars, element_limit, script_limit, event_limit, step_timeout_ms }, extra) => wrapTool(
    () => ctx.edge.analyzePage(page_id, {
      includeHtml: include_html,
      maxTextChars: max_text_chars,
      maxHtmlChars: max_html_chars,
      elementLimit: element_limit,
      scriptLimit: script_limit,
      eventLimit: event_limit,
      stepTimeoutMs: step_timeout_ms
    }, async event => {
      const progressToken = extra._meta?.progressToken;
      if (progressToken === undefined) return;
      await extra.sendNotification({
        method: 'notifications/progress',
        params: { progressToken, ...event }
      }).catch(() => undefined);
    }),
    { name: 'browser_analyze_page', timeoutMs: 65_000, signal: extra.signal }
  ));
  server.registerTool('browser_page_info', { description: 'Lê título, URL, estado do documento, viewport e contagens da aba.', inputSchema: z.object({ page_id: pageId }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id }) => wrapTool(() => ctx.edge.pageInfo(page_id)));
  server.registerTool('browser_snapshot', { description: 'Lista elementos interativos visíveis e cria refs temporárias como e1.', inputSchema: z.object({ page_id: pageId, limit: z.number().int().min(1).max(1000).default(300) }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, limit }) => wrapTool(() => ctx.edge.snapshot(page_id, limit)));
  server.registerTool('browser_get_text', { description: 'Lê texto visível de um seletor CSS.', inputSchema: z.object({ page_id: pageId, selector: z.string().default('body'), max_chars: z.number().int().min(1).max(1_000_000).default(200_000) }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, selector, max_chars }) => wrapTool(() => ctx.edge.getText(selector, page_id, max_chars)));
  server.registerTool('browser_get_html', { description: 'Lê HTML renderizado do documento ou de um seletor CSS.', inputSchema: z.object({ page_id: pageId, selector: z.string().default(''), max_chars: z.number().int().min(1).max(1_000_000).default(500_000) }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, selector, max_chars }) => wrapTool(() => ctx.edge.getHtml(selector, page_id, max_chars)));
  server.registerTool('browser_screenshot', { description: 'Salva uma captura PNG da aba no diretório de artefatos.', inputSchema: z.object({ page_id: pageId, full_page: z.boolean().default(false) }), annotations: { readOnlyHint: true, idempotentHint: false } }, async ({ page_id, full_page }) => wrapTool(() => ctx.edge.screenshot(page_id, full_page)));
  server.registerTool('browser_list_scripts', { description: 'Lista scripts inline e externos em ordem do documento.', inputSchema: z.object({ page_id: pageId, limit: z.number().int().min(1).max(1000).default(300) }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, limit }) => wrapTool(() => ctx.edge.listScripts(page_id, limit)));
  server.registerTool('browser_read_inline_script', { description: 'Lê um script inline pelo índice retornado por browser_list_scripts.', inputSchema: z.object({ page_id: pageId, index: z.number().int().min(0), max_chars: z.number().int().min(1).max(1_000_000).default(200_000) }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, index, max_chars }) => wrapTool(() => ctx.edge.readInlineScript(index, page_id, max_chars)));
  server.registerTool('browser_list_stylesheets', { description: 'Lista stylesheets e contagem acessível de regras CSS.', inputSchema: z.object({ page_id: pageId, limit: z.number().int().min(1).max(1000).default(300) }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, limit }) => wrapTool(() => ctx.edge.listStylesheets(page_id, limit)));
  server.registerTool('browser_recent_console', { description: 'Lê mensagens recentes do console e erros de página.', inputSchema: z.object({ page_id: pageId, limit: z.number().int().min(1).max(500).default(100) }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, limit }) => wrapTool(() => ctx.edge.recentConsole(page_id, limit)));
  server.registerTool('browser_recent_network', { description: 'Lê metadados recentes de rede sem corpos, cookies ou Authorization.', inputSchema: z.object({ page_id: pageId, limit: z.number().int().min(1).max(500).default(100), url_contains: z.string().default(''), phase: z.string().default('') }), annotations: { readOnlyHint: true, idempotentHint: true } }, async ({ page_id, limit, url_contains, phase }) => wrapTool(() => ctx.edge.recentNetwork(page_id, limit, url_contains, phase)));
}
