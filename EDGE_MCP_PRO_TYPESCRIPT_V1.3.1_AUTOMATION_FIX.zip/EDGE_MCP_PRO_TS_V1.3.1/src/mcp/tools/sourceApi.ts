import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import { assertSafeRemoteUrl } from '../../core/security.js';
import { wrapTool } from '../result.js';

export function registerSourceApiTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('source_fetch_url', {
    description: 'Baixa texto público JS, CSS, HTML ou JSON sem cookies do navegador e sem cabeçalhos sensíveis.',
    inputSchema: z.object({ url: z.string().min(1), max_chars: z.number().int().min(1).max(1_000_000).default(300_000) }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true }
  }, async ({ url, max_chars }) => wrapTool(async () => {
    const safe = await assertSafeRemoteUrl(url, ctx.runtime.get().allowPrivateNetwork);
    const response = await fetch(safe, { redirect: 'follow', signal: AbortSignal.timeout(30_000) });
    const text = await response.text();
    return {
      url: response.url,
      status: response.status,
      content_type: response.headers.get('content-type'),
      text: text.slice(0, max_chars),
      truncated: text.length > max_chars
    };
  }));

  server.registerTool('api_http_request', {
    description: 'Testa uma API HTTP com qualquer método e cabeçalhos fornecidos no modo de desenvolvimento local.',
    inputSchema: z.object({
      url: z.string().min(1),
      method: z.string().default('GET'),
      headers: z.record(z.string(), z.string()).default({}),
      body: z.string().default(''),
      timeout_seconds: z.number().int().min(1).max(120).default(30)
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async ({ url, method, headers, body, timeout_seconds }) => wrapTool(async () => {
    const normalizedMethod = method.toUpperCase();
    const safe = await assertSafeRemoteUrl(url, true);
    const response = await fetch(safe, {
      method: normalizedMethod,
      headers,
      body: ['GET', 'HEAD'].includes(normalizedMethod) ? undefined : body,
      redirect: 'manual',
      signal: AbortSignal.timeout(timeout_seconds * 1000)
    });
    const text = await response.text();
    ctx.audit.write({ actor: 'mcp', action: 'api_http_request', details: { url: safe.origin + safe.pathname, method: normalizedMethod, status: response.status } });
    return { status: response.status, url: response.url, headers: Object.fromEntries([...response.headers].filter(([key]) => !/set-cookie|authorization/i.test(key))), body: text.slice(0, 500_000), truncated: text.length > 500_000 };
  }));

  server.registerTool('api_scaffold_fastify', {
    description: 'Cria um projeto de API Fastify em TypeScript dentro do workspace.',
    inputSchema: z.object({ project_name: z.string().regex(/^[A-Za-z0-9_-]{1,80}$/), overwrite: z.boolean().default(false) }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }, async ({ project_name, overwrite }) => wrapTool(() => {
    ctx.runtime.assertEnabled('allowWorkspaceWrite');
    const base = `apis/${project_name}`;
    const files: Record<string, string> = {
      [`${base}/package.json`]: JSON.stringify({ name: project_name.toLowerCase(), version: '1.0.0', private: true, type: 'module', scripts: { dev: 'tsx watch src/server.ts', build: 'tsc', start: 'node dist/server.js' }, dependencies: { fastify: '^5.6.0' }, devDependencies: { '@types/node': '^24.0.0', tsx: '^4.20.0', typescript: '^6.0.0' } }, null, 2),
      [`${base}/tsconfig.json`]: JSON.stringify({ compilerOptions: { target: 'ES2023', module: 'NodeNext', moduleResolution: 'NodeNext', strict: true, outDir: 'dist', rootDir: 'src', skipLibCheck: true }, include: ['src/**/*.ts'] }, null, 2),
      [`${base}/src/server.ts`]: `import Fastify from 'fastify';\n\nconst app = Fastify({ logger: true });\n\napp.get('/health', async () => ({ ok: true }));\n\nawait app.listen({ host: '127.0.0.1', port: 3000 });\n`,
      [`${base}/README.md`]: `# ${project_name}\n\n\`\`\`bash\nnpm install\nnpm run dev\n\`\`\`\n`
    };
    for (const [file, content] of Object.entries(files)) ctx.workspace.write(file, content, overwrite);
    ctx.audit.write({ actor: 'mcp', action: 'api_project_scaffolded', subject: project_name });
    return { created: Object.keys(files), root: base };
  }));
}
