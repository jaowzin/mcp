import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import { wrapTool } from '../result.js';

const pageId = z.string().default('');

export function registerBrowserActionTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('browser_open_and_analyze', {
    title: 'Abrir URL e analisar em uma chamada',
    description: 'USE IMEDIATAMENTE quando o usuário fornecer uma URL e pedir análise pelo Edge. Abre ou reutiliza a página e coleta DOM, texto, scripts, estilos, frames, console e rede em UMA chamada. Não chame browser_list_tabs antes desta ferramenta.',
    inputSchema: z.object({
      url: z.string().min(1),
      reuse_existing: z.boolean().default(true),
      include_html: z.boolean().default(false),
      max_text_chars: z.number().int().min(1_000).max(120_000).default(30_000),
      max_html_chars: z.number().int().min(1_000).max(160_000).default(40_000),
      element_limit: z.number().int().min(1).max(500).default(200),
      script_limit: z.number().int().min(1).max(500).default(200),
      event_limit: z.number().int().min(1).max(200).default(80),
      step_timeout_ms: z.number().int().min(1_000).max(20_000).default(10_000)
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async ({ url, reuse_existing, include_html, max_text_chars, max_html_chars, element_limit, script_limit, event_limit, step_timeout_ms }, extra) => wrapTool(
    () => ctx.edge.openAndAnalyze(url, {
      includeHtml: include_html,
      maxTextChars: max_text_chars,
      maxHtmlChars: max_html_chars,
      elementLimit: element_limit,
      scriptLimit: script_limit,
      eventLimit: event_limit,
      stepTimeoutMs: step_timeout_ms
    }, reuse_existing, async event => {
      const progressToken = extra._meta?.progressToken;
      if (progressToken === undefined) return;
      await extra.sendNotification({ method: 'notifications/progress', params: { progressToken, ...event } }).catch(() => undefined);
    }),
    { name: 'browser_open_and_analyze', timeoutMs: 70_000, signal: extra.signal }
  ));

  server.registerTool('browser_open_tab', {
    description: 'Abre uma nova aba no Edge isolado.',
    inputSchema: z.object({ url: z.string().default('about:blank') }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async ({ url }) => wrapTool(() => ctx.edge.openTab(url)));

  server.registerTool('browser_close_tab', {
    description: 'Fecha uma aba pelo page_id.',
    inputSchema: z.object({ page_id: z.string().min(1) }),
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: false }
  }, async ({ page_id }) => wrapTool(() => ctx.edge.closeTab(page_id)));

  server.registerTool('browser_switch_tab', {
    description: 'Traz uma aba existente para frente e a seleciona.',
    inputSchema: z.object({ page_id: z.string().min(1) }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }, async ({ page_id }) => wrapTool(() => ctx.edge.switchTab(page_id)));

  server.registerTool('browser_navigate', {
    description: 'Navega a aba selecionada para uma URL HTTP/HTTPS.',
    inputSchema: z.object({ url: z.string().min(1), page_id: pageId, wait_until: z.enum(['load', 'domcontentloaded', 'networkidle']).default('domcontentloaded') }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async ({ url, page_id, wait_until }) => wrapTool(() => ctx.edge.navigate(url, page_id, wait_until)));

  server.registerTool('browser_reload', { description: 'Recarrega a aba.', inputSchema: z.object({ page_id: pageId }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true } }, async ({ page_id }) => wrapTool(() => ctx.edge.reload(page_id)));
  server.registerTool('browser_go_back', { description: 'Volta no histórico da aba.', inputSchema: z.object({ page_id: pageId }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false } }, async ({ page_id }) => wrapTool(() => ctx.edge.goBack(page_id)));
  server.registerTool('browser_go_forward', { description: 'Avança no histórico da aba.', inputSchema: z.object({ page_id: pageId }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false } }, async ({ page_id }) => wrapTool(() => ctx.edge.goForward(page_id)));

  server.registerTool('browser_click', {
    description: 'Clica por ref de snapshot, seletor CSS ou texto visível exato.',
    inputSchema: z.object({ page_id: pageId, ref: z.string().default(''), selector: z.string().default(''), text: z.string().default('') }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async ({ page_id, ref, selector, text }) => wrapTool(() => ctx.edge.click({ pageId: page_id, ref, selector, text })));

  server.registerTool('browser_fill', {
    description: 'Substitui o valor de um campo. O valor não é gravado na auditoria.',
    inputSchema: z.object({ value: z.string(), page_id: pageId, ref: z.string().default(''), selector: z.string().default('') }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false }
  }, async ({ value, page_id, ref, selector }) => wrapTool(() => ctx.edge.fill({ value, pageId: page_id, ref, selector })));

  server.registerTool('browser_type_text', {
    description: 'Digita texto sequencialmente em um elemento.',
    inputSchema: z.object({ value: z.string(), delay_ms: z.number().int().min(0).max(1000).default(0), page_id: pageId, ref: z.string().default(''), selector: z.string().default('') }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false }
  }, async ({ value, delay_ms, page_id, ref, selector }) => wrapTool(() => ctx.edge.typeText({ value, delayMs: delay_ms, pageId: page_id, ref, selector })));

  server.registerTool('browser_press', { description: 'Pressiona uma tecla globalmente ou em um seletor.', inputSchema: z.object({ key: z.string().min(1), page_id: pageId, selector: z.string().default('') }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false } }, async ({ key, page_id, selector }) => wrapTool(() => ctx.edge.press(key, page_id, selector)));
  server.registerTool('browser_select_option', { description: 'Seleciona valores em um elemento select.', inputSchema: z.object({ selector: z.string().min(1), values: z.array(z.string()).min(1), page_id: pageId }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false } }, async ({ selector, values, page_id }) => wrapTool(() => ctx.edge.selectOption(selector, values, page_id)));
  server.registerTool('browser_hover', { description: 'Move o mouse sobre o primeiro elemento que corresponde ao seletor.', inputSchema: z.object({ selector: z.string().min(1), page_id: pageId }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true } }, async ({ selector, page_id }) => wrapTool(() => ctx.edge.hover(selector, page_id)));
  server.registerTool('browser_scroll', { description: 'Rola a aba por deltas em pixels.', inputSchema: z.object({ delta_x: z.number().int().default(0), delta_y: z.number().int().default(700), page_id: pageId }), annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false } }, async ({ delta_x, delta_y, page_id }) => wrapTool(() => ctx.edge.scroll(delta_x, delta_y, page_id)));

  server.registerTool('browser_evaluate_javascript', {
    description: 'Executa JavaScript direto na aba no modo de desenvolvimento local.',
    inputSchema: z.object({ expression: z.string().min(1).max(1_000_000), page_id: pageId, timeout_ms: z.number().int().min(250).max(120_000).default(15_000) }),
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: true }
  }, async ({ expression, page_id, timeout_ms }) => wrapTool(async () => {
    ctx.runtime.assertEnabled('allowDirectJavaScript', 'JavaScript direto está desativado.');
    const payload = { page_id, sha256: await import('node:crypto').then(({ default: crypto }) => crypto.createHash('sha256').update(expression).digest('hex')), timeout_ms };
    const result = await ctx.edge.evaluate(expression, page_id, timeout_ms);
    ctx.audit.write({ actor: 'mcp', action: 'browser_javascript_evaluated', details: payload });
    return result;
  }));
}
