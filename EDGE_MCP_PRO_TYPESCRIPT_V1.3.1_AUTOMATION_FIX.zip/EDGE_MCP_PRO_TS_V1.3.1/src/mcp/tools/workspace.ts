import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import { wrapTool } from '../result.js';

export function registerWorkspaceTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('workspace_list', {
    description: 'Lista arquivos somente dentro do workspace persistente.',
    inputSchema: z.object({ path: z.string().default('.'), recursive: z.boolean().default(true), limit: z.number().int().min(1).max(2000).default(300) }),
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async ({ path, recursive, limit }) => wrapTool(() => ({ entries: ctx.workspace.list(path, recursive, limit) })));

  server.registerTool('workspace_read', {
    description: 'Lê um arquivo UTF-8 dentro do workspace.',
    inputSchema: z.object({ path: z.string().min(1), offset: z.number().int().min(0).default(0), max_chars: z.number().int().min(1).max(1_000_000).default(200_000) }),
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async ({ path, offset, max_chars }) => wrapTool(() => ctx.workspace.read(path, offset, max_chars)));

  server.registerTool('workspace_write', {
    description: 'Cria ou substitui um arquivo UTF-8 dentro do workspace. Para scripts de página, use site-scripts/<id>.js. Criar arquivo novo não executa nada.',
    inputSchema: z.object({ path: z.string().min(1), content: z.string(), overwrite: z.boolean().default(false) }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }, async ({ path, content, overwrite }) => wrapTool(() => {
    ctx.runtime.assertEnabled('allowWorkspaceWrite');
    const result = ctx.workspace.write(path, content, overwrite);
    ctx.audit.write({ actor: 'mcp', action: 'workspace_file_written', subject: result.path, details: { bytes: result.bytes, created: result.created } });
    return {
      ...result,
      site_script_candidate: result.path.startsWith('site-scripts/') && result.path.toLowerCase().endsWith('.js'),
      registered: false,
      executed: false
    };
  }));

  server.registerTool('workspace_delete', {
    description: 'Remove um arquivo ou diretório vazio do workspace.',
    inputSchema: z.object({ path: z.string().min(1) }),
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: false }
  }, async ({ path }) => wrapTool(() => {
    ctx.runtime.assertEnabled('allowWorkspaceDelete');
    const result = ctx.workspace.delete(path);
    ctx.audit.write({ actor: 'mcp', action: 'workspace_path_deleted', subject: path });
    return result;
  }));

  server.registerTool('workspace_search', {
    description: 'Pesquisa texto em arquivos do workspace.',
    inputSchema: z.object({ query: z.string().min(1), path: z.string().default('.'), limit: z.number().int().min(1).max(500).default(100) }),
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async ({ query, path, limit }) => wrapTool(() => ({ matches: ctx.workspace.search(query, path, limit) })));
}
