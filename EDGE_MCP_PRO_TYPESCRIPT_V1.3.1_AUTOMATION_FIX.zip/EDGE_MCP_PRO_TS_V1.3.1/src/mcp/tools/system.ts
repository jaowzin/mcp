import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import { getPaths } from '../../core/paths.js';
import { toolActivityResult, toolResult, wrapTool } from '../result.js';
import { APP_NAME, APP_VERSION } from '../../core/version.js';
import { clearActivityHistory } from '../../core/activity.js';

export function registerSystemTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('system_status', {
    title: 'Status do Edge MCP',
    description: 'Mostra versão, domínio, caminho MCP, configurações dinâmicas e conexão do Edge sem revelar tokens.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => wrapTool(async () => ({
    name: APP_NAME,
    version: APP_VERSION,
    tool_mode: (process.env.EDGE_MCP_TOOL_MODE ?? 'advanced').trim().toLowerCase(),
    public_base_url: ctx.config.publicBaseUrl,
    mcp_url: `${ctx.config.publicBaseUrl}${ctx.identity.mcpPath}`,
    dashboard_url: `http://127.0.0.1:${ctx.config.port}/dashboard`,
    workspace: getPaths().workspaceDir,
    settings: ctx.runtime.get(),
    edge: await ctx.edge.status(),
    autorun: ctx.autorun.status()
  })));

  server.registerTool('system_settings_get', {
    description: 'Lê as opções atuais do painel administrativo.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => toolResult(ctx.runtime.get()));


  server.registerTool('system_activity', {
    title: 'Diagnóstico de chamadas MCP',
    description: 'Mostra chamadas MCP e ferramentas ativas ou recentes, incluindo duração, timeout e erro. Use quando uma análise parecer ter parado.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => toolActivityResult());


  server.registerTool('system_session_reset', {
    title: 'Limpar sessão MCP/Edge',
    description: 'Limpa histórico recente, buffers de console/rede e refs temporárias quando o MCP começar a parecer bloqueado após muito uso. Pode fechar abas extras se solicitado.',
    inputSchema: z.object({
      close_extra_tabs: z.boolean().default(false),
      clear_events: z.boolean().default(true),
      clear_activity: z.boolean().default(true)
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }, async ({ close_extra_tabs, clear_events, clear_activity }) => wrapTool(async () => {
    const edge = await ctx.edge.resetSession({ closeExtraTabs: close_extra_tabs, clearEvents: clear_events });
    const activity = clear_activity ? clearActivityHistory() : { skipped: true };
    return { ok: true, edge, activity };
  }, { name: 'system_session_reset', timeoutMs: 20_000 }));

  server.registerTool('system_settings_update', {
    description: 'Atualiza opções do Edge MCP. Use apenas quando o usuário pedir explicitamente para mudar uma opção.',
    inputSchema: z.object({
      patch: z.record(z.string(), z.boolean()).describe('Mapa com opções booleanas a alterar.')
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }, async ({ patch }) => wrapTool(() => {
    const updated = ctx.runtime.update(patch);
    ctx.audit.write({ actor: 'mcp', action: 'runtime_settings_updated', details: { keys: Object.keys(patch) } });
    return updated;
  }));

  server.registerTool('approval_list_pending', {
    description: 'Lista solicitações locais de aprovação pendentes ou recentes.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => toolResult({ approvals: ctx.approvals.list() }));

  server.registerTool('page_script_autorun_status', {
    description: 'Mostra scripts armados para autoexecução e resultados recentes.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => toolResult(ctx.autorun.status()));
}
