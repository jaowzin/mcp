import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import type { UploadedFileObject } from '../../services/UploadedFileService.js';
import { wrapTool } from '../result.js';

const hostList = z.array(z.string()).default(['*']);

export function registerSiteScriptTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('page_script_list_saved', {
    description: 'Lista metadados de scripts locais registrados; não retorna o código-fonte.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => wrapTool(() => ({ scripts: ctx.scripts.list() })));

  server.registerTool('page_script_register_workspace_file', {
    description: 'Registra um arquivo .js já salvo em workspace/site-scripts. Armazena checksum e escopo, sem executar.',
    inputSchema: z.object({
      path: z.string().min(1),
      script_id: z.string().default(''),
      name: z.string().default(''),
      description: z.string().default(''),
      allowed_page_hosts: hostList,
      allowed_network_hosts: hostList,
      trusted: z.boolean().default(false)
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }, async ({ path, script_id, name, description, allowed_page_hosts, allowed_network_hosts, trusted }) => wrapTool(() => {
    ctx.runtime.assertEnabled('allowSavedScripts');
    const record = ctx.scripts.registerWorkspaceFile({
      path,
      scriptId: script_id || undefined,
      name: name || undefined,
      description: description || undefined,
      allowedPageHosts: allowed_page_hosts,
      allowedNetworkHosts: allowed_network_hosts,
      trusted,
      origin: 'workspace'
    });
    ctx.audit.write({ actor: 'mcp', action: 'site_script_registered', subject: record.id, details: { sha256: record.sha256, profile: record.profile } });
    return { registered: true, executed: false, script: record };
  }));

  server.registerTool('page_script_import_file', {
    description: 'Importa um arquivo .js anexado na conversa, salva localmente e registra checksum/escopo sem executar.',
    inputSchema: z.object({
      file: z.record(z.string(), z.unknown()),
      script_id: z.string().default(''),
      name: z.string().default(''),
      description: z.string().default(''),
      allowed_page_hosts: hostList,
      allowed_network_hosts: hostList,
      trusted: z.boolean().default(false)
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false },
    _meta: { 'openai/fileParams': ['file'] }
  }, async ({ file, script_id, name, description, allowed_page_hosts, allowed_network_hosts, trusted }) => wrapTool(async () => {
    ctx.runtime.assertEnabled('allowSavedScripts');
    const uploaded = await ctx.uploads.downloadJavaScript(file as UploadedFileObject);
    const inferredId = script_id || uploaded.name.replace(/\.js$/i, '');
    const record = ctx.scripts.saveSource({
      source: uploaded.text,
      scriptId: inferredId,
      name: name || undefined,
      description: description || `Arquivo importado: ${uploaded.name}`,
      allowedPageHosts: allowed_page_hosts,
      allowedNetworkHosts: allowed_network_hosts,
      trusted,
      origin: 'upload'
    });
    ctx.audit.write({ actor: 'mcp', action: 'site_script_file_imported', subject: record.id, details: { file_id: uploaded.fileId, bytes: uploaded.bytes, sha256: record.sha256 } });
    return { imported: true, registered: true, executed: false, file: { name: uploaded.name, file_id: uploaded.fileId, bytes: uploaded.bytes }, script: record };
  }));

  server.registerTool('page_script_update', {
    description: 'Atualiza nome, escopo, confiança, habilitação ou autoexecução de um script local.',
    inputSchema: z.object({
      script_id: z.string().min(1),
      name: z.string().optional(),
      description: z.string().optional(),
      enabled: z.boolean().optional(),
      trusted: z.boolean().optional(),
      auto_run: z.boolean().optional(),
      allowed_page_hosts: z.array(z.string()).optional(),
      allowed_network_hosts: z.array(z.string()).optional()
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true }
  }, async ({ script_id, auto_run, allowed_page_hosts, allowed_network_hosts, ...rest }) => wrapTool(() => {
    const record = ctx.scripts.update(script_id, {
      ...rest,
      autoRun: auto_run,
      allowedPageHosts: allowed_page_hosts,
      allowedNetworkHosts: allowed_network_hosts
    });
    ctx.audit.write({ actor: 'mcp', action: 'site_script_updated', subject: script_id });
    return record;
  }));

  server.registerTool('page_script_run_saved', {
    description: 'Executa um script local registrado na aba escolhida, com rede liberada no modo de desenvolvimento.',
    inputSchema: z.object({ script_id: z.string().min(1), page_id: z.string().default(''), timeout_ms: z.number().int().min(250).max(120_000).default(30_000) }),
    annotations: { readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: true }
  }, async ({ script_id, page_id, timeout_ms }) => wrapTool(async () => {
    ctx.runtime.assertEnabled('allowSavedScripts');
    const script = ctx.scripts.get(script_id, true);
    const pageInfo = await ctx.edge.pageInfo(page_id);
    const pageUrl = String(pageInfo.url ?? '');
    const host = ctx.scripts.assertRunnable(script, pageUrl, true);
    const payload = { script_id, sha256: script.sha256, page_id: String(pageInfo.page_id ?? page_id), host, timeout_ms };
    const result = await ctx.edge.runSavedScript(script.source ?? '', {
      pageId: String(pageInfo.page_id ?? page_id),
      allowedNetworkHosts: ['*'],
      allowGlobalHosts: true,
      timeoutMs: timeout_ms
    });
    ctx.audit.write({ actor: 'mcp', action: 'site_script_executed', subject: script_id, details: payload });
    return { executed: true, script_id, profile: script.profile, ...result };
  }));
}
