import crypto from 'node:crypto';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import { getPaths } from '../../core/paths.js';
import { assertSafeRemoteUrl } from '../../core/security.js';
import { APP_NAME, APP_VERSION } from '../../core/version.js';
import { toolActivityResult, wrapTool } from '../result.js';

const pageId = z.string().default('');

const analysisFields = {
  include_html: z.boolean().default(false),
  max_text_chars: z.number().int().min(1_000).max(200_000).default(50_000),
  max_html_chars: z.number().int().min(1_000).max(300_000).default(80_000),
  element_limit: z.number().int().min(1).max(500).default(200),
  script_limit: z.number().int().min(1).max(500).default(200),
  event_limit: z.number().int().min(1).max(300).default(150),
  step_timeout_ms: z.number().int().min(1_000).max(20_000).default(10_000)
};

function analysisOptions(input: {
  include_html: boolean;
  max_text_chars: number;
  max_html_chars: number;
  element_limit: number;
  script_limit: number;
  event_limit: number;
  step_timeout_ms: number;
}) {
  return {
    includeHtml: input.include_html,
    maxTextChars: input.max_text_chars,
    maxHtmlChars: input.max_html_chars,
    elementLimit: input.element_limit,
    scriptLimit: input.script_limit,
    eventLimit: input.event_limit,
    stepTimeoutMs: input.step_timeout_ms
  };
}

export function registerCompactTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('browser_open_and_analyze', {
    title: 'Abrir e analisar URL agora',
    description: 'FERRAMENTA PRINCIPAL. Quando o usuário fornecer uma URL, chame esta ferramenta diretamente. Ela abre/reutiliza a página e devolve DOM, texto, scripts, estilos, frames, console e rede em uma única resposta. Não liste abas antes.',
    inputSchema: z.object({
      url: z.string().min(1),
      reuse_existing: z.boolean().default(true),
      ...analysisFields
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async (input, extra) => wrapTool(
    () => ctx.edge.openAndAnalyze(input.url, analysisOptions(input), input.reuse_existing, async event => {
      const progressToken = extra._meta?.progressToken;
      if (progressToken === undefined) return;
      await extra.sendNotification({ method: 'notifications/progress', params: { progressToken, ...event } }).catch(() => undefined);
    }),
    { name: 'browser_open_and_analyze', timeoutMs: 70_000, signal: extra.signal }
  ));

  server.registerTool('edge_execute', {
    title: 'Executar ação no Edge',
    description: 'Ferramenta única para continuar uma tarefa no Edge sem pesquisar outras ferramentas. Use action=open_analyze para URL; analyze para aba atual; snapshot antes de interagir; depois click/fill/type/press/navigate/reload/back/forward/scroll/screenshot/javascript/list_tabs/status.',
    inputSchema: z.object({
      action: z.enum([
        'open_analyze', 'analyze', 'status', 'list_tabs', 'snapshot', 'navigate',
        'click', 'fill', 'type', 'press', 'reload', 'back', 'forward',
        'scroll', 'screenshot', 'javascript'
      ]),
      url: z.string().default(''),
      page_id: pageId,
      reuse_existing: z.boolean().default(true),
      selector: z.string().default(''),
      ref: z.string().default(''),
      text: z.string().default(''),
      value: z.string().default(''),
      key: z.string().default(''),
      expression: z.string().default(''),
      delay_ms: z.number().int().min(0).max(1000).default(0),
      delta_x: z.number().int().default(0),
      delta_y: z.number().int().default(700),
      full_page: z.boolean().default(false),
      timeout_ms: z.number().int().min(250).max(120_000).default(15_000),
      wait_until: z.enum(['load', 'domcontentloaded', 'networkidle']).default('domcontentloaded'),
      limit: z.number().int().min(1).max(1000).default(300),
      ...analysisFields
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async (input, extra) => wrapTool(async () => {
    const opts = analysisOptions(input);
    switch (input.action) {
      case 'open_analyze':
        if (!input.url) throw new Error('url é obrigatória para action=open_analyze.');
        return ctx.edge.openAndAnalyze(input.url, opts, input.reuse_existing);
      case 'analyze':
        return ctx.edge.analyzePage(input.page_id, opts);
      case 'status':
        return ctx.edge.status();
      case 'list_tabs':
        return { items: await ctx.edge.listTabs() };
      case 'snapshot':
        return ctx.edge.snapshot(input.page_id, input.limit);
      case 'navigate':
        if (!input.url) throw new Error('url é obrigatória para action=navigate.');
        return ctx.edge.navigate(input.url, input.page_id, input.wait_until);
      case 'click':
        return ctx.edge.click({ pageId: input.page_id, ref: input.ref, selector: input.selector, text: input.text });
      case 'fill':
        return ctx.edge.fill({ pageId: input.page_id, ref: input.ref, selector: input.selector, value: input.value });
      case 'type':
        return ctx.edge.typeText({ pageId: input.page_id, ref: input.ref, selector: input.selector, value: input.value, delayMs: input.delay_ms });
      case 'press':
        if (!input.key) throw new Error('key é obrigatória para action=press.');
        return ctx.edge.press(input.key, input.page_id, input.selector);
      case 'reload':
        return ctx.edge.reload(input.page_id);
      case 'back':
        return ctx.edge.goBack(input.page_id);
      case 'forward':
        return ctx.edge.goForward(input.page_id);
      case 'scroll':
        return ctx.edge.scroll(input.delta_x, input.delta_y, input.page_id);
      case 'screenshot':
        return ctx.edge.screenshot(input.page_id, input.full_page);
      case 'javascript': {
        if (!input.expression) throw new Error('expression é obrigatória para action=javascript.');
        const result = await ctx.edge.evaluate(input.expression, input.page_id, input.timeout_ms);
        ctx.audit.write({
          actor: 'mcp',
          action: 'browser_javascript_evaluated',
          details: {
            page_id: input.page_id,
            sha256: crypto.createHash('sha256').update(input.expression).digest('hex'),
            timeout_ms: input.timeout_ms
          }
        });
        return result;
      }
    }
  }, { name: `edge_execute:${input.action}`, timeoutMs: input.action.includes('analyze') ? 70_000 : 60_000, signal: extra.signal }));

  server.registerTool('api_http_request', {
    title: 'Testar requisição HTTP',
    description: 'Executa uma requisição HTTP/HTTPS para API autorizada, com método, cabeçalhos e corpo. Use diretamente sem procurar outra ferramenta.',
    inputSchema: z.object({
      url: z.string().min(1),
      method: z.string().default('GET'),
      headers: z.record(z.string(), z.string()).default({}),
      body: z.string().default(''),
      timeout_seconds: z.number().int().min(1).max(120).default(30)
    }),
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
  }, async ({ url, method, headers, body, timeout_seconds }) => wrapTool(async () => {
    const normalizedMethod = method.toUpperCase();
    const safe = await assertSafeRemoteUrl(url, true);
    const response = await fetch(safe, {
      method: normalizedMethod,
      headers,
      body: ['GET', 'HEAD'].includes(normalizedMethod) ? undefined : body,
      redirect: 'manual',
      signal: AbortSignal.timeout(timeout_seconds * 1000)
    });
    const text = await response.text();
    ctx.audit.write({ actor: 'mcp', action: 'api_http_request', details: { url: safe.origin + safe.pathname, method: normalizedMethod, status: response.status } });
    return {
      status: response.status,
      url: response.url,
      headers: Object.fromEntries([...response.headers].filter(([key]) => !/set-cookie|authorization/i.test(key))),
      body: text.slice(0, 500_000),
      truncated: text.length > 500_000
    };
  }, { name: 'api_http_request', timeoutMs: timeout_seconds * 1000 + 5_000 }));

  server.registerTool('source_fetch_url', {
    title: 'Ler recurso público',
    description: 'Baixa texto público JS, CSS, HTML ou JSON sem cookies do navegador.',
    inputSchema: z.object({
      url: z.string().min(1),
      max_chars: z.number().int().min(1).max(1_000_000).default(300_000)
    }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true }
  }, async ({ url, max_chars }) => wrapTool(async () => {
    const safe = await assertSafeRemoteUrl(url, ctx.runtime.get().allowPrivateNetwork);
    const response = await fetch(safe, { redirect: 'follow', signal: AbortSignal.timeout(30_000) });
    const text = await response.text();
    return {
      url: response.url,
      status: response.status,
      content_type: response.headers.get('content-type'),
      text: text.slice(0, max_chars),
      truncated: text.length > max_chars
    };
  }, { name: 'source_fetch_url', timeoutMs: 35_000 }));

  server.registerTool('system_status', {
    title: 'Status do Edge MCP',
    description: 'Mostra versão, modo de ferramentas e conexão do Edge.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => wrapTool(async () => ({
    name: APP_NAME,
    version: APP_VERSION,
    tool_mode: 'compact',
    public_base_url: ctx.config.publicBaseUrl,
    mcp_url: `${ctx.config.publicBaseUrl}${ctx.identity.mcpPath}`,
    dashboard_url: `http://127.0.0.1:${ctx.config.port}/dashboard`,
    workspace: getPaths().workspaceDir,
    edge: await ctx.edge.status()
  }), { name: 'system_status', timeoutMs: 15_000 }));

  server.registerTool('system_activity', {
    title: 'Atividade MCP',
    description: 'Mostra chamadas ativas e recentes. Use somente quando uma operação aparentar travar.',
    annotations: { readOnlyHint: true, idempotentHint: true }
  }, async () => toolActivityResult());
}
