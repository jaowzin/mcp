import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import type { AppContext } from '../../core/context.js';
import { assertSafeRemoteUrl, normalizeHttpUrlInput } from '../../core/security.js';
import { wrapTool } from '../result.js';

const pathItem = z.string().min(1).max(2_000);

function sameOriginUrl(base: URL, input: string): URL {
  const trimmed = input.trim();
  const url = /^https?:\/\//i.test(trimmed)
    ? new URL(trimmed)
    : new URL(trimmed.startsWith('/') ? trimmed : `/${trimmed}`, base);
  if (url.origin !== base.origin) {
    throw new Error(`Fora do mesmo origin: ${url.href}`);
  }
  url.username = '';
  url.password = '';
  return url;
}

function headersObject(headers: Headers): Record<string, string> {
  const blocked = /set-cookie|authorization|cookie|token|secret|password|api[-_]?key/i;
  return Object.fromEntries([...headers].map(([key, value]) => [key, blocked.test(key) ? '[REDACTED]' : value]));
}

async function readSmallText(response: Response, maxChars: number): Promise<{ preview: string; truncated: boolean; chars: number }> {
  const type = response.headers.get('content-type') ?? '';
  if (!/text|html|json|javascript|xml|css|plain/i.test(type)) return { preview: '', truncated: false, chars: 0 };
  const text = await response.text();
  return { preview: text.replace(/\s+/g, ' ').slice(0, maxChars), truncated: text.length > maxChars, chars: text.length };
}

function safeRegex(term: string): RegExp {
  return new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
}

function snippetAround(text: string, term: string, chars: number): string[] {
  const lower = text.toLowerCase();
  const needle = term.toLowerCase();
  const out: string[] = [];
  let from = 0;
  while (out.length < 3) {
    const idx = lower.indexOf(needle, from);
    if (idx < 0) break;
    const start = Math.max(0, idx - chars);
    const end = Math.min(text.length, idx + term.length + chars);
    out.push(text.slice(start, end).replace(/\s+/g, ' '));
    from = idx + term.length;
  }
  return out;
}

export function registerCtfTools(server: McpServer, ctx: AppContext): void {
  server.registerTool('ctf_readonly_recon', {
    title: 'CTF read-only recon',
    description: 'Para CTF/lab autorizado: mede status, redirects, content-type, tamanho e preview pequeno de caminhos no mesmo origin usando GET ou HEAD. Não envia senha, cookie, POST, PUT, DELETE nem payload mutável.',
    inputSchema: z.object({
      base_url: z.string().min(1),
      paths: z.array(pathItem).min(1).max(80),
      method: z.enum(['GET', 'HEAD']).default('GET'),
      preview_chars: z.number().int().min(0).max(2_000).default(400),
      timeout_seconds: z.number().int().min(1).max(30).default(10),
      stop_on_error: z.boolean().default(false)
    }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true }
  }, async ({ base_url, paths, method, preview_chars, timeout_seconds, stop_on_error }) => wrapTool(async () => {
    const base = await assertSafeRemoteUrl(base_url, ctx.runtime.get().allowPrivateNetwork);
    const started = Date.now();
    const results: Record<string, unknown>[] = [];
    for (const item of paths) {
      try {
        const url = sameOriginUrl(base, item);
        const response = await fetch(url, {
          method,
          redirect: 'manual',
          headers: { accept: 'text/html,application/json,text/plain,application/javascript,text/css,*/*;q=0.1' },
          signal: AbortSignal.timeout(timeout_seconds * 1000)
        });
        const body = method === 'GET' && preview_chars > 0 ? await readSmallText(response, preview_chars) : { preview: '', truncated: false, chars: 0 };
        results.push({
          path: url.pathname + url.search,
          status: response.status,
          redirected: response.redirected,
          location: response.headers.get('location'),
          type: response.headers.get('content-type'),
          length: response.headers.get('content-length'),
          preview: body.preview,
          truncated: body.truncated,
          body_chars_read: body.chars
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        results.push({ path: item, error: message });
        if (stop_on_error) break;
      }
    }
    ctx.audit.write({ actor: 'mcp', action: 'ctf_readonly_recon', details: { origin: base.origin, count: results.length, method } });
    return {
      mode: 'authorized_ctf_readonly',
      origin: base.origin,
      method,
      count: results.length,
      duration_ms: Date.now() - started,
      results,
      note: 'Somente observação read-only. Para testes com POST/payloads mutáveis, use ctf_request_plan e execute manualmente no seu laboratório/DevTools.'
    };
  }, { name: 'ctf_readonly_recon', timeoutMs: Math.min(70_000, Math.max(15_000, timeout_seconds * 1000 * paths.length + 5_000)) }));

  server.registerTool('ctf_public_code_search', {
    title: 'CTF public code search',
    description: 'Para CTF/lab autorizado: baixa páginas públicas do mesmo origin por GET e procura termos/endpoints em HTML/JS/CSS com snippets pequenos. Não executa ações, login, pagamento ou mutação.',
    inputSchema: z.object({
      base_url: z.string().min(1),
      pages: z.array(pathItem).min(1).max(30),
      terms: z.array(z.string().min(1).max(120)).min(1).max(80),
      max_page_chars: z.number().int().min(5_000).max(300_000).default(120_000),
      snippet_chars: z.number().int().min(20).max(300).default(90),
      timeout_seconds: z.number().int().min(1).max(30).default(12)
    }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true }
  }, async ({ base_url, pages, terms, max_page_chars, snippet_chars, timeout_seconds }) => wrapTool(async () => {
    const base = await assertSafeRemoteUrl(base_url, ctx.runtime.get().allowPrivateNetwork);
    const out: Record<string, unknown>[] = [];
    for (const pagePath of pages) {
      try {
        const url = sameOriginUrl(base, pagePath);
        const response = await fetch(url, { method: 'GET', redirect: 'follow', signal: AbortSignal.timeout(timeout_seconds * 1000) });
        const raw = await response.text();
        const text = raw.slice(0, max_page_chars);
        const hits: Record<string, number> = {};
        const snippets: Record<string, string[]> = {};
        for (const term of terms) {
          const count = (text.match(safeRegex(term)) ?? []).length;
          hits[term] = count;
          if (count > 0) snippets[term] = snippetAround(text, term, snippet_chars);
        }
        const endpoints = [...text.matchAll(/\/(?:api|ajax|admin|dashboard|auth|en)\/[A-Za-z0-9_./?=&:%-]*/g)]
          .map(match => match[0])
          .filter((value, index, array) => array.indexOf(value) === index)
          .slice(0, 120);
        out.push({
          page: url.pathname + url.search,
          status: response.status,
          final_url: response.url,
          type: response.headers.get('content-type'),
          original_chars: raw.length,
          searched_chars: text.length,
          truncated: raw.length > max_page_chars,
          hits,
          snippets,
          endpoints
        });
      } catch (error) {
        out.push({ page: pagePath, error: error instanceof Error ? error.message : String(error) });
      }
    }
    ctx.audit.write({ actor: 'mcp', action: 'ctf_public_code_search', details: { origin: base.origin, pages: out.length } });
    return { mode: 'authorized_ctf_public_code_search', origin: base.origin, pages: out };
  }, { name: 'ctf_public_code_search', timeoutMs: 65_000 }));

  server.registerTool('ctf_request_plan', {
    title: 'CTF request plan',
    description: 'Monta um plano e scripts locais para testes CTF que podem envolver POST, callbacks ou payloads. Esta ferramenta NÃO executa as requisições; ela gera comandos para DevTools/curl com escopo e avisos.',
    inputSchema: z.object({
      base_url: z.string().min(1),
      goal: z.string().min(1).max(1_000).default('validar comportamento do endpoint no CTF'),
      requests: z.array(z.object({
        name: z.string().min(1).max(120),
        method: z.string().min(1).max(12).default('GET'),
        path: pathItem,
        query: z.record(z.string(), z.string()).default({}),
        body: z.string().max(5_000).default(''),
        content_type: z.string().max(120).default('application/json')
      })).min(1).max(20)
    }),
    annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false }
  }, async ({ base_url, goal, requests }) => wrapTool(async () => {
    const base = new URL(normalizeHttpUrlInput(base_url));
    const planned = requests.map(req => {
      const url = sameOriginUrl(base, req.path);
      for (const [key, value] of Object.entries(req.query)) url.searchParams.set(key, value);
      const method = req.method.toUpperCase();
      const hasBody = !['GET', 'HEAD'].includes(method) && req.body.trim().length > 0;
      const curlParts = [
        'curl',
        '-i',
        '-X', method,
        JSON.stringify(url.href),
        '-H', JSON.stringify(`content-type: ${req.content_type}`)
      ];
      if (hasBody) curlParts.push('--data-raw', JSON.stringify(req.body));
      return {
        name: req.name,
        method,
        url: url.href,
        executes_in_mcp: false,
        curl: curlParts.join(' '),
        devtools_fetch: `await fetch(${JSON.stringify(url.pathname + url.search)}, { method: ${JSON.stringify(method)}, credentials: 'same-origin', cache: 'no-store', redirect: 'manual'${hasBody ? `, headers: {'content-type': ${JSON.stringify(req.content_type)}}, body: ${JSON.stringify(req.body)}` : ''} }).then(async r => ({status:r.status, location:r.headers.get('location'), type:r.headers.get('content-type'), body:(await r.text()).slice(0,800)}))`
      };
    });
    return {
      mode: 'authorized_ctf_request_plan_no_execution',
      goal,
      origin: base.origin,
      request_count: planned.length,
      planned,
      note: 'Por desenho, esta ferramenta não executa POST/payload/callback. Ela evita travar a sessão MCP e deixa o teste mutável explícito no seu ambiente local autorizado.'
    };
  }, { name: 'ctf_request_plan', timeoutMs: 10_000 }));

  server.registerTool('ctf_ws_frame_capture', {
    title: 'CTF WebSocket frame capture via Playwright',
    description: 'Para CTF/lab autorizado: captura amostras de frames WebSocket pelos eventos nativos do Playwright, sem CDP externo, sem hook JS, sem monkeypatch de WebSocket e sem mexer em ws.send. Use para mapear opcodes/payloads binários com limite de tamanho.',
    inputSchema: z.object({
      page_id: z.string().default(''),
      url: z.string().default(''),
      url_contains: z.string().max(300).default(''),
      duration_ms: z.number().int().min(1_000).max(120_000).default(20_000),
      max_frames: z.number().int().min(1).max(500).default(80),
      max_payload_bytes: z.number().int().min(1).max(4096).default(256),
      include_sent: z.boolean().default(true),
      include_received: z.boolean().default(true),
      reload: z.boolean().default(false),
      click_selector: z.string().max(500).default(''),
      click_text: z.string().max(200).default(''),
      click_delay_ms: z.number().int().min(0).max(30000).default(0)
    }),
    annotations: { readOnlyHint: true, idempotentHint: false, openWorldHint: true }
  }, async ({ page_id, url, url_contains, duration_ms, max_frames, max_payload_bytes, include_sent, include_received, reload, click_selector, click_text, click_delay_ms }) => wrapTool(async () => {
    const result = await ctx.edge.captureWebSocketFrames({
      pageId: page_id,
      url,
      urlContains: url_contains,
      durationMs: duration_ms,
      maxFrames: max_frames,
      maxPayloadBytes: max_payload_bytes,
      includeSent: include_sent,
      includeReceived: include_received,
      reload,
      clickSelector: click_selector || undefined,
      clickText: click_text || undefined,
      clickDelayMs: click_delay_ms
    });
    ctx.audit.write({ actor: 'mcp', action: 'ctf_ws_frame_capture', details: { duration_ms, max_frames, url_contains, has_url: Boolean(url) } });
    return {
      ...result,
      note: 'Captura feita por eventos Playwright de WebSocket. Não usa CDP externo, JavaScript injetado, hook em WebSocket/gotPacket nem ws.send.'
    };
  }, { name: 'ctf_ws_frame_capture', timeoutMs: Math.min(130_000, Math.max(10_000, duration_ms + 10_000)) }));


  server.registerTool('ctf_game_runtime_capture', {
    title: 'CTF/Game runtime capture estável',
    description: 'Captura leve para jogos em Telegram/Gamee/iframe: faz quick scan opcional, clica em TAP TO PLAY se pedido e captura WebSocket via Playwright. Não varre DOM inteiro e não usa hook JS.',
    inputSchema: z.object({
      page_id: z.string().default(''),
      url_contains: z.string().max(300).default(''),
      duration_ms: z.number().int().min(1_000).max(120_000).default(30_000),
      max_frames: z.number().int().min(1).max(500).default(120),
      max_payload_bytes: z.number().int().min(1).max(4096).default(512),
      click_text: z.string().max(200).default('TAP TO PLAY'),
      click_selector: z.string().max(500).default(''),
      click_delay_ms: z.number().int().min(0).max(30000).default(0),
      include_sent: z.boolean().default(true),
      include_received: z.boolean().default(true),
      reload: z.boolean().default(false),
      quick_scan_first: z.boolean().default(true)
    }),
    annotations: { readOnlyHint: true, idempotentHint: false, openWorldHint: true }
  }, async ({ page_id, url_contains, duration_ms, max_frames, max_payload_bytes, click_text, click_selector, click_delay_ms, include_sent, include_received, reload, quick_scan_first }) => wrapTool(async () => {
    const before = quick_scan_first ? await ctx.edge.quickScan({ pageId: page_id, eventLimit: 30, frameLimit: 40 }) : null;
    const capture = await ctx.edge.captureWebSocketFrames({
      pageId: page_id,
      urlContains: url_contains,
      durationMs: duration_ms,
      maxFrames: max_frames,
      maxPayloadBytes: max_payload_bytes,
      includeSent: include_sent,
      includeReceived: include_received,
      reload,
      clickText: click_text || undefined,
      clickSelector: click_selector || undefined,
      clickDelayMs: click_delay_ms
    });
    ctx.audit.write({ actor: 'mcp', action: 'ctf_game_runtime_capture', details: { duration_ms, max_frames, url_contains } });
    return {
      mode: 'ctf_game_runtime_capture_playwright',
      before,
      capture,
      guidance: 'Use enquanto o jogo está prestes a iniciar. Para Telegram/Gamee, esta ferramenta evita varredura completa e captura frames via eventos Playwright.'
    };
  }, { name: 'ctf_game_runtime_capture', timeoutMs: Math.min(135_000, Math.max(15_000, duration_ms + 15_000)) }));

}
