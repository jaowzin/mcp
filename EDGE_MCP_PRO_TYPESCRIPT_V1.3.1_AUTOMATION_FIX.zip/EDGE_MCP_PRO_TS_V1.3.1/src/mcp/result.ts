import type { CallToolResult } from '@modelcontextprotocol/sdk/types.js';
import { activitySnapshot, beginActivity, finishActivity } from '../core/activity.js';
import { DeadlineError, withDeadline } from '../core/deadline.js';

function defaultToolTimeoutMs(): number {
  const parsed = Number(process.env.EDGE_MCP_TOOL_TIMEOUT_MS ?? 60_000);
  return Number.isFinite(parsed) ? Math.max(5_000, Math.min(parsed, 110_000)) : 60_000;
}

const MAX_TEXT_CONTENT_CHARS = Number(process.env.EDGE_MCP_TEXT_RESULT_MAX_CHARS ?? 90_000);
const MAX_STRING_CHARS = Number(process.env.EDGE_MCP_STRING_MAX_CHARS ?? 60_000);
const MAX_ARRAY_ITEMS = Number(process.env.EDGE_MCP_ARRAY_MAX_ITEMS ?? 180);
const MAX_OBJECT_KEYS = Number(process.env.EDGE_MCP_OBJECT_MAX_KEYS ?? 220);
const MAX_DEPTH = Number(process.env.EDGE_MCP_RESULT_MAX_DEPTH ?? 8);

function sanitize(value: unknown, depth = 0, seen = new WeakSet<object>()): unknown {
  if (typeof value === 'string') {
    return value.length > MAX_STRING_CHARS
      ? `${value.slice(0, MAX_STRING_CHARS)}\n\n[EDGE_MCP_TRUNCATED_STRING original_chars=${value.length}]`
      : value;
  }
  if (value === null || typeof value !== 'object') return value;
  if (seen.has(value)) return '[EDGE_MCP_CIRCULAR_REFERENCE]';
  if (depth >= MAX_DEPTH) return `[EDGE_MCP_TRUNCATED_DEPTH depth=${depth}]`;
  seen.add(value);

  if (Array.isArray(value)) {
    const sliced = value.slice(0, MAX_ARRAY_ITEMS).map(item => sanitize(item, depth + 1, seen));
    if (value.length > MAX_ARRAY_ITEMS) {
      sliced.push({ truncated: true, original_items: value.length, shown_items: MAX_ARRAY_ITEMS });
    }
    return sliced;
  }

  const entries = Object.entries(value as Record<string, unknown>);
  const out: Record<string, unknown> = {};
  for (const [key, item] of entries.slice(0, MAX_OBJECT_KEYS)) out[key] = sanitize(item, depth + 1, seen);
  if (entries.length > MAX_OBJECT_KEYS) {
    out._edge_mcp_truncated_keys = { original_keys: entries.length, shown_keys: MAX_OBJECT_KEYS };
  }
  return out;
}

function stringify(value: unknown): string {
  let text: string;
  try {
    text = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
  } catch {
    text = String(value);
  }
  if (text.length > MAX_TEXT_CONTENT_CHARS) {
    return `${text.slice(0, MAX_TEXT_CONTENT_CHARS)}\n\n[EDGE_MCP_TRUNCATED_TEXT original_chars=${text.length}]`;
  }
  return text;
}

function toStructuredObject(value: unknown): Record<string, unknown> {
  const sanitized = sanitize(value);
  if (Array.isArray(sanitized)) return { items: sanitized };
  if (typeof sanitized === 'object' && sanitized !== null) return sanitized as Record<string, unknown>;
  return { value: sanitized };
}

export function toolResult(value: unknown, isError = false): CallToolResult {
  const structuredContent = toStructuredObject(value);
  return {
    content: [{ type: 'text', text: stringify(structuredContent) }],
    structuredContent,
    isError
  };
}

export interface WrapToolOptions {
  name?: string;
  timeoutMs?: number;
  signal?: AbortSignal;
}

export async function wrapTool<T>(fn: () => Promise<T> | T, options: WrapToolOptions = {}): Promise<CallToolResult> {
  const name = options.name ?? 'mcp_tool';
  const timeoutMs = options.timeoutMs ?? defaultToolTimeoutMs();
  const activity = beginActivity('tool', name, { timeout_ms: timeoutMs });

  try {
    const value = await withDeadline(fn, timeoutMs, `Ferramenta ${name}`, options.signal);
    finishActivity(activity, 'ok');
    return toolResult(value);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (error instanceof DeadlineError) {
      finishActivity(activity, 'timeout', message);
      return toolResult({
        error: message,
        code: error.code,
        retryable: true,
        timeout_ms: error.timeoutMs,
        guidance: 'A operação foi encerrada pelo watchdog para não deixar a conversa travada. Rode system_session_reset e tente novamente com limites menores.'
      }, true);
    }
    if (options.signal?.aborted) {
      finishActivity(activity, 'cancelled', message);
      return toolResult({ error: message, code: 'CLIENT_CANCELLED', retryable: true }, true);
    }
    finishActivity(activity, 'error', message);
    return toolResult({ error: message, code: 'TOOL_ERROR', retryable: false }, true);
  }
}

export function toolActivityResult(): CallToolResult {
  return toolResult(activitySnapshot());
}
