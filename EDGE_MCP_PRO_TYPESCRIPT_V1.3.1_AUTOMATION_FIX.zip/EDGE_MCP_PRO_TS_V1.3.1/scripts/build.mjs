import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const tscCli = path.join(root, 'node_modules', 'typescript', 'bin', 'tsc');
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const packageLock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
const versionFile = fs.readFileSync(path.join(root, 'VERSION.txt'), 'utf8').trim();
const expectedVersion = packageJson.version;

if (packageLock.version !== expectedVersion || packageLock.packages?.['']?.version !== expectedVersion || versionFile !== expectedVersion) {
  throw new Error(`Versoes inconsistentes: package.json=${expectedVersion}, package-lock=${packageLock.version}/${packageLock.packages?.['']?.version}, VERSION.txt=${versionFile}`);
}

if (!fs.existsSync(tscCli)) {
  throw new Error('TypeScript nao encontrado. Execute npm install antes de compilar.');
}

fs.rmSync(dist, { recursive: true, force: true });

// Executa o CLI JavaScript local do TypeScript com o mesmo node.exe.
// Isso evita tentar abrir npx.cmd diretamente via execFileSync no Windows.
execFileSync(process.execPath, [tscCli], {
  cwd: root,
  stdio: 'inherit',
  windowsHide: true,
});

fs.mkdirSync(path.join(dist, 'public'), { recursive: true });
await build({
  entryPoints: [path.join(root, 'web', 'main.ts')],
  bundle: true,
  format: 'esm',
  target: 'es2022',
  minify: false,
  sourcemap: true,
  outfile: path.join(dist, 'public', 'app.js'),
});
const panelHtml = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8').replaceAll('__APP_VERSION__', expectedVersion);
fs.writeFileSync(path.join(dist, 'public', 'index.html'), panelHtml, 'utf8');
fs.copyFileSync(path.join(root, 'web', 'app.css'), path.join(dist, 'public', 'app.css'));
console.log('Build concluido em dist/.');
