@echo off
setlocal EnableExtensions
cd /d "%~dp0\..\.."

if not exist "dist\src\server.js" goto not_ready
if not exist "node_modules" goto not_ready

if not defined EDGE_MCP_TOOL_MODE set "EDGE_MCP_TOOL_MODE=advanced"
if not defined EDGE_MCP_EDGE_MODE set "EDGE_MCP_EDGE_MODE=automation"
echo Modo de ferramentas MCP: %EDGE_MCP_TOOL_MODE%
echo Modo do Edge: %EDGE_MCP_EDGE_MODE% ^(sem CDP externo; controlado por software^)
call npm.cmd run start
set "EXIT_CODE=%ERRORLEVEL%"
endlocal & exit /b %EXIT_CODE%

:not_ready
echo O projeto ainda nao foi preparado.
echo Execute a opcao 1 do menu primeiro.
pause
endlocal
exit /b 1
