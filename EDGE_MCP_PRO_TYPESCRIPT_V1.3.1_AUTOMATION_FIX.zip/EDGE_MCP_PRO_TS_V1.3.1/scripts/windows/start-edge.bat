@echo off
setlocal EnableExtensions
cd /d "%~dp0\..\.."

echo.
echo ============================================================
echo  Edge MCP Pro v1.3.1 - modo controlado por software
echo ============================================================
echo.
echo Esta versao NAO usa porta CDP externa por padrao.
echo O Microsoft Edge sera aberto pelo proprio servidor MCP via Playwright.
echo.
echo Quando iniciar a opcao 3, o Edge deve aparecer com o aviso:
echo   "Microsoft Edge esta sendo controlado por software de teste automatizado"
echo.
echo Perfil usado:
echo   %%LOCALAPPDATA%%\EdgeMCPPro\edge-profile-automation
echo.
echo Proxima etapa: volte ao menu e escolha [3].
echo.
pause
endlocal
exit /b 0
