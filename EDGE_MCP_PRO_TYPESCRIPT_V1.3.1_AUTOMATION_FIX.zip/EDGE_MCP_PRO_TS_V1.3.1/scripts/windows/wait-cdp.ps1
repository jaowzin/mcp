param([int]$Port = 9222, [int]$Seconds = 25)
$deadline = (Get-Date).AddSeconds($Seconds)
while ((Get-Date) -lt $deadline) {
  try {
    $result = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 2
    if ($result.Browser) { Write-Output $result.Browser; exit 0 }
  } catch {}
  Start-Sleep -Milliseconds 500
}
exit 1
