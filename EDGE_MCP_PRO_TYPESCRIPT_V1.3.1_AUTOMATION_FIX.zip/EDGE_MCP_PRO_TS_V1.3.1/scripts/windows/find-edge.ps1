[CmdletBinding()]
param()

$ErrorActionPreference = 'SilentlyContinue'

function Convert-ToEdgeExecutablePath {
  param([AllowNull()][string]$Value)

  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }

  $expanded = [Environment]::ExpandEnvironmentVariables($Value.Trim())
  $candidates = New-Object System.Collections.Generic.List[string]

  $plain = $expanded.Trim().Trim('"')
  if ($plain) {
    [void]$candidates.Add($plain)
    if (Test-Path -LiteralPath $plain -PathType Container) {
      [void]$candidates.Add((Join-Path $plain 'msedge.exe'))
      [void]$candidates.Add((Join-Path $plain 'Application\msedge.exe'))
    }
  }

  if ($expanded -match '^\s*"([^"]*\\msedge\.exe)"') {
    [void]$candidates.Add($Matches[1])
  }
  elseif ($expanded -match '^\s*(.+?\\msedge\.exe)(?:\s|$)') {
    [void]$candidates.Add($Matches[1].Trim('"'))
  }

  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      try {
        return (Resolve-Path -LiteralPath $candidate).Path
      }
      catch {
        return $candidate
      }
    }
  }

  return $null
}

$found = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$candidates = [System.Collections.Generic.List[string]]::new()

function Add-EdgeCandidate {
  param([AllowNull()][string]$Value)
  if (-not [string]::IsNullOrWhiteSpace($Value)) {
    [void]$candidates.Add($Value)
  }
}

# Caminhos opcionais informados manualmente pelo usuario.
Add-EdgeCandidate ([Environment]::GetEnvironmentVariable('EDGE_MCP_EDGE_PATH'))

$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$edgePathFile = Join-Path $projectRoot 'edge-path.txt'
if (Test-Path -LiteralPath $edgePathFile -PathType Leaf) {
  try {
    Add-EdgeCandidate (Get-Content -LiteralPath $edgePathFile | Select-Object -First 1)
  }
  catch {}
}

# Edge ja aberto: normalmente fornece o caminho exato mesmo em instalacoes incomuns.
try {
  foreach ($edgeProcess in Get-Process -Name msedge) {
    Add-EdgeCandidate $edgeProcess.Path
  }
}
catch {}

# Caminhos padrao. O nome ProgramFiles(x86) precisa ser lido desta forma;
# $env:ProgramFiles(x86) nao funciona corretamente no PowerShell.
$programFiles = [Environment]::GetEnvironmentVariable('ProgramFiles')
$programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
$localAppData = [Environment]::GetEnvironmentVariable('LOCALAPPDATA')

$installRoots = @($programFilesX86, $programFiles, $localAppData) |
  Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
  Select-Object -Unique

$edgeFolders = @('Edge', 'Edge Beta', 'Edge Dev', 'Edge SxS')
foreach ($installRoot in $installRoots) {
  foreach ($edgeFolder in $edgeFolders) {
    Add-EdgeCandidate (Join-Path $installRoot "Microsoft\$edgeFolder\Application\msedge.exe")
  }
}

# App Paths e instaladores registrados pelo Windows.
$registryPaths = @(
  'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
  'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
  'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe'
)

foreach ($registryPath in $registryPaths) {
  try {
    $registryKey = Get-Item -LiteralPath $registryPath
    Add-EdgeCandidate ([string]$registryKey.GetValue(''))
    Add-EdgeCandidate ([string]$registryKey.GetValue('Path'))
  }
  catch {}
}

# Atalhos registrados no menu Iniciar.
$startMenuRoots = @(
  'Registry::HKEY_CURRENT_USER\SOFTWARE\Clients\StartMenuInternet',
  'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Clients\StartMenuInternet',
  'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Clients\StartMenuInternet'
)

foreach ($startMenuRoot in $startMenuRoots) {
  try {
    foreach ($clientKey in Get-ChildItem -LiteralPath $startMenuRoot) {
      $commandPath = Join-Path $clientKey.PSPath 'shell\open\command'
      try {
        $commandKey = Get-Item -LiteralPath $commandPath
        Add-EdgeCandidate ([string]$commandKey.GetValue(''))
      }
      catch {}
    }
  }
  catch {}
}

# Entradas de desinstalacao, usadas por algumas variantes do instalador do Edge.
$uninstallRoots = @(
  'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
  'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
  'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
)

foreach ($uninstallRoot in $uninstallRoots) {
  try {
    foreach ($applicationKey in Get-ChildItem -LiteralPath $uninstallRoot) {
      try {
        $application = Get-ItemProperty -LiteralPath $applicationKey.PSPath
        if ([string]$application.DisplayName -like 'Microsoft Edge*') {
          Add-EdgeCandidate ([string]$application.DisplayIcon)
          if ($application.InstallLocation) {
            Add-EdgeCandidate (Join-Path ([string]$application.InstallLocation) 'msedge.exe')
            Add-EdgeCandidate (Join-Path ([string]$application.InstallLocation) 'Application\msedge.exe')
          }
        }
      }
      catch {}
    }
  }
  catch {}
}

# PATH do usuario/sistema.
try {
  $edgeCommand = Get-Command msedge.exe -CommandType Application | Select-Object -First 1
  if ($edgeCommand) { Add-EdgeCandidate $edgeCommand.Source }
}
catch {}

try {
  foreach ($whereResult in (& where.exe msedge.exe 2>$null)) {
    Add-EdgeCandidate $whereResult
  }
}
catch {}

foreach ($candidate in $candidates) {
  $resolved = Convert-ToEdgeExecutablePath $candidate
  if ($resolved -and $found.Add($resolved)) {
    [Console]::Out.WriteLine($resolved)
    exit 0
  }
}

exit 1
