@echo off
setlocal EnableExtensions
cd /d "%~dp0\..\.."

echo [1/5] Verificando Node.js e npm...
where node.exe >nul 2>nul
if errorlevel 1 goto node_missing
where npm.cmd >nul 2>nul
if errorlevel 1 goto npm_missing
node.exe -e "const n=Number(process.versions.node.split('.')[0]); process.exit(n >= 22 ? 0 : 1)"
if errorlevel 1 goto node_old
node.exe --version
call npm.cmd --version

echo.
echo [2/5] Instalando dependencias npm...
call npm.cmd install --registry=https://registry.npmjs.org/ --replace-registry-host=always
if errorlevel 1 goto error

echo.
echo [3/5] Validando TypeScript e confiabilidade MCP...
call npm.cmd run typecheck
if errorlevel 1 goto error
call npm.cmd test
if errorlevel 1 goto error
echo Testes finalizados. Continuando para build...

echo.
echo [4/5] Compilando TypeScript e painel...
call npm.cmd run build
if errorlevel 1 goto error

echo.
echo [5/5] Preparando identidade e workspace persistentes...
call npm.cmd run setup
if errorlevel 1 goto error

echo.
echo Ambiente pronto. Modo Automation Edge validado sem travar apos testes.
pause
endlocal
exit /b 0

:node_missing
echo.
echo Node.js nao encontrado.
echo Instale Node.js 24 LTS pelo site oficial: https://nodejs.org/
echo Durante a instalacao, mantenha a opcao Add to PATH ativada.
echo Depois feche este terminal, abra outro e execute o menu novamente.
pause
endlocal
exit /b 1

:npm_missing
echo.
echo npm nao foi encontrado no PATH.
echo Reinstale Node.js 24 LTS e mantenha Add to PATH ativado.
pause
endlocal
exit /b 1

:node_old
echo.
echo A versao do Node.js precisa ser 22 ou superior.
echo Recomendado: Node.js 24 LTS em https://nodejs.org/
pause
endlocal
exit /b 1

:error
echo.
echo Ocorreu um erro. Leia as mensagens acima.
pause
endlocal
exit /b 1
