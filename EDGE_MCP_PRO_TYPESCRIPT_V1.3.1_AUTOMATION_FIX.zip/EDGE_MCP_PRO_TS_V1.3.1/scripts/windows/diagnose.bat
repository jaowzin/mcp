@echo off
setlocal EnableExtensions
cd /d "%~dp0\..\.."
call npm.cmd run diagnose
set "EXIT_CODE=%ERRORLEVEL%"
pause
endlocal & exit /b %EXIT_CODE%
