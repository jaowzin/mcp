import { createContext } from '../src/core/createContext.js';
import { APP_VERSION } from '../src/core/version.js';

const ctx = createContext();
const localBase = `http://127.0.0.1:${ctx.config.port}`;
const localMcp = `${localBase}${ctx.identity.mcpPath}`;

console.log(`Edge MCP Pro: ${APP_VERSION}`);
console.log(`Node: ${process.version}`);
console.log(`Plataforma: ${process.platform} ${process.arch}`);
console.log(`URL pública: ${ctx.config.publicBaseUrl}${ctx.identity.mcpPath}`);
console.log(`Modo Edge: ${process.env.EDGE_MCP_EDGE_MODE ?? 'automation'} (sem CDP externo por padrão)`);
console.log('Edge:', await ctx.edge.status());

try {
  const response = await fetch(`${localBase}/health`, { signal: AbortSignal.timeout(5000) });
  console.log(`Servidor local: HTTP ${response.status}`);
} catch {
  console.log('Servidor local: não está rodando. Inicie a opção 3 antes do diagnóstico MCP.');
}

try {
  const started = Date.now();
  const response = await fetch(localMcp, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'tools/list', params: {} }),
    signal: AbortSignal.timeout(10_000)
  });
  const payload = await response.json() as any;
  const names = Array.isArray(payload?.result?.tools) ? payload.result.tools.map((tool: any) => String(tool.name)) : [];
  console.log(`Descoberta MCP: HTTP ${response.status}, ${names.length} ferramentas, ${Date.now() - started} ms`);
  console.log(`browser_analyze_page: ${names.includes('browser_analyze_page') ? 'OK' : 'AUSENTE'}`);
  console.log(`system_activity: ${names.includes('system_activity') ? 'OK' : 'AUSENTE'}`);
} catch (error) {
  console.log(`Descoberta MCP: FALHOU — ${error instanceof Error ? error.message : String(error)}`);
}
