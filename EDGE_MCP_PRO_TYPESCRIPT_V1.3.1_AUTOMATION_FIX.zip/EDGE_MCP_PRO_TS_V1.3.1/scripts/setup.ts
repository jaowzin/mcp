import fs from 'node:fs';
import { createContext } from '../src/core/createContext.js';
import { getPaths, ensureDirectories } from '../src/core/paths.js';

const ctx = createContext();
const paths = getPaths();
ensureDirectories(paths);
const url = `${ctx.config.publicBaseUrl}${ctx.identity.mcpPath}`;
fs.writeFileSync(`${paths.globalRoot}/CHATGPT_MCP_URL.txt`, `${url}\n`, 'utf8');
fs.writeFileSync(paths.approvalsFile, '[]\n', 'utf8');
console.log('');
console.log('Ambiente persistente preparado em modo UNLOCKED.');
console.log(`Identidade: ${paths.identityFile}`);
console.log(`Workspace:  ${paths.workspaceDir}`);
console.log(`URL MCP:    ${url}`);
if (ctx.identity.migratedFrom) console.log(`Segredo importado da versão Python: ${ctx.identity.migratedFrom}`);
else console.log('O segredo existente foi reutilizado ou criado uma única vez.');
