import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import fs from 'node:fs';
import { loadIdentity } from '../src/core/identity.js';
import { loadConfig, saveConfig } from '../src/core/settings.js';
import { getPaths } from '../src/core/paths.js';

const current = loadConfig();
const rl = readline.createInterface({ input, output });
const answer = (await rl.question(`Domínio/base pública [${current.publicBaseUrl}]: `)).trim();
rl.close();
const config = saveConfig({ publicBaseUrl: answer || current.publicBaseUrl });
const identity = loadIdentity();
const url = `${config.publicBaseUrl}${identity.mcpPath}`;
fs.writeFileSync(`${getPaths().globalRoot}/CHATGPT_MCP_URL.txt`, `${url}\n`, 'utf8');
console.log(`Domínio salvo: ${config.publicBaseUrl}`);
console.log(`URL MCP preservada: ${url}`);
console.log('O caminho secreto não foi alterado.');
