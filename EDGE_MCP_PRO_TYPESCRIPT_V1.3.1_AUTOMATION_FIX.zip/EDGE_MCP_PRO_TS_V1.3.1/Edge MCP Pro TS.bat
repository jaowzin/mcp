@echo off
setlocal EnableExtensions
cd /d "%~dp0"

:menu
cls
echo ============================================================
echo              EDGE MCP PRO TYPESCRIPT v1.3.1 AUTOMATION EDGE
echo ============================================================
echo.
echo  [1] Preparar ambiente Node.js
echo  [2] Preparar modo Edge controlado por software
echo  [3] Iniciar MCP + Edge controlado por software
echo  [4] Configurar dominio fixo
echo  [5] Diagnostico
echo  [6] Abrir guia de instalacao
echo  [0] Sair
echo.
set "CHOICE="
set /p "CHOICE=Escolha: "

if "%CHOICE%"=="1" goto prepare
if "%CHOICE%"=="2" goto edge
if "%CHOICE%"=="3" goto server
if "%CHOICE%"=="4" goto domain
if "%CHOICE%"=="5" goto diagnose
if "%CHOICE%"=="6" goto guide
if "%CHOICE%"=="0" goto quit

goto menu

:prepare
call "scripts\windows\prepare.bat"
goto menu

:edge
call "scripts\windows\start-edge.bat"
goto menu

:server
call "scripts\windows\start-server.bat"
goto menu

:domain
call "scripts\windows\configure-domain.bat"
goto menu

:diagnose
call "scripts\windows\diagnose.bat"
goto menu

:guide
start "" "%~dp0docs\INSTALACAO_NODE_WINDOWS.md"
goto menu

:quit
endlocal
exit /b 0
