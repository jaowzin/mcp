import test from 'node:test';
import assert from 'node:assert/strict';
import { registerCtfTools } from '../src/mcp/tools/ctf.js';

test('ferramentas CTF registram modo read-only e plano sem execução', async () => {
  const tools = new Map<string, any>();
  const server = { registerTool: (name: string, config: unknown, handler: unknown) => tools.set(name, { config, handler }) };
  const ctx: any = {
    runtime: { get: () => ({ allowPrivateNetwork: true }) },
    audit: { write: () => undefined }
  };
  registerCtfTools(server as any, ctx);
  assert.deepEqual([...tools.keys()].sort(), ['ctf_game_runtime_capture', 'ctf_public_code_search', 'ctf_readonly_recon', 'ctf_request_plan', 'ctf_ws_frame_capture']);
  assert.equal((tools.get('ctf_readonly_recon').config as any).annotations.readOnlyHint, true);
  assert.equal((tools.get('ctf_request_plan').config as any).annotations.readOnlyHint, true);

  const result = await tools.get('ctf_request_plan').handler({
    base_url: 'https://example.test',
    goal: 'teste autorizado',
    requests: [{ name: 'observe', method: 'POST', path: '/api/test', query: { a: '1' }, body: '{"probe":true}', content_type: 'application/json' }]
  });
  assert.equal(result.isError, false);
  assert.equal(result.structuredContent.mode, 'authorized_ctf_request_plan_no_execution');
  assert.equal(result.structuredContent.planned[0].executes_in_mcp, false);
  assert.match(result.structuredContent.planned[0].devtools_fetch, /fetch/);
});
