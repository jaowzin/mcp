import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), 'edge-mcp-ts-test-'));
process.env.HOME = tempHome;
process.env.USERPROFILE = tempHome;
process.env.LOCALAPPDATA = path.join(tempHome, 'LocalAppData');

const { safeJoin, getPaths } = await import('../src/core/paths.js');
const { hostMatches } = await import('../src/core/security.js');
const { WorkspaceService } = await import('../src/services/WorkspaceService.js');
const { ScriptService } = await import('../src/services/ScriptService.js');
const { loadIdentity } = await import('../src/core/identity.js');
const { RuntimeSettingsStore } = await import('../src/core/settings.js');

test('safeJoin bloqueia saída do workspace em qualquer sistema operacional', () => {
  const root = path.resolve(os.tmpdir(), 'edge-mcp-safe-root');
  assert.throws(() => safeJoin(root, '../secret.txt'));
  assert.equal(safeJoin(root, 'a/b.txt'), path.join(root, 'a', 'b.txt'));
});

test('hostMatches aceita host exato e wildcard limitado', () => {
  assert.equal(hostMatches('api.example.com', ['*.example.com'], false), true);
  assert.equal(hostMatches('example.com', ['*.example.com'], false), false);
  assert.equal(hostMatches('anything.test', ['*'], false), false);
  assert.equal(hostMatches('anything.test', ['*'], true), true);
});

test('identidade permanece fixa entre carregamentos', () => {
  const a = loadIdentity();
  const b = loadIdentity();
  assert.equal(a.mcpPath, b.mcpPath);
  assert.equal(a.dashboardToken, b.dashboardToken);
});

test('runtime settings persistem', () => {
  const a = new RuntimeSettingsStore();
  a.update({ allowDirectJavaScript: true });
  const b = new RuntimeSettingsStore();
  assert.equal(b.get().allowDirectJavaScript, true);
});

test('workspace cria, lê, pesquisa e não cria arquivo vazio por falha', () => {
  const workspace = new WorkspaceService(100_000);
  const created = workspace.write('notes/test.txt', 'linha um\nlinha dois', false);
  assert.equal(created.created, true);
  assert.equal(workspace.read('notes/test.txt').content.includes('linha dois'), true);
  assert.equal(workspace.search('dois').length, 1);
  assert.throws(() => workspace.write('../escape.txt', 'x', false));
});

test('análise de scripts separa visual, rede e revisão', () => {
  const scripts = new ScriptService(100_000);
  assert.equal(scripts.analyze('document.body.append("ok")').profile, 'visual_preview');
  assert.equal(scripts.analyze('fetch("/api")').profile, 'authorized_web_test');
  assert.equal(scripts.analyze('eval("1+1")').profile, 'review_required');
});

test('script vazio é rejeitado', () => {
  const scripts = new ScriptService(100_000);
  assert.throws(() => scripts.saveSource({ source: '', scriptId: 'empty' }));
});

test('script salva checksum e detecta alteração externa', () => {
  const scripts = new ScriptService(100_000);
  const record = scripts.saveSource({ source: 'document.title', scriptId: 'checksum', allowedPageHosts: ['example.com'] });
  assert.equal(scripts.get(record.id).integrityOk, true);
  const scriptPath = path.join(getPaths().scriptsDir, 'checksum.js');
  assert.equal(fs.existsSync(scriptPath), true);
  fs.writeFileSync(scriptPath, 'alterado', 'utf8');
  assert.equal(scripts.get(record.id).integrityOk, false);
});


test('toolResult sempre entrega structuredContent como objeto MCP valido', async () => {
  const { toolResult } = await import('../src/mcp/result.js');

  assert.deepEqual(toolResult([{ page_id: 'abc' }]).structuredContent, { items: [{ page_id: 'abc' }] });
  assert.deepEqual(toolResult({ ok: true }).structuredContent, { ok: true });
  assert.deepEqual(toolResult('texto').structuredContent, { value: 'texto' });
  assert.deepEqual(toolResult(null).structuredContent, { value: null });
  assert.equal(toolResult({ error: 'falha' }, true).isError, true);

  const { CallToolResultSchema } = await import('@modelcontextprotocol/sdk/types.js');
  for (const value of [[{ page_id: 'abc' }], { ok: true }, 'texto', null, 42, false]) {
    assert.equal(CallToolResultSchema.safeParse(toolResult(value)).success, true);
  }
});

test('versao do codigo coincide com package.json, package-lock e VERSION.txt', async () => {
  const { APP_VERSION } = await import('../src/core/version.js');
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')) as { version: string };
  const packageLock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8')) as { version: string; packages: Record<string, { version?: string }> };
  const versionFile = fs.readFileSync(path.join(root, 'VERSION.txt'), 'utf8').trim();

  assert.equal(APP_VERSION, packageJson.version);
  assert.equal(APP_VERSION, packageLock.version);
  assert.equal(APP_VERSION, packageLock.packages['']?.version);
  assert.equal(APP_VERSION, versionFile);
});

test('watchdog encerra ferramenta pendurada com erro estruturado', async () => {
  const { wrapTool } = await import('../src/mcp/result.js');
  const started = Date.now();
  const result = await wrapTool(() => new Promise<never>(() => undefined), { name: 'teste_pendurado', timeoutMs: 120 });
  assert.equal(result.isError, true);
  assert.ok(Date.now() - started < 1_000);
  assert.equal((result.structuredContent as any).code, 'OPERATION_TIMEOUT');
  assert.equal((result.structuredContent as any).retryable, true);
});

test('atividade registra conclusão e não deixa chamada ativa', async () => {
  const { wrapTool, toolActivityResult } = await import('../src/mcp/result.js');
  await wrapTool(() => ({ ok: true }), { name: 'atividade_teste', timeoutMs: 1_000 });
  const activity = toolActivityResult().structuredContent as any;
  assert.equal(activity.active.length, 0);
  assert.equal(activity.recent.some((item: any) => item.name === 'atividade_teste' && item.status === 'ok'), true);
});

test('browser_analyze_page conclui pacote unico com seções parciais independentes', async () => {
  const { EdgeController } = await import('../src/edge/EdgeController.js');
  const runtime = new RuntimeSettingsStore();
  const edge = new EdgeController('http://127.0.0.1:0', runtime) as any;
  const frame: any = { url: () => 'https://example.test/frame', name: () => 'main' };
  const page: any = {
    isClosed: () => false,
    url: () => 'https://example.test/',
    title: async () => 'Página de teste',
    on: () => undefined,
    frames: () => [frame],
    mainFrame: () => frame,
    locator: () => ({ first: () => ({ innerText: async () => 'texto visível' }) }),
    evaluate: async (fn: Function) => {
      const source = fn.toString();
      if (source.includes('document.readyState')) return { readyState: 'complete', viewport: { width: 1000, height: 700, devicePixelRatio: 1 }, elements: 10, links: 1, forms: 0, scripts: 2, stylesheets: 1 };
      if (source.includes('document.querySelectorAll(selector)')) return [];
      if (source.includes('document.scripts')) return [];
      if (source.includes('document.styleSheets')) return [];
      return null;
    }
  };
  edge.browser = { isConnected: () => true };
  edge.context = { pages: () => [page] };

  const progress: number[] = [];
  const result = await edge.analyzePage('', { stepTimeoutMs: 1_000 }, (event: any) => { progress.push(event.progress); });
  assert.equal(result.completed, true);
  assert.equal(result.partial, false);
  assert.equal((result.sections.page as any).ok, true);
  assert.equal((result.sections.network as any).ok, true);
  assert.deepEqual(progress, [0, 1, 2, 3, 4]);
});

test('browser_open_and_analyze abre URL e entrega análise em uma única chamada', async () => {
  const { EdgeController } = await import('../src/edge/EdgeController.js');
  const runtime = new RuntimeSettingsStore();
  const edge = new EdgeController('http://127.0.0.1:0', runtime) as any;
  let currentUrl = 'about:blank';
  let navigatedTo = '';
  const page: any = {
    isClosed: () => false,
    url: () => currentUrl,
    title: async () => 'Página direta',
    on: () => undefined,
    bringToFront: async () => undefined,
    goto: async (url: string) => {
      navigatedTo = url;
      currentUrl = url;
      return { status: () => 200 };
    }
  };
  edge.browser = { isConnected: () => true };
  edge.context = { pages: () => [], newPage: async () => page };
  edge.analyzePage = async (pageId: string, _options: unknown, onProgress?: (event: any) => void) => {
    onProgress?.({ progress: 0, total: 4, message: 'analisando' });
    return { completed: true, page_id: pageId, url: currentUrl };
  };

  const progress: number[] = [];
  const result = await edge.openAndAnalyze('https://example.test/path', {}, true, (event: any) => { progress.push(event.progress); });
  assert.equal(navigatedTo, 'https://example.test/path');
  assert.equal(result.completed, true);
  assert.equal((result.navigation as any).ok, true);
  assert.equal((result.analysis as any).completed, true);
  assert.deepEqual(progress, [0, 1]);
});


test('browser read registra quick_scan e frame_scan para páginas pesadas', async () => {
  const { registerBrowserReadTools } = await import('../src/mcp/tools/browserRead.js');
  const tools = new Map<string, any>();
  const server = { registerTool: (name: string, config: unknown, handler: unknown) => tools.set(name, { config, handler }) };
  const ctx: any = { edge: {}, audit: { write: () => undefined } };
  registerBrowserReadTools(server as any, ctx);
  assert.equal(tools.has('browser_quick_scan'), true);
  assert.equal(tools.has('browser_frame_scan'), true);
  assert.equal((tools.get('browser_quick_scan').config as any).annotations.readOnlyHint, true);
});
