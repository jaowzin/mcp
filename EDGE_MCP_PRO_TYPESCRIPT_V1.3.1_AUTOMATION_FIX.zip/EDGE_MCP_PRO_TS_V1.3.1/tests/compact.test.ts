import test from 'node:test';
import assert from 'node:assert/strict';
import { registerCompactTools } from '../src/mcp/tools/compact.js';

function analysisInput(url: string) {
  return {
    url,
    reuse_existing: true,
    include_html: false,
    max_text_chars: 50_000,
    max_html_chars: 80_000,
    element_limit: 200,
    script_limit: 200,
    event_limit: 150,
    step_timeout_ms: 10_000
  };
}

test('modo compacto registra somente seis ferramentas', () => {
  const tools = new Map<string, unknown>();
  const server = { registerTool: (name: string, config: unknown, handler: unknown) => tools.set(name, { config, handler }) };
  const ctx: any = {
    edge: {},
    audit: { write: () => undefined },
    runtime: { get: () => ({ allowPrivateNetwork: true }) },
    config: { publicBaseUrl: 'https://mcp.example.test', port: 8765 },
    identity: { mcpPath: '/mcp/test' }
  };
  registerCompactTools(server as any, ctx);
  assert.deepEqual([...tools.keys()].sort(), [
    'api_http_request',
    'browser_open_and_analyze',
    'edge_execute',
    'source_fetch_url',
    'system_activity',
    'system_status'
  ]);
});

test('browser_open_and_analyze chama abertura e análise sem listar abas', async () => {
  const tools = new Map<string, any>();
  const server = { registerTool: (name: string, config: unknown, handler: unknown) => tools.set(name, { config, handler }) };
  const calls: string[] = [];
  const ctx: any = {
    edge: {
      openAndAnalyze: async (url: string) => {
        calls.push(`open:${url}`);
        return { completed: true, requested_url: url, analysis: { completed: true } };
      }
    },
    audit: { write: () => undefined },
    runtime: { get: () => ({ allowPrivateNetwork: true }) },
    config: { publicBaseUrl: 'https://mcp.example.test', port: 8765 },
    identity: { mcpPath: '/mcp/test' }
  };
  registerCompactTools(server as any, ctx);
  const result = await tools.get('browser_open_and_analyze').handler(
    analysisInput('https://example.test/ctf'),
    { _meta: {}, signal: new AbortController().signal, sendNotification: async () => undefined }
  );
  assert.deepEqual(calls, ['open:https://example.test/ctf']);
  assert.equal(result.isError, false);
  assert.equal(result.structuredContent.completed, true);
});
