import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), 'edge-mcp-ts-http-'));
process.env.HOME = tempHome;
process.env.USERPROFILE = tempHome;
process.env.LOCALAPPDATA = path.join(tempHome, 'LocalAppData');
process.env.EDGE_MCP_PORT = '18765';
process.env.EDGE_MCP_PUBLIC_BASE_URL = 'https://mcp.example.test';
process.env.EDGE_MCP_CDP_URL = 'http://127.0.0.1:65534';

const { createContext } = await import('../src/core/createContext.js');
const { createHttpApp } = await import('../src/http/app.js');

test('health e MCP initialize funcionam', async () => {
  const ctx = createContext();
  const app = createHttpApp(ctx);
  const server = app.listen(0, '127.0.0.1');
  await new Promise<void>(resolve => server.once('listening', resolve));
  const address = server.address();
  assert.ok(address && typeof address === 'object');
  const base = `http://127.0.0.1:${address.port}`;
  const health = await fetch(`${base}/health`);
  assert.equal(health.status, 200);
  const initialize = await fetch(`${base}${ctx.identity.mcpPath}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-11-25', capabilities: {}, clientInfo: { name: 'test', version: '1' } } })
  });
  assert.equal(initialize.status, 200);
  const payload = await initialize.json() as any;
  assert.equal(payload.result.serverInfo.name, 'Edge MCP Pro TypeScript');
  assert.match(payload.result.instructions, /browser_open_and_analyze/);

  const startedList = Date.now();
  const toolsResponse = await fetch(`${base}${ctx.identity.mcpPath}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} })
  });
  assert.equal(toolsResponse.status, 200);
  assert.ok(Date.now() - startedList < 2_000);
  assert.equal(toolsResponse.headers.get('x-edge-mcp-version'), (await import('../src/core/version.js')).APP_VERSION);
  const toolsPayload = await toolsResponse.json() as any;
  const tools = toolsPayload.result.tools as any[];
  const toolNames = tools.map((tool: any) => tool.name).sort();
  assert.ok(toolNames.length >= 40, `catalogo completo deveria expor muitas ferramentas, recebeu ${toolNames.length}`);
  for (const required of [
    'browser_open_and_analyze',
    'browser_analyze_page',
    'browser_quick_scan',
    'browser_frame_scan',
    'browser_list_tabs',
    'browser_navigate',
    'api_http_request',
    'source_fetch_url',
    'ctf_readonly_recon',
    'ctf_public_code_search',
    'ctf_request_plan',
    'ctf_game_runtime_capture',
    'workspace_write',
    'page_script_run_saved',
    'system_activity',
    'system_status'
  ]) {
    assert.equal(toolNames.includes(required), true, `ferramenta ausente: ${required}`);
  }
  for (const tool of tools) {
    assert.equal(typeof tool.outputSchema, 'object', `outputSchema ausente em ${tool.name}`);
    assert.equal(tool.outputSchema.type, 'object', `outputSchema precisa ser objeto em ${tool.name}`);
  }

  const activityResponse = await fetch(`${base}${ctx.identity.mcpPath}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'system_activity', arguments: {} } })
  });
  assert.equal(activityResponse.status, 200);
  const activityPayload = await activityResponse.json() as any;
  assert.equal(typeof activityPayload.result.structuredContent, 'object');
  assert.equal(Array.isArray(activityPayload.result.structuredContent), false);

  await new Promise<void>(resolve => server.close(() => resolve()));
});

test('caminho MCP incorreto retorna 404', async () => {
  const ctx = createContext();
  const app = createHttpApp(ctx);
  const server = app.listen(0, '127.0.0.1');
  await new Promise<void>(resolve => server.once('listening', resolve));
  const address = server.address();
  assert.ok(address && typeof address === 'object');
  const response = await fetch(`http://127.0.0.1:${address.port}/mcp/errado`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
  assert.equal(response.status, 404);
  await new Promise<void>(resolve => server.close(() => resolve()));
});
