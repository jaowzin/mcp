type Overview = {
  version: string;
  config: { publicBaseUrl: string; port: number; cdpUrl: string };
  mcpUrl: string;
  settings: Record<string, boolean>;
  edge: Record<string, unknown>;
  tabs: Array<Record<string, unknown>>;
  activity: { active: Array<Record<string, any>>; recent: Array<Record<string, any>> };
  scripts: Array<Record<string, any>>;
  approvals: Array<Record<string, any>>;
  autorun: Record<string, unknown>;
  audit: Array<Record<string, any>>;
};

const token = new URLSearchParams(location.search).get('token') ?? '';
const q = (id: string) => document.getElementById(id)!;
let overview: Overview | null = null;
let selectedScriptId = '';

const api = async (path: string, init: RequestInit = {}) => {
  const separator = path.includes('?') ? '&' : '?';
  const response = await fetch(`${path}${separator}token=${encodeURIComponent(token)}`, init);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
};

const escapeHtml = (value: unknown) => String(value ?? '').replace(/[&<>'"]/g, char => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[char]!));
const splitHosts = (text: string) => text.split(/[\n,]/).map(v => v.trim()).filter(Boolean);
const setResult = (id: string, value: unknown) => { q(id).textContent = typeof value === 'string' ? value : JSON.stringify(value, null, 2); };

const settingLabels: Record<string, [string,string]> = {
  allowBrowserActions: ['Ações no navegador', 'Navegação, clique, preenchimento, teclado e rolagem.'],
  allowWorkspaceWrite: ['Criar arquivos', 'Permite criar e substituir arquivos no workspace.'],
  allowWorkspaceDelete: ['Excluir arquivos', 'Permite exclusão após aprovação local.'],
  allowDirectJavaScript: ['JavaScript direto', 'Expõe execução direta de JavaScript na aba.'],
  allowSavedScripts: ['Scripts JavaScript salvos', 'Permite registrar, importar e executar scripts locais.'],
  allowNetworkScripts: ['Scripts com rede', 'Permite fetch, XHR, WebSocket, EventSource e sendBeacon.'],
  allowGlobalScriptHosts: ['Todos os hosts', 'Aceita * nos hosts da página e da rede.'],
  requireApprovalForDirectJavaScript: ['Aprovar JavaScript direto', 'Exige aprovação de uso único antes da execução direta.'],
  requireApprovalForNetworkScripts: ['Aprovar scripts com rede', 'Exige aprovação de uso único para scripts que usam rede.'],
  autoRunTrustedScripts: ['Autoexecutar scripts confiáveis', 'Executa scripts armados quando uma página permitida carregar.'],
  allowPrivateNetwork: ['Rede privada', 'Permite APIs em localhost e endereços privados.']
};

function switchView(name: string): void {
  document.querySelectorAll('.nav-item').forEach(el => el.classList.toggle('active', (el as HTMLElement).dataset.view === name));
  document.querySelectorAll('.view').forEach(el => el.classList.toggle('active', el.id === `view-${name}`));
  const titles: Record<string,[string,string]> = {
    overview: ['Visão geral','Status do servidor, Edge e domínio fixo.'],
    controls: ['Controles','Permissões aplicadas em tempo real.'],
    scripts: ['Scripts JS','Biblioteca, escopo, execução e autoexecução.'],
    approvals: ['Aprovações','Confirmações locais de uso único.'],
    audit: ['Auditoria','Eventos recentes sem segredos.']
  };
  q('pageTitle').textContent = titles[name]?.[0] ?? name;
  q('pageSubtitle').textContent = titles[name]?.[1] ?? '';
}

function renderOverview(data: Overview): void {
  const connected = Boolean(data.edge.connected);
  q('connectionDot').className = `status-dot ${connected ? 'good' : 'bad'}`;
  q('connectionText').textContent = connected ? 'Edge conectado' : 'Edge desconectado';
  q('mcpUrl').textContent = data.mcpUrl;
  const cards = [
    ['Servidor','Online',`v${data.version}`],
    ['Edge',connected ? 'Conectado' : 'Desconectado',String(data.config.cdpUrl)],
    ['Abas',String(data.tabs.length),'Microsoft Edge isolado'],
    ['Scripts',String(data.scripts.length),`${data.scripts.filter(s => s.enabled).length} habilitados`],
    ['MCP ativo',String(data.activity?.active?.length ?? 0),'watchdog de chamadas']
  ];
  q('statusCards').innerHTML = cards.map(([label,value,small]) => `<div class="card"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(small)}</small></div>`).join('');
  q('tabsTable').innerHTML = data.tabs.length ? `<table><thead><tr><th>Ativa</th><th>Título</th><th>URL</th><th>page_id</th></tr></thead><tbody>${data.tabs.map(tab => `<tr><td>${tab.active ? '●' : ''}</td><td>${escapeHtml(tab.title)}</td><td>${escapeHtml(tab.url)}</td><td><code>${escapeHtml(tab.page_id)}</code></td></tr>`).join('')}</tbody></table>` : '<div class="empty-state">Nenhuma aba conectada.</div>';
  setResult('activityBox', { active: data.activity?.active ?? [], recent: (data.activity?.recent ?? []).slice(0, 10) });
}

function renderSettings(data: Overview): void {
  q('settingsGrid').innerHTML = Object.entries(data.settings).map(([key,value]) => {
    const [title,description] = settingLabels[key] ?? [key,''];
    return `<div class="setting"><div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(description)}</span></div><label class="switch"><input type="checkbox" data-setting="${escapeHtml(key)}" ${value ? 'checked' : ''}><span class="slider"></span></label></div>`;
  }).join('');
  document.querySelectorAll<HTMLInputElement>('[data-setting]').forEach(input => input.addEventListener('change', async () => {
    input.disabled = true;
    try { await api('/admin/api/settings', { method: 'PATCH', headers: { 'content-type':'application/json' }, body: JSON.stringify({ [input.dataset.setting!]: input.checked }) }); await refresh(); }
    catch (error) { alert(error instanceof Error ? error.message : String(error)); input.checked = !input.checked; }
    finally { input.disabled = false; }
  }));
}

function renderScripts(data: Overview): void {
  const list = q('scriptsList');
  list.innerHTML = data.scripts.length ? data.scripts.map(script => `<div class="script-item ${selectedScriptId === script.id ? 'active' : ''}" data-script-id="${escapeHtml(script.id)}"><strong>${escapeHtml(script.name)}</strong><span>${escapeHtml(script.id)}</span><div><span class="badge ${script.integrityOk ? 'good':'bad'}">${script.integrityOk ? 'checksum ok':'alterado'}</span><span class="badge ${script.profile === 'visual_preview' ? 'good' : script.profile === 'authorized_web_test' ? 'warn':'bad'}">${escapeHtml(script.profile)}</span>${script.autoRun ? '<span class="badge good">autorun</span>' : ''}</div></div>`).join('') : '<div class="empty-state">Nenhum script registrado.</div>';
  list.querySelectorAll<HTMLElement>('[data-script-id]').forEach(item => item.addEventListener('click', () => { selectedScriptId = item.dataset.scriptId!; renderScripts(data); renderScriptEditor(data); }));
  renderScriptEditor(data);
}

function renderScriptEditor(data: Overview): void {
  const script = data.scripts.find(item => item.id === selectedScriptId);
  q('scriptEditorEmpty').classList.toggle('hidden', Boolean(script));
  q('scriptForm').classList.toggle('hidden', !script);
  if (!script) return;
  (q('scriptId') as HTMLInputElement).value = script.id;
  (q('scriptName') as HTMLInputElement).value = script.name;
  (q('scriptDescription') as HTMLTextAreaElement).value = script.description;
  (q('pageHosts') as HTMLTextAreaElement).value = script.allowedPageHosts.join('\n');
  (q('networkHosts') as HTMLTextAreaElement).value = script.allowedNetworkHosts.join('\n');
  (q('scriptEnabled') as HTMLInputElement).checked = script.enabled;
  (q('scriptTrusted') as HTMLInputElement).checked = script.trusted;
  (q('scriptAutorun') as HTMLInputElement).checked = script.autoRun;
  q('scriptMeta').innerHTML = `Perfil: <b>${escapeHtml(script.profile)}</b><br>SHA-256: <code>${escapeHtml(script.sha256)}</code><br>Tamanho: ${escapeHtml(script.bytes)} bytes<br>Origem: ${escapeHtml(script.origin)}<br>Flags: ${escapeHtml((script.reviewFlags || []).join(', ') || 'nenhuma')}`;
  const select = q('targetPage') as HTMLSelectElement;
  select.innerHTML = data.tabs.map(tab => `<option value="${escapeHtml(tab.page_id)}">${escapeHtml(tab.title || tab.url)} — ${escapeHtml(tab.url)}</option>`).join('');
}

function renderApprovals(data: Overview): void {
  q('approvalsList').innerHTML = data.approvals.length ? data.approvals.map(item => `<div class="approval"><div><strong>${escapeHtml(item.summary || item.tool)}</strong><p>${escapeHtml(item.risk)} · ${escapeHtml(item.status)} · ${escapeHtml(item.createdAt)}</p><code>${escapeHtml(item.id)}</code></div>${item.status === 'pending' ? `<div class="approval-actions"><button class="button" data-approval="${escapeHtml(item.id)}" data-decision="approve">Aprovar</button><button class="button danger" data-approval="${escapeHtml(item.id)}" data-decision="deny">Negar</button></div>` : ''}</div>`).join('') : '<div class="empty-state">Nenhuma aprovação.</div>';
  document.querySelectorAll<HTMLElement>('[data-approval]').forEach(button => button.addEventListener('click', async () => {
    await api(`/admin/api/approvals/${button.dataset.approval}/${button.dataset.decision}`, { method: 'POST' });
    await refresh();
  }));
}

function renderAudit(data: Overview): void {
  q('auditTable').innerHTML = data.audit.length ? `<table><thead><tr><th>Hora</th><th>Ator</th><th>Ação</th><th>Alvo</th></tr></thead><tbody>${data.audit.map(item => `<tr><td>${escapeHtml(item.at)}</td><td>${escapeHtml(item.actor)}</td><td>${escapeHtml(item.action)}</td><td>${escapeHtml(item.subject || '')}</td></tr>`).join('')}</tbody></table>` : '<div class="empty-state">Sem eventos.</div>';
}

async function refresh(): Promise<void> {
  try {
    overview = await api('/admin/api/overview');
    renderOverview(overview!); renderSettings(overview!); renderScripts(overview!); renderApprovals(overview!); renderAudit(overview!);
  } catch (error) {
    q('connectionDot').className = 'status-dot bad';
    q('connectionText').textContent = error instanceof Error ? error.message : String(error);
  }
}

document.querySelectorAll<HTMLElement>('.nav-item').forEach(button => button.addEventListener('click', () => switchView(button.dataset.view!)));
q('refreshButton').addEventListener('click', () => void refresh());
q('copyMcp').addEventListener('click', async () => { await navigator.clipboard.writeText(q('mcpUrl').textContent || ''); (q('copyMcp') as HTMLButtonElement).textContent = 'Copiado'; setTimeout(() => (q('copyMcp') as HTMLButtonElement).textContent = 'Copiar', 1200); });

q('scriptForm').addEventListener('submit', async event => {
  event.preventDefault();
  if (!selectedScriptId) return;
  try {
    await api(`/admin/api/scripts/${encodeURIComponent(selectedScriptId)}`, { method:'PATCH', headers:{'content-type':'application/json'}, body:JSON.stringify({
      name:(q('scriptName') as HTMLInputElement).value,
      description:(q('scriptDescription') as HTMLTextAreaElement).value,
      allowedPageHosts:splitHosts((q('pageHosts') as HTMLTextAreaElement).value),
      allowedNetworkHosts:splitHosts((q('networkHosts') as HTMLTextAreaElement).value),
      enabled:(q('scriptEnabled') as HTMLInputElement).checked,
      trusted:(q('scriptTrusted') as HTMLInputElement).checked,
      autoRun:(q('scriptAutorun') as HTMLInputElement).checked
    }) });
    setResult('scriptResult','Salvo.'); await refresh();
  } catch(error) { setResult('scriptResult',{error:error instanceof Error ? error.message : String(error)}); }
});
q('runScript').addEventListener('click', async () => {
  if (!selectedScriptId) return;
  setResult('scriptResult','Executando...');
  try { setResult('scriptResult', await api(`/admin/api/scripts/${encodeURIComponent(selectedScriptId)}/run`, { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({ page_id:(q('targetPage') as HTMLSelectElement).value }) })); await refresh(); }
  catch(error) { setResult('scriptResult',{error:error instanceof Error ? error.message : String(error)}); }
});
q('deleteScript').addEventListener('click', async () => {
  if (!selectedScriptId || !confirm(`Excluir ${selectedScriptId}?`)) return;
  try { await api(`/admin/api/scripts/${encodeURIComponent(selectedScriptId)}`, { method:'DELETE' }); selectedScriptId=''; await refresh(); }
  catch(error) { setResult('scriptResult',{error:error instanceof Error ? error.message : String(error)}); }
});

const dialog = q('importDialog') as HTMLDialogElement;
q('newImport').addEventListener('click', () => dialog.showModal());
q('closeImport').addEventListener('click', () => dialog.close());
q('cancelImport').addEventListener('click', () => dialog.close());
q('importForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = new FormData();
  const file = (q('importFile') as HTMLInputElement).files?.[0];
  if (!file) return;
  form.append('file', file);
  form.append('script_id', (q('importId') as HTMLInputElement).value);
  form.append('name', (q('importName') as HTMLInputElement).value);
  form.append('allowed_page_hosts', (q('importPageHosts') as HTMLTextAreaElement).value);
  form.append('allowed_network_hosts', (q('importNetworkHosts') as HTMLTextAreaElement).value);
  form.append('trusted', String((q('importTrusted') as HTMLInputElement).checked));
  setResult('importResult','Importando...');
  try { const result = await api('/admin/api/scripts/import', { method:'POST', body:form }); selectedScriptId=result.id; setResult('importResult',result); await refresh(); setTimeout(() => dialog.close(), 700); }
  catch(error) { setResult('importResult',{error:error instanceof Error ? error.message : String(error)}); }
});

void refresh();
setInterval(() => void refresh(), 5000);
